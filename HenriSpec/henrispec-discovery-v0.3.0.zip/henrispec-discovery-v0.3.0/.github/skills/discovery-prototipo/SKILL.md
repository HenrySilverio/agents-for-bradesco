---
name: discovery-prototipo
description: "Atalho de compatibilidade do comando /discovery-prototipo. A etapa roda no agente discovery-prototipo."
argument-hint: "<a pergunta em uma frase> [contexto: caminhos]"
disable-model-invocation: true
---

# /discovery-prototipo

Esta etapa roda no agente `discovery-prototipo`, que fixa o modelo e as ferramentas dela.

Se as instruções deste chat começam com `# Agente discovery-prototipo`, siga-as usando o texto que veio
depois do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente
`discovery-prototipo` no seletor de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a etapa
fora do agente troca o modelo dela e libera ferramentas que ela não deveria ter.

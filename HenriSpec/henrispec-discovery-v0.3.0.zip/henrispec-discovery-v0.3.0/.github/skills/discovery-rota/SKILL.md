---
name: discovery-rota
description: "Atalho de compatibilidade do comando /discovery-rota. A etapa roda no agente discovery-rota."
argument-hint: "<onde você está e o que quer fazer>"
disable-model-invocation: true
---

# /discovery-rota

Esta etapa roda no agente `discovery-rota`, que fixa o modelo e as ferramentas dela.

Se as instruções deste chat começam com `# Agente discovery-rota`, siga-as usando o texto que veio
depois do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente
`discovery-rota` no seletor de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a etapa
fora do agente troca o modelo dela e libera ferramentas que ela não deveria ter.

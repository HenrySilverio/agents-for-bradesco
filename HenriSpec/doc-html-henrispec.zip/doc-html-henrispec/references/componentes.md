# Catálogo de componentes da fonte

Tudo que não está aqui não existe no casco: não invente classe nem estilo inline.

## Metadados (obrigatório, primeira linha)

```html
<meta-doc titulo="Título da aba do navegador" marca="HenriSpec" versao="v1.0"
          descricao="Uma frase sobre o documento" rodape="Texto do rodapé.">
```

`marca` vira o nome no topo; a última palavra com maiúscula (`Spec`) sai em vermelho, ou a
que você declarar em `marca-destaque`. `logo="caminho/logo.svg"`, relativo à fonte, troca a
logo e o favicon; sem ele vale a logo HenriSpec.

## Hero (opcional, uma vez)

```html
<header class="hero">
  <div class="marca-hero"><svg class="logo-vivo" width="64" height="64" aria-hidden="true"><use href="#logo"/></svg><span>Henri<b>Spec</b></span></div>
  <h1>Frase principal, no máximo duas linhas.</h1>
  <p class="sub">Uma ou duas frases do que o leitor ganha.</p>
  <div class="acoes"><a class="btn" href="#secao">Ação principal</a><a class="btn sec" href="#outra">Secundária</a></div>
  <!-- opcional: um diagrama (ver diagramas.md) -->
</header>
```

## Seção

```html
<section id="instalar" data-nav="Instalação">
  <h2>Instalação</h2>
  <p class="intro">Uma frase de abertura.</p>
  ...
</section>
```

- `id` é obrigatório. `data-nav` põe a seção na barra do topo. A numeração é automática;
  `data-num="nao"` a desliga.
- `class="faixa guard"` deixa a seção com fundo de faixa larga, para o bloco de destaque da
  página (guardrails, regras, segurança). Use uma vez.

## Texto e destaque

| Componente | Uso |
| --- | --- |
| `<p class="intro">` | parágrafo de abertura da seção |
| `<code>` | caminho, comando curto ou nome técnico dentro do texto |
| `<span class="chave">texto</span>` | frase crítica, com brilho animado |
| `class="vivo"` em `p` ou `.nota` | borda que gira em vermelho e âmbar |
| `<span class="etiqueta">`, `.etiqueta r`, `.etiqueta v` | rótulo neutro, vermelho (pulsa) e verde |
| `<div class="nota">` | aviso âmbar; `.nota vermelha` risco; `.nota verde` confirmação |

## Blocos

```html
<div class="duas"><div class="bloco"><h3>…</h3><p>…</p></div><div class="bloco">…</div></div>
```

Passos numerados (só para sequência real):

```html
<ol class="passos">
  <li><strong>Título curto do passo.</strong> Explicação. Código pode vir dentro do item.</li>
</ol>
```

Cartão expansível, fechado por padrão (exemplos de arquivo, saídas longas, FAQ):

```html
<details class="arq"><summary>Título <span class="caminho">detalhe ou caminho</span></summary>
  <div class="corpo"> … </div>
</details>
```

Abas (um cenário por aba). Os comentários de fechamento são obrigatórios:

```html
<div class="abas-grupo">
  <div class="painel" data-aba="Repositório novo"> … </div><!-- /painel -->
  <div class="painel" data-aba="Atualizar"> … </div><!-- /painel -->
</div><!-- /abas-grupo -->
```

Etapas com trilho lateral que acompanha a leitura:

```html
<div class="etapas">
  <article class="etapa" id="e-plano" data-rotulo="sdd-plan" data-sub="Claude Opus 5">
    <header><h3>sdd-plan</h3><span class="etiqueta r">Claude Opus 5</span></header>
    <p>…</p>
    <div class="grade"><div class="sim"><h4>Use quando</h4><ul><li>…</li></ul></div>
                       <div class="nao"><h4>Não use para</h4><ul><li>…</li></ul></div></div>
  </article>
</div><!-- /etapas -->
```

Grupos de destaque, dentro da seção `faixa guard`:

```html
<div class="guard-grupos">
  <div class="guard-grupo"><h3>Controle</h3><dl><dt>Regra</dt><dd>Explicação.</dd></dl></div>
</div>
```

Linha do tempo que se desenha com a rolagem:

```html
<div class="tempo" id="tempo"><div class="linha-viva"></div>
  <div class="momento"><time>09:00</time><h3>Título</h3><p>O que acontece.</p></div>
</div>
```

## Código

```html
<script type="text/x-codigo" data-lang="bash" data-rotulo="bash">
  bash "<pasta-do-pacote>/instalar.sh" repo . --dry-run   # comentário
</script>
```

| `data-lang` | Para | Visual |
| --- | --- | --- |
| `bash` | comandos de terminal | `$` verde, cursor piscando |
| `saida` | saída de terminal | cores ANSI: criar, atualizar, remover, CONFLITO, BLOQUEANTE |
| `json`, `yaml`, `markdown`, `html` | arquivos | números de linha, sintaxe Dark+ |
| `ts`, `java` | código-fonte | números de linha, sintaxe Dark+ |
| `chat` | mensagem para um agente | `#arquivo` e `chave:` realçados, cursor |
| `prompt` | prompt longo para colar | igual a `chat` |

O texto vai cru: não escape `<` nem `&`. A indentação comum é removida. Se o código tiver a
sequência `</script>`, escreva `<\/script>`. O botão Copiar copia sem o `$` e sem os números
de linha.

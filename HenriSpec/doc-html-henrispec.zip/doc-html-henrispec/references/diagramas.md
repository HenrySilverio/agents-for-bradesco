# Diagramas

Cada diagrama se monta passo a passo, segura, apaga e recomeça, em loop, com pontos de fluxo
correndo pelas setas. É CSS e SVG puro: funciona sem JavaScript e fica parado no estado final
quando o sistema pede menos movimento.

Um diagrama por cenário, com no máximo oito nós. Diagrama que precisa de legenda longa para
ser entendido está tentando explicar duas coisas.

## Esquema

```html
<script type="application/x-diagrama">
{
  "titulo": "Texto para leitor de tela",
  "legendaCores": true,
  "grade": { "col": 200, "lin": 110 },
  "nos": [
    { "id": "b", "col": 0, "lin": 0, "t": "briefing", "s": "você", "k": "voce", "step": 0 },
    { "id": "p", "col": 1, "lin": 0, "t": "sdd-plan", "s": "Opus", "step": 1, "destaque": true },
    { "id": "a", "col": 1, "lin": 1, "w": 180, "t": "archive", "s": "specs + decisões", "k": "dado", "step": 2 }
  ],
  "arestas": [
    { "de": "b", "para": "p", "step": 1 },
    { "de": "p", "para": "a", "step": 2, "cor": "b", "rotulo": "aprovado" }
  ]
}
</script>
```

## Nó

| Campo | Significa | Padrão |
| --- | --- | --- |
| `id` | identificador único, usado nas arestas | obrigatório |
| `col`, `lin` | posição na grade (0, 1, 2…); ou `x`, `y` em pixels | obrigatório |
| `t`, `s` | título e subtítulo; título até ~16 caracteres | `t` = `id` |
| `k` | `agente` (vermelho), `voce` (âmbar, pessoa), `arquivo` (cinza), `dado` (azul), `ok` (verde), `alerta` (vermelho de erro) | `agente` |
| `step` | em que passo aparece; 0 é o primeiro | 0 |
| `w`, `h` | largura e altura | 160, 58 |
| `destaque` | borda pulsando, para o nó que importa | não |
| `tracejado`, `x_riscado` | contorno tracejado; X por cima, para "proibido" | não |

## Aresta

| Campo | Significa | Padrão |
| --- | --- | --- |
| `de`, `para` | ids dos nós | obrigatório |
| `step` | passo em que a seta se desenha; use o do nó de destino | 0 |
| `cor` | `r` vermelho, `a` âmbar, `b` azul, `g` verde, `x` erro, `c` cinza | `r` |
| `rotulo`, `rx`, `ry` | texto da seta e, se precisar, a posição dele | meio da seta |
| `tracejada` | seta tracejada e sem ponto de fluxo: leitura, referência, dependência | não |
| `d` | caminho SVG manual, para laços e desvios (`M650 128V168H440V130`) | automático |

O caminho automático sai pela direita e entra pela esquerda quando o destino está à direita,
e pelo fundo e pelo topo quando está embaixo. Laço de volta (repetir, refazer) precisa de `d`
manual: desça do nó, ande na horizontal e suba no outro.

## Layout que funciona

- Fluxo principal numa linha (`lin: 0`), da esquerda para a direita; o que sai do fluxo vai
  para `lin: 1`.
- Grade de 200 por 110 com nós de 160 por 58 deixa 40 px entre nós; texto maior pede `w`
  maior e, às vezes, `grade.col` maior.
- `step` cresce na ordem de leitura. Nós do mesmo passo aparecem juntos.
- Cores com significado fixo no documento inteiro: âmbar é sempre pessoa, azul é sempre dado.

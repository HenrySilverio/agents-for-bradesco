---
name: doc-html-henrispec
description: Gera documentos HTML de página única no padrão visual HenriSpec — tema escuro com vermelho Bradesco, diagramas SVG que se montam em loop, código no visual do VS Code, abas, cartões expansíveis, linha do tempo e destaques animados. Use sempre que pedirem onboarding, guia, manual, tutorial, documentação, página de apresentação ou explicação de fluxo em HTML, mesmo que o pedido não cite o padrão HenriSpec.
---

# Documento HTML no padrão HenriSpec

Você escreve só o **conteúdo**, num arquivo fonte pequeno. Um script monta o HTML final:
realce de código, diagramas animados, abas, navegação, favicon, CSS e JavaScript. Nunca
escreva o HTML final à mão e nunca escreva CSS ou `<script>` próprio na fonte: o HTML final
tem dezenas de KB que custariam token e quebrariam o padrão; a fonte tem poucos.

A pasta desta skill é a pasta onde está este `SKILL.md` (por exemplo
`.agents/skills/doc-html-henrispec/`). Os caminhos abaixo são relativos a ela.

## Passo 1 - Entender o pedido

Extraia do pedido: público, objetivo do documento e as seções. Se o público ou o objetivo
não estiverem claros, faça **uma** pergunta e pare. Se estiverem, siga.

Público amplo, como um time inteiro, pede caminhos genéricos (`<seu-repo>`,
`<pasta-do-pacote>`), nunca caminhos ou nomes reais de uma pessoa.

## Passo 2 - Ler o catálogo

Leia `references/componentes.md`. Leia `references/diagramas.md` só se o documento tiver
diagrama. Use `assets/exemplo.fonte.html` como modelo de uma fonte completa.

## Passo 3 - Escrever a fonte

Crie `<nome>.fonte.html`, por padrão em `docs/`. Ela começa com `<meta-doc>`, pode ter um
`<header class="hero">` e segue com `<section>`s. Use só componentes do catálogo.

- Código vai em `<script type="text/x-codigo" data-lang="..." data-rotulo="...">`, com o
  texto cru, sem escapar `<` nem `&`. Exemplo de comando ou arquivo precisa ser real: se você
  não conferiu que o comando existe e roda, não o publique.
- Diagrama vai em `<script type="application/x-diagrama">` com JSON.
- Destaque animado (`vivo`, `chave`) é para o que não pode passar despercebido: no máximo
  cinco por documento. Se tudo pisca, nada destaca.
- Texto em português do Brasil, frases curtas, voz ativa.

## Passo 4 - Montar

```bash
node "<pasta-da-skill>/scripts/montar.mjs" docs/<nome>.fonte.html docs/<nome>.html
```

O script é Node 18+, sem dependência e sem rede. Ele valida a fonte e, com qualquer `ERRO`,
não grava nada: corrija a fonte e rode de novo. `AVISO` de texto que não cabe num nó de
diagrama se corrige aumentando o `w` sugerido.

Sem Node disponível, pare e diga isso. Não tente montar o HTML à mão.

## Passo 5 - Entregar

Informe o caminho do HTML e o da fonte. A fonte é o artefato editável: qualquer mudança
futura edita a fonte e roda o Passo 4 de novo. O HTML é um arquivo único, sem dependência
externa, que abre direto no navegador e pode ser enviado por e-mail ou Teams.

#!/usr/bin/env node
// doc-html-henrispec - monta um documento HTML no padrão visual HenriSpec.
// Arquivo único, sem dependência, Node 18+. Não usa rede.
//
//   node montar.mjs <fonte.html> [saida.html]
//
// A fonte é um fragmento HTML com componentes do catálogo (references/componentes.md).
// O script faz o trabalho mecânico que custaria token se o modelo fizesse à mão:
// realce de código no visual do VS Code, diagramas SVG animados em loop, abas, trilho de
// etapas, navegação, favicon e o casco com CSS e JS. Sai com código 1 se a fonte tiver erro.

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join, resolve, basename } from 'node:path';
import { fileURLToPath } from 'node:url';

const AQUI = dirname(fileURLToPath(import.meta.url));
const BASE = join(AQUI, '..', 'assets', 'base.html');
const LOGO_PADRAO = join(AQUI, '..', 'assets', 'logo.svg');

const erros = [];
const avisos = [];
const esc = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escAttr = (t) => esc(t).replace(/"/g, '&quot;');
const sp = (cls, t) => `<span class="${cls}">${esc(t)}</span>`;

// ------------------------------------------------------------------ atributos
function attrs(txt) {
  const out = {};
  for (const m of txt.matchAll(/([\w-]+)\s*=\s*"([^"]*)"/g)) out[m[1]] = m[2];
  for (const m of txt.matchAll(/([\w-]+)\s*=\s*'([^']*)'/g)) out[m[1]] ??= m[2];
  return out;
}

// ------------------------------------------------------------------ realce
const ICONES = {
  bash: ['&gt;_', 'ic-bash'], markdown: ['M↓', 'ic-md'], json: ['{}', 'ic-json'], chat: ['✦', 'ic-chat'],
  prompt: ['✦', 'ic-prompt'], saida: ['≡', 'ic-saida'], ts: ['TS', 'ic-ts'], html: ['&lt;&gt;', 'ic-html'], yaml: ['!', 'ic-yaml'], java: ['J', 'ic-java'],
};

const BASH = /(?<com>(?:(?<=\s)|^)#.*$)|(?<str>"(?:[^"\\]|\\.)*"|'[^']*')|(?<op>&&|\|\||[|;])|(?<flag>(?<=\s)--?[\w-]+)|(?<w>[^\s"'|;&]+)|(?<sp>\s+)/g;
function bash(l) {
  let inicio = true;
  let out = '';
  for (const m of l.matchAll(BASH)) {
    const g = m.groups;
    if (g.com) out += sp('k-com', g.com);
    else if (g.str) { out += sp('k-str', g.str); inicio = false; }
    else if (g.op) { out += esc(g.op); inicio = true; }
    else if (g.flag) out += sp('k-flag', g.flag);
    else if (g.w) { out += inicio ? sp('k-cmd', g.w) : esc(g.w); inicio = false; }
    else out += esc(m[0]);
  }
  return out;
}

const JSONRE = /(?<str>"(?:[^"\\]|\\.)*")(?<col>\s*:)?|(?<num>-?\d+(?:\.\d+)?)|(?<bool>\btrue\b|\bfalse\b|\bnull\b)|(?<br>[{}[\]])|(?<o>[^"\d{}[\]tfn-]+|.)/g;
function json(l, prof) {
  let out = '';
  for (const m of l.matchAll(JSONRE)) {
    const g = m.groups;
    if (g.str !== undefined) out += sp(g.col ? 'k-key' : 'k-str', g.str) + esc(g.col || '');
    else if (g.num !== undefined) out += sp('k-num', g.num);
    else if (g.bool !== undefined) out += sp('k-bool', g.bool);
    else if (g.br !== undefined) {
      if ('}]'.includes(g.br)) prof.n--;
      out += sp(`k-b${(((prof.n % 3) + 3) % 3) + 1}`, g.br);
      if ('{['.includes(g.br)) prof.n++;
    } else out += esc(m[0]);
  }
  return out;
}

function inlineMd(t) {
  let out = '';
  let pos = 0;
  for (const m of t.matchAll(/`[^`]+`|\*\*[^*]+\*\*|\[[ x]\]|\b(?:MUST NOT|MUST|SHOULD|MAY)\b|\bREQ-[\w-]+\b|\[NÃO RESPONDIDO\]/g)) {
    out += esc(t.slice(pos, m.index));
    const g = m[0];
    const cls = g.startsWith('`') ? 'k-code' : g.startsWith('**') ? 'k-bold' : g === '[ ]' || g === '[x]' ? 'k-chk'
      : g.startsWith('[NÃO') ? 'k-warn' : g.startsWith('REQ-') ? 'k-ref' : 'k-kw';
    out += sp(cls, g);
    pos = m.index + g.length;
  }
  return out + esc(t.slice(pos));
}
function markdown(l) {
  if (/^#{1,6}\s/.test(l)) return sp('k-h', l);
  let m = l.match(/^(\s*)([-*>]|\d+\.)(\s)(.*)$/);
  if (m) return esc(m[1]) + sp('k-li', m[2]) + esc(m[3]) + inlineMd(m[4]);
  m = l.match(/^([A-ZÀ-Ú][\wÀ-ú ]{1,28})(:)(\s.*|)$/);
  if (m && !/\s{2,}/.test(m[1])) return sp('k-meta', m[1]) + esc(m[2]) + inlineMd(m[3]);
  return inlineMd(l);
}

const TS = /(?<com>\/\/.*$)|(?<str>`(?:[^`\\]|\\.)*`|"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|(?<kw>\b(?:import|export|from|const|let|var|function|return|if|else|for|while|class|extends|implements|new|this|async|await|type|interface|readonly|private|public|protected|static|of|in|as|package|void|final|throws|throw|try|catch|record|enum|switch|case|default)\b)|(?<lit>\b(?:true|false|null|undefined)\b|\b\d+(?:\.\d+)?\b)|(?<tipo>\b[A-Z][\w]*\b)|(?<fn>\b[a-z_$][\w$]*(?=\s*\())|(?<dec>@\w+)|(?<o>[\s\S])/g;
function ts(l) {
  let out = '';
  for (const m of l.matchAll(TS)) {
    const g = m.groups;
    if (g.com) out += sp('k-com', g.com);
    else if (g.str) out += sp('k-str', g.str);
    else if (g.kw) out += sp('k-bool', g.kw);
    else if (g.lit) out += sp('k-num', g.lit);
    else if (g.tipo) out += sp('k-type', g.tipo);
    else if (g.fn) out += sp('k-cmd', g.fn);
    else if (g.dec) out += sp('k-cmd', g.dec);
    else out += esc(m[0]);
  }
  return out;
}

function html(l) {
  let out = '';
  let pos = 0;
  for (const m of l.matchAll(/<\/?([\w-]+)((?:\s+[\w:@\[\]().-]+(?:="[^"]*")?)*)\s*\/?>|<!--.*?-->/g)) {
    out += esc(l.slice(pos, m.index));
    if (m[0].startsWith('<!--')) out += sp('k-com', m[0]);
    else {
      const fecha = m[0].startsWith('</') ? '&lt;/' : '&lt;';
      let a = '';
      for (const at of (m[2] || '').matchAll(/(\s+)([\w:@\[\]().-]+)(?:(=)("[^"]*"))?/g)) {
        a += at[1] + sp('k-key', at[2]) + (at[3] ? '=' + sp('k-str', at[4]) : '');
      }
      out += `<span class="k-dim">${fecha}</span>${sp('k-bool', m[1])}${a}<span class="k-dim">${m[0].endsWith('/>') ? '/&gt;' : '&gt;'}</span>`;
    }
    pos = m.index + m[0].length;
  }
  return out + esc(l.slice(pos));
}

function yaml(l) {
  const m = l.match(/^(\s*-?\s*)([\w.-]+)(:)(.*)$/);
  if (/^\s*#/.test(l)) return sp('k-com', l);
  if (m) return esc(m[1]) + sp('k-key', m[2]) + esc(m[3]) + sp('k-str', m[4]);
  return esc(l);
}

const SAIDA = [
  [/\bCONFLITO\b|\bBLOQUEANTES?\b|\bREPROVA\b|\bREPROVADO\b|\bremover\b|\bFALHOU\b|\bERRO\b|\bfalhou\b/, 'k-err'],
  [/\bcriar\b|\bInstalado\b|\bsem bloqueante\b|\bok\b|\bAPROVADO\b|\bgravado\b|\bgravada\b|\bpassou\b/, 'k-ok'],
  [/\batualizar\b/, 'k-info'],
  [/\bmanter\b|\bPENDENTE\b|\bAVISO\b|\bNOTA\b|pré-existente\(s\)|pré-existente|Pré-existentes/, 'k-warn'],
  [/\bigual\b|\[dry-run\]/, 'k-dim'],
  [/(?<![\w/])\.?(?:\.github|\.sdd|\.agents|docs|src)\/[\w./@<>-]*/, 'k-path'],
];
const SAIDA_RE = new RegExp(SAIDA.map(([r], i) => `(?<g${i}>${r.source})`).join('|'), 'g');
function saida(l) {
  let out = '';
  let pos = 0;
  for (const m of l.matchAll(SAIDA_RE)) {
    out += esc(l.slice(pos, m.index));
    const i = Number(Object.keys(m.groups).find((k) => m.groups[k] !== undefined).slice(1));
    out += sp(SAIDA[i][1], m[0]);
    pos = m.index + m[0].length;
  }
  return out + esc(l.slice(pos));
}

function chat(l) {
  let out = '';
  let pos = 0;
  for (const m of l.matchAll(/#[\w.-]+|\b[\w-]+:(?=\s)|\beixo=\w+|(?<![\w/])(?:docs|\.sdd|\.agents|src)\/[\w./-]+|`[^`]+`/g)) {
    out += esc(l.slice(pos, m.index));
    const g = m[0];
    out += sp(g.startsWith('#') ? 'k-ref' : g.startsWith('`') ? 'k-code' : g.includes('/') ? 'k-path' : 'k-kw', g);
    pos = m.index + g.length;
  }
  return out + esc(l.slice(pos));
}

function bloco(lang, rotulo, conteudo) {
  if (!ICONES[lang]) {
    erros.push(`bloco de código "${rotulo}": data-lang "${lang}" inválido; use ${Object.keys(ICONES).join(', ')}`);
    lang = 'saida';
  }
  const linhas = conteudo.replace(/^\n+|\s+$/g, '').replace(/<\\\//g, '</').split('\n');
  const ind = Math.min(...linhas.filter((l) => l.trim()).map((l) => l.match(/^\s*/)[0].length));
  const prof = { n: 0 };
  const corpo = linhas.map((bruta) => {
    const l = bruta.slice(Number.isFinite(ind) ? ind : 0);
    switch (lang) {
      case 'bash': {
        const cmd = l.trim() && !l.trimStart().startsWith('#') && !l.startsWith('"');
        return `<span class="l${cmd ? ' cmd' : ''}">${bash(l)}</span>`;
      }
      case 'json': return `<span class="l">${json(l, prof)}</span>`;
      case 'markdown': return `<span class="l">${markdown(l)}</span>`;
      case 'ts':
      case 'java': return `<span class="l">${ts(l)}</span>`;
      case 'html': return `<span class="l">${html(l)}</span>`;
      case 'yaml': return `<span class="l">${yaml(l)}</span>`;
      case 'saida': return `<span class="l">${saida(l)}</span>`;
      default: return `<span class="l">${chat(l)}</span>`;
    }
  });
  if (['bash', 'chat', 'prompt'].includes(lang)) {
    corpo[corpo.length - 1] = corpo[corpo.length - 1].replace(/<\/span>$/, '<span class="caret" aria-hidden="true"></span></span>');
  }
  const extra = ['json', 'markdown', 'ts', 'java', 'html', 'yaml'].includes(lang) ? ' num' : lang === 'bash' ? ' term' : '';
  const [ic, iccls] = ICONES[lang];
  return `<div class="cod${extra}"><div class="rot"><span class="aba"><i class="ic ${iccls}">${ic}</i>${esc(rotulo)}</span>` +
    `<button class="copiar" type="button">Copiar</button></div><pre><code>${corpo.join('\n')}</code></pre></div>`;
}

// ------------------------------------------------------------------ diagramas
const KINDS = {
  agente: { fill: '#2a0c13', stroke: '#cc092f', sub: '#f36279' },
  voce: { fill: '#2b2207', stroke: '#ffbc00', sub: '#ffcf4d' },
  arquivo: { fill: '#1c1c1e', stroke: '#5b5c61', sub: '#a7a8ac' },
  dado: { fill: '#0e1a33', stroke: '#3b69ff', sub: '#8fb0ff' },
  ok: { fill: '#0c2016', stroke: '#09ab47', sub: '#57d98b' },
  alerta: { fill: '#2e0a12', stroke: '#e1173f', sub: '#ff8197' },
};
const CORES = { r: '#cc092f', a: '#ffbc00', c: '#5b5c61', b: '#3b69ff', g: '#09ab47', x: '#e1173f' };
const CICLO = 11;
let contDg = 0;

function keyframes(p, n) {
  const out = [];
  for (let i = 0; i <= n; i++) {
    const a = 4 + (62 / Math.max(n, 1)) * i;
    const b = a + 5;
    out.push(`@keyframes ${p}a${i}{0%,${a.toFixed(1)}%{opacity:0;transform:translateY(6px)}${b.toFixed(1)}%,88%{opacity:1;transform:none}96%,100%{opacity:0;transform:none}}`);
    out.push(`@keyframes ${p}d${i}{0%,${a.toFixed(1)}%{stroke-dashoffset:1}${(b + 3).toFixed(1)}%,88%{stroke-dashoffset:0}96%,100%{stroke-dashoffset:0}}`);
    out.push(`.${p} .s${i}{animation:${p}a${i} ${CICLO}s ease-in-out infinite both}`);
    out.push(`.${p} .s${i} .ln{animation:${p}d${i} ${CICLO}s ease-in-out infinite both}`);
  }
  return out.join('\n');
}

function ancora(n, lado) {
  const { x, y, w, h } = n;
  return { r: [x + w, y + h / 2], l: [x, y + h / 2], t: [x + w / 2, y], b: [x + w / 2, y + h] }[lado];
}

function caminho(a, b) {
  if (b.x >= a.x + a.w - 1) {
    const [x1, y1] = ancora(a, 'r');
    const [x2, y2] = ancora(b, 'l');
    if (Math.abs(y1 - y2) < 1) return `M${x1} ${y1}H${x2 - 2}`;
    const mx = (x1 + x2) / 2;
    return `M${x1} ${y1}H${mx}V${y2}H${x2 - 2}`;
  }
  if (b.x + b.w <= a.x + 1 && Math.abs(a.y + a.h / 2 - (b.y + b.h / 2)) < 1) {
    const [x1, y1] = ancora(a, 'l');
    const [x2, y2] = ancora(b, 'r');
    return `M${x1} ${y1}H${x2 + 2}`;
  }
  if (b.y > a.y) {
    const [x1, y1] = ancora(a, 'b');
    const [x2, y2] = ancora(b, 't');
    if (Math.abs(x1 - x2) < 1) return `M${x1} ${y1}V${y2 - 2}`;
    const my = (y1 + y2) / 2;
    return `M${x1} ${y1}V${my}H${x2}V${y2 - 2}`;
  }
  const [x1, y1] = ancora(a, 't');
  const [x2, y2] = ancora(b, 'b');
  const my = (y1 + y2) / 2;
  return `M${x1} ${y1}V${my}H${x2}V${y2 + 2}`;
}

function meio(d) {
  let cx = 0;
  let cy = 0;
  const xs = [];
  const ys = [];
  for (const t of d.match(/[MHVL][^MHVL]*/g) || []) {
    const v = (t.match(/-?\d+\.?\d*/g) || []).map(Number);
    if (t[0] === 'M' || t[0] === 'L') [cx, cy] = v;
    else if (t[0] === 'H') cx = v[0];
    else if (t[0] === 'V') cy = v[0];
    xs.push(cx);
    ys.push(cy);
  }
  return [(Math.min(...xs) + Math.max(...xs)) / 2, (Math.min(...ys) + Math.max(...ys)) / 2 - 7];
}

function diagrama(spec) {
  const p = `dg${++contDg}`;
  const nos = spec.nos || [];
  const arestas = spec.arestas || [];
  if (!nos.length) erros.push(`diagrama ${contDg}: sem "nos"`);
  const g = { col: spec.grade?.col ?? 200, lin: spec.grade?.lin ?? 110, x0: spec.grade?.x0 ?? 20, y0: spec.grade?.y0 ?? 30 };
  const porId = {};
  for (const n of nos) {
    n.w ??= 160;
    n.h ??= 58;
    if (n.x === undefined && n.col !== undefined) n.x = g.x0 + n.col * g.col;
    if (n.y === undefined && n.lin !== undefined) n.y = g.y0 + n.lin * g.lin;
    if (n.x === undefined || n.y === undefined) erros.push(`diagrama ${contDg}: nó "${n.id}" sem posição (x/y ou col/lin)`);
    if (!KINDS[n.k ?? 'agente']) erros.push(`diagrama ${contDg}: nó "${n.id}" com k "${n.k}" inválido; use ${Object.keys(KINDS).join(', ')}`);
    if (porId[n.id]) erros.push(`diagrama ${contDg}: id de nó repetido "${n.id}"`);
    porId[n.id] = n;
  }
  const largura = spec.largura ?? Math.max(...nos.map((n) => n.x + n.w)) + 20;
  const altura = spec.altura ?? Math.max(...nos.map((n) => n.y + n.h)) + 30;
  const passos = Math.max(0, ...nos.map((n) => n.step ?? 0), ...arestas.map((e) => e.step ?? 0));
  const titulo = spec.titulo || 'Diagrama';
  const css = `.${p} text{font-family:"Segoe UI Variable Text","Segoe UI",system-ui,Helvetica,Arial,sans-serif}
.${p} .t{font-size:14px;font-weight:650;fill:#f0f1f5}
.${p} .st{font-size:11.5px;font-family:"Cascadia Mono",Consolas,monospace}
.${p} .el{font-size:11.5px;fill:#a7a8ac;font-family:"Cascadia Mono",Consolas,monospace}
.${p} .ln{fill:none;stroke-width:2;stroke-dasharray:1;stroke-dashoffset:1}
.${p} .tracejada .ln{stroke-dasharray:.02 .015;stroke-dashoffset:0;animation:none!important}
.${p} .pulso{animation:${p}pulse 2.4s ease-in-out infinite}
@keyframes ${p}pulse{0%,100%{stroke:#cc092f}50%{stroke:#ff6b86;filter:drop-shadow(0 0 6px rgba(225,23,63,.75))}}
.${p} .pulso-a{animation:${p}pulsea 2.4s ease-in-out infinite}
@keyframes ${p}pulsea{0%,100%{stroke:#e1173f}50%{stroke:#ffbc00;filter:drop-shadow(0 0 6px rgba(255,188,0,.6))}}
${keyframes(p, passos)}
@media (prefers-reduced-motion:reduce){.${p} *{animation:none!important}.${p} .ln{stroke-dashoffset:0}.${p} .pac{display:none}}`;
  const out = [
    `<svg xmlns="http://www.w3.org/2000/svg" class="${p}" viewBox="0 0 ${largura} ${altura}" role="img" aria-label="${escAttr(titulo)}"><title>${esc(titulo)}</title>`,
    `<style>${css}</style><defs>`,
  ];
  for (const [nm, cor] of Object.entries(CORES)) {
    out.push(`<marker id="${p}-m${nm}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="${cor}"/></marker>`);
  }
  out.push('</defs>', `<rect width="${largura}" height="${altura}" rx="18" fill="#121212"/>`);

  arestas.forEach((e, i) => {
    const a = porId[e.de];
    const b = porId[e.para];
    if (!a || !b) {
      erros.push(`diagrama ${contDg}: aresta ${i + 1} liga "${e.de}" a "${e.para}", e um dos dois não existe`);
      return;
    }
    const d = e.d || caminho(a, b);
    const c = CORES[e.cor ?? 'r'] ? e.cor ?? 'r' : 'r';
    out.push(`<g class="s${e.step ?? 0}${e.tracejada ? ' tracejada' : ''}">`);
    out.push(`<path id="${p}-e${i}" class="ln" pathLength="1" d="${d}" stroke="${CORES[c]}" marker-end="url(#${p}-m${c})"/>`);
    if (e.rotulo) {
      let [lx, ly] = [e.rx, e.ry];
      if (lx === undefined) [lx, ly] = meio(d);
      out.push(`<text class="el" x="${lx}" y="${ly}" text-anchor="middle">${esc(e.rotulo)}</text>`);
    }
    if (e.pacote !== false && !e.tracejada) {
      out.push(`<circle class="pac" r="3.6" fill="${CORES[c]}"><animateMotion dur="${e.dur ?? 2.2}s" begin="${((i % 5) * 0.35).toFixed(2)}s" repeatCount="indefinite"><mpath href="#${p}-e${i}"/></animateMotion></circle>`);
    }
    out.push('</g>');
  });

  for (const n of nos) {
    const k = KINDS[n.k ?? 'agente'] || KINDS.agente;
    const { x, y, w, h } = n;
    const pulso = n.destaque ? (n.k === 'alerta' ? ' class="pulso-a"' : ' class="pulso"') : '';
    const trac = n.tracejado ? ' stroke-dasharray="6 5"' : '';
    out.push(`<g class="s${n.step ?? 0}">`);
    out.push(`<rect${pulso} x="${x}" y="${y}" width="${w}" height="${h}" rx="12" fill="${k.fill}" stroke="${k.stroke}" stroke-width="1.8"${trac}/>`);
    const cx = x + w / 2;
    if (n.s) {
      out.push(`<text class="t" x="${cx}" y="${y + h / 2 - 3}" text-anchor="middle">${esc(n.t ?? n.id)}</text>`);
      out.push(`<text class="st" x="${cx}" y="${y + h / 2 + 15}" text-anchor="middle" fill="${k.sub}">${esc(n.s)}</text>`);
    } else {
      out.push(`<text class="t" x="${cx}" y="${y + h / 2 + 5}" text-anchor="middle">${esc(n.t ?? n.id)}</text>`);
    }
    if (n.x_riscado) {
      out.push(`<path d="M${x + 8} ${y + 8}L${x + w - 8} ${y + h - 8}M${x + w - 8} ${y + 8}L${x + 8} ${y + h - 8}" stroke="#e1173f" stroke-width="2.5" opacity=".85"/>`);
    }
    const larg = Math.max((n.t ?? '').length * 8.2, (n.s ?? '').length * 7) + 16;
    if (larg > w) avisos.push(`diagrama ${contDg}: o texto do nó "${n.id}" provavelmente não cabe em w=${w}; use w>=${Math.ceil(larg / 10) * 10}`);
    out.push('</g>');
  }
  for (const f of spec.legenda || []) {
    const cor = f.cor || '#a7a8ac';
    out.push(`<g class="s${f.step ?? 0}"><text x="${f.x}" y="${f.y}" class="el" text-anchor="${f.ancora || 'start'}" style="fill:${cor}">${esc(f.texto)}</text></g>`);
  }
  out.push('</svg>');
  return out.join('\n');
}

// ------------------------------------------------------------------ estrutura
let idAba = 0;
function abas(inner) {
  const paineis = [...inner.matchAll(/<div class="painel"([^>]*)>([\s\S]*?)<\/div>\s*<!--\s*\/painel\s*-->/g)];
  if (!paineis.length) {
    erros.push('grupo de abas sem painéis: cada painel é <div class="painel" data-aba="..."> ... </div><!-- /painel -->');
    return inner;
  }
  const g = ++idAba;
  const botoes = [];
  const corpos = [];
  paineis.forEach((m, i) => {
    const a = attrs(m[1]);
    const nome = a['data-aba'] || `Aba ${i + 1}`;
    const sel = i === 0;
    botoes.push(`<button role="tab" id="ab${g}-${i}" aria-controls="pn${g}-${i}" aria-selected="${sel}"${sel ? '' : ' tabindex="-1"'}>${esc(nome)}</button>`);
    corpos.push(`<div class="painel${sel ? ' ativo' : ''}" id="pn${g}-${i}" role="tabpanel" aria-labelledby="ab${g}-${i}"><h3 class="titulo-painel">${esc(nome)}</h3>${m[2]}</div>`);
  });
  return `<div class="abas" role="tablist">${botoes.join('')}</div>${corpos.join('\n')}`;
}

function etapas(inner) {
  const arts = [...inner.matchAll(/<article class="etapa"([^>]*)>/g)];
  let i = 0;
  const itens = [];
  const corpo = inner.replace(/<article class="etapa"([^>]*)>/g, (_, at) => {
    const a = attrs(at);
    const id = a.id || `etapa-${++i}`;
    itens.push(`<li><a href="#${id}">${esc(a['data-rotulo'] || id)}<span class="q">${esc(a['data-sub'] || '')}</span></a></li>`);
    return `<article class="etapa" id="${id}">`;
  });
  if (!arts.length) erros.push('<div class="etapas"> sem <article class="etapa" data-rotulo="...">');
  return `<div class="fluxo"><nav class="trilho-lateral" aria-label="Etapas"><ol>${itens.join('')}</ol></nav><div>${corpo}</div></div>`;
}

// ------------------------------------------------------------------ montagem
function montar(fonte) {
  let src = fonte;

  const metaM = src.match(/<meta-doc([^>]*)\/?>/);
  if (!metaM) erros.push('falta <meta-doc titulo="..." marca="..."> no topo da fonte');
  const meta = attrs(metaM?.[1] || '');
  src = src.replace(/<meta-doc[^>]*\/?>/, '');

  // código e diagramas primeiro: o conteúdo deles é texto cru
  src = src.replace(/<script type="text\/x-codigo"([^>]*)>([\s\S]*?)<\/script>/g, (_, at, corpo) => {
    const a = attrs(at);
    return bloco(a['data-lang'] || 'saida', a['data-rotulo'] || a['data-lang'] || 'código', corpo);
  });
  src = src.replace(/<script type="application\/x-diagrama"([^>]*)>([\s\S]*?)<\/script>/g, (_, at, corpo) => {
    let spec;
    try {
      spec = JSON.parse(corpo);
    } catch (e) {
      erros.push(`diagrama ${contDg + 1}: JSON inválido (${e.message})`);
      contDg++;
      return '';
    }
    const leg = spec.legendaCores === false ? '' :
      '<figcaption><span class="lg ag">agente</span><span class="lg vc">pessoa</span><span class="lg dd">dado</span></figcaption>';
    return `<figure class="diagrama">${diagrama(spec)}${spec.legendaCores ? leg : ''}</figure>`;
  });
  if (/<script(?![^>]*type="(?:text\/x-codigo|application\/x-diagrama)")/.test(src)) {
    erros.push('a fonte tem <script> próprio: o comportamento vem do casco, não da fonte');
  }

  src = src.replace(/<div class="abas-grupo">([\s\S]*?)<\/div>\s*<!--\s*\/abas-grupo\s*-->/g, (_, inner) => abas(inner));
  src = src.replace(/<div class="etapas">([\s\S]*?)<\/div>\s*<!--\s*\/etapas\s*-->/g, (_, inner) => etapas(inner));

  // hero
  let hero = '';
  src = src.replace(/<header class="hero">([\s\S]*?)<\/header>/, (_, inner) => {
    hero = `<div class="hero" id="inicio"><div class="wrap">${inner}</div></div>`;
    return '';
  });

  // seções: numeração, navegação, faixa larga
  const nav = [];
  let num = 0;
  src = src.replace(/<section([^>]*)>([\s\S]*?)<\/section>/g, (_, at, inner) => {
    const a = attrs(at);
    if (!a.id) erros.push(`seção sem id: ${inner.slice(0, 60).replace(/\s+/g, ' ')}`);
    const rotulo = a['data-nav'];
    if (rotulo) nav.push(`<a href="#${a.id}">${esc(rotulo)}</a>`);
    const n = a['data-num'] === 'nao' ? '' : `<span class="secao-num">${++num}</span>`;
    const faixa = (a.class || '').split(/\s+/).includes('faixa');
    const corpo = n + inner;
    return faixa
      ? `<section id="${a.id}" class="${a.class}"><div class="wrap">${corpo}</div></section>`
      : `<section id="${a.id}" class="wrap ${a.class || ''}">${corpo}</section>`;
  });
  if (!nav.length) avisos.push('nenhuma <section> com data-nav: a barra de navegação fica vazia');

  // logo e favicon
  const logoPath = meta.logo ? resolve(dirname(ARQ_FONTE), meta.logo) : LOGO_PADRAO;
  if (!existsSync(logoPath)) erros.push(`logo não encontrada: ${logoPath}`);
  const logoSvg = existsSync(logoPath) ? readFileSync(logoPath, 'utf8').trim() : '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#cc092f"/></svg>';
  const viewBox = (logoSvg.match(/viewBox="([^"]+)"/) || [, '0 0 64 64'])[1];
  const interno = logoSvg.replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '').replace(/<title>[\s\S]*?<\/title>/, '');
  const favicon = 'data:image/svg+xml,' + encodeURIComponent(logoSvg.replace(/<title>[\s\S]*?<\/title>/, '')).replace(/'/g, '%27');

  const marca = meta.marca || 'HenriSpec';
  const corte = meta['marca-destaque'] ?? (marca.match(/[A-Z][a-z]+$/)?.[0] || '');
  const marcaHtml = corte && marca.endsWith(corte)
    ? `${esc(marca.slice(0, -corte.length))}<span class="spec">${esc(corte)}</span>`
    : esc(marca);

  let base = readFileSync(BASE, 'utf8');
  const troca = {
    TITULO: esc(meta.titulo || marca),
    DESCRICAO: escAttr(meta.descricao || ''),
    FAVICON: favicon,
    LOGO_VIEWBOX: viewBox,
    LOGO: interno,
    MARCA: marcaHtml,
    VERSAO: esc(meta.versao || ''),
    NAV: nav.join('\n      '),
    HERO: hero,
    CONTEUDO: src.trim(),
    RODAPE: esc(meta.rodape || `${marca}${meta.versao ? ' ' + meta.versao : ''}.`),
  };
  for (const [k, v] of Object.entries(troca)) base = base.split(`{{${k}}}`).join(v);
  const resto = base.match(/\{\{[A-Z_]+\}\}/);
  if (resto) erros.push(`marcador não substituído no casco: ${resto[0]}`);
  return base;
}

// ------------------------------------------------------------------ main
const [, , ARQ_FONTE, ARQ_SAIDA] = process.argv;
if (!ARQ_FONTE) {
  console.error('uso: node montar.mjs <fonte.html> [saida.html]');
  process.exit(2);
}
if (!existsSync(ARQ_FONTE)) {
  console.error(`fonte não encontrada: ${ARQ_FONTE}`);
  process.exit(2);
}
const saidaPath = ARQ_SAIDA || join(dirname(ARQ_FONTE), basename(ARQ_FONTE).replace(/\.fonte\.html$|\.html$/, '') + '.html');
if (resolve(saidaPath) === resolve(ARQ_FONTE)) {
  console.error('a saída não pode ser a própria fonte');
  process.exit(2);
}
const final = montar(readFileSync(ARQ_FONTE, 'utf8'));
for (const a of avisos) console.log(`AVISO ${a}`);
if (erros.length) {
  for (const e of erros) console.error(`ERRO  ${e}`);
  console.error(`\n${erros.length} erro(s). Nada foi gravado.`);
  process.exit(1);
}
writeFileSync(saidaPath, final);
console.log(`ok: ${saidaPath} (${Math.round(final.length / 1024)} KB, ${contDg} diagrama(s))`);

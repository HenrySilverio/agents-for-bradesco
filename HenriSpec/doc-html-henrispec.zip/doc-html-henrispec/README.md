# doc-html-henrispec

Skill que gera documentos HTML de página única no padrão visual HenriSpec. Formato aberto de
Agent Skills: a mesma pasta funciona no GitHub Copilot (VS Code) e no Antigravity.

## Instalar

Uma cópia na pasta `.agents/skills/` do repositório serve aos dois:

```bash
mkdir -p .agents/skills
cp -r "<pasta-baixada>/doc-html-henrispec" .agents/skills/
```

Para usar em todos os projetos da máquina:

| Ferramenta | Pasta do usuário |
| --- | --- |
| GitHub Copilot no VS Code | `~/.copilot/skills/` ou `~/.agents/skills/` |
| Antigravity | `~/.gemini/config/skills/` (versões antigas: `~/.gemini/antigravity/skills/`) |

Requer Node 18 ou mais. Não usa rede nem npm.

## Usar

Peça em linguagem natural, por exemplo: "crie um onboarding em HTML para o BFF de limites".
No Copilot também dá para chamar com `/doc-html-henrispec`.

O agente escreve `docs/<nome>.fonte.html` e roda o montador:

```bash
node .agents/skills/doc-html-henrispec/scripts/montar.mjs docs/<nome>.fonte.html docs/<nome>.html
```

Para mudar o documento depois, edite a fonte e rode o montador de novo.

## Conteúdo

| Caminho | Papel |
| --- | --- |
| `SKILL.md` | fluxo que o agente segue |
| `references/componentes.md` | catálogo de componentes da fonte |
| `references/diagramas.md` | esquema dos diagramas animados |
| `scripts/montar.mjs` | montador: fonte para HTML final |
| `assets/base.html` | casco com CSS e JavaScript |
| `assets/logo.svg` | logo e favicon padrão |
| `assets/exemplo.fonte.html` | fonte de exemplo com todos os componentes |

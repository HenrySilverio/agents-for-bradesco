---
name: init
description: "Prepara o repositório aberto para o HenriSpec: cria .sdd/ e docs/briefings/, atualiza a camada do repositório e remove cópias antigas do toolkit que fariam sombra ao plugin."
argument-hint: "[caminho do repositório, se houver mais de um aberto]"
disable-model-invocation: true
---

# /henrispec:init

Prepara o repositório para o fluxo. Roda em qualquer agente, num chat novo.

1. Chame `henrispec/status` e mostre o resultado em até quatro linhas. Se houver mais de um
   repositório aberto e o usuário não disse qual, pergunte e pare.
2. Chame `henrispec/init` **sem** `aplicar`. Mostre o plano como veio: ele lista o que será
   criado, mantido e removido, e marca `CONFLITO` em arquivo alterado à mão.
3. Se houver `CONFLITO`, explique que nada será gravado até o usuário decidir, e que
   `forcar=true` sobrescreve com backup em `.sdd/.toolkit-backup/`. Não use `forcar` sem que o
   usuário peça.
4. Pergunte se pode aplicar. Só com um sim explícito, chame `henrispec/init` com
   `aplicar=true`.
5. Feche em até seis linhas: o que mudou; que `.sdd/verificacao.json` nasce com as camadas de um
   MFE Angular e precisa ser ajustado ao projeto; e o commit a fazer:

```
git add .sdd docs
git commit -m "chore: prepara repositório para o HenriSpec"
```

Não comite, não crie branch e não edite nenhum arquivo além do que a ferramenta grava.

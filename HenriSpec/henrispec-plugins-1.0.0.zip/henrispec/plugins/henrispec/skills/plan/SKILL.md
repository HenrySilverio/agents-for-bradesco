---
name: plan
description: "Atalho do comando /henrispec:plan. A etapa roda no agente sdd-plan."
argument-hint: "<caminho do briefing.md> [replanejar: <change-id>] [contexto]"
disable-model-invocation: true
---

# /henrispec:plan

Esta etapa roda no agente `sdd-plan`, que fixa o modelo e as ferramentas dela.

Se as instruções deste chat começam com `# Agente sdd-plan`, siga-as usando o texto que veio depois
do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `sdd-plan` no
seletor de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a etapa fora do agente
troca o modelo dela e libera ferramentas que ela não deveria ter.

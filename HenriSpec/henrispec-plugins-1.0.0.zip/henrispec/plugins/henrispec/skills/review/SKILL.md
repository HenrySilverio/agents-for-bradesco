---
name: review
description: "Atalho do comando /henrispec:review. A etapa roda no agente sdd-review."
argument-hint: "<change-id> [eixo=padroes|spec]"
disable-model-invocation: true
---

# /henrispec:review

Esta etapa roda no agente `sdd-review`, que fixa o modelo e as ferramentas dela.

Se as instruções deste chat começam com `# Agente sdd-review`, siga-as usando o texto que veio depois
do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `sdd-review` no
seletor de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a etapa fora do agente
troca o modelo dela e libera ferramentas que ela não deveria ter.

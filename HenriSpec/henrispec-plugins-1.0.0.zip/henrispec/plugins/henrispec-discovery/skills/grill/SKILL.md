---
name: grill
description: "Atalho do comando /henrispec-discovery:grill. A etapa roda no agente discovery-grill."
argument-hint: "<necessidade em uma ou duas frases>"
disable-model-invocation: true
---

# /henrispec-discovery:grill

Esta etapa roda no agente `discovery-grill`, que fixa o modelo e as ferramentas dela.

Se as instruções deste chat começam com `# Agente discovery-grill`, siga-as usando o texto que veio depois
do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `discovery-grill` no
seletor de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a etapa fora do agente
troca o modelo dela e libera ferramentas que ela não deveria ter.

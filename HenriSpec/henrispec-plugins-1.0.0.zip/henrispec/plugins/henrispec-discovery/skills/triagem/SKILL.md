---
name: triagem
description: "Atalho do comando /henrispec-discovery:triagem. A etapa roda no agente discovery-triagem."
argument-hint: "<caminho ou texto do ticket>"
disable-model-invocation: true
---

# /henrispec-discovery:triagem

Esta etapa roda no agente `discovery-triagem`, que fixa o modelo e as ferramentas dela.

Se as instruções deste chat começam com `# Agente discovery-triagem`, siga-as usando o texto que veio depois
do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `discovery-triagem` no
seletor de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a etapa fora do agente
troca o modelo dela e libera ferramentas que ela não deveria ter.

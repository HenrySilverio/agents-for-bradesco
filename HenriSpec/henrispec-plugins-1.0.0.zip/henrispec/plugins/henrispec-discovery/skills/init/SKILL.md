---
name: init
description: "Prepara o repositório para o HenriSpec Discovery: cria docs/briefings/ e docs/prototipos/ e remove cópias antigas do toolkit que fariam sombra ao plugin."
argument-hint: "[caminho do repositório, se houver mais de um aberto]"
disable-model-invocation: true
---

# /henrispec-discovery:init

Prepara o repositório para o discovery. Roda em qualquer agente, num chat novo.

1. Chame `henrispec-discovery/status` e mostre o resultado em até quatro linhas. Se houver mais de um
   repositório aberto e o usuário não disse qual, pergunte e pare.
2. Chame `henrispec-discovery/init` **sem** `aplicar`. Mostre o plano como veio: ele lista o que será
   criado, mantido e removido, e marca `CONFLITO` em arquivo alterado à mão.
3. Se houver `CONFLITO`, explique que nada será gravado até o usuário decidir, e que
   `forcar=true` sobrescreve com backup em `docs/henrispec-discovery/.backup/`. Não use `forcar` sem que o
   usuário peça.
4. Pergunte se pode aplicar. Só com um sim explícito, chame `henrispec-discovery/init` com
   `aplicar=true`.
5. Feche em até seis linhas: o que mudou e o commit a fazer:

```
git add docs
git commit -m "chore: prepara repositório para o HenriSpec Discovery"
```

Não comite, não crie branch e não edite nenhum arquivo além do que a ferramenta grava.

---
name: sdd-archive
description: "Atalho de compatibilidade do comando /sdd-archive do fluxo SDD. A etapa roda no agente sdd-archive."
argument-hint: "<change-id>"
disable-model-invocation: true
---

# /sdd-archive

Esta etapa roda no agente `sdd-archive`, que fixa o modelo e as ferramentas dela.

Se as instruções deste chat começam com `# Agente sdd-archive`, siga-as usando o texto que veio depois
do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `sdd-archive` no
seletor de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a etapa fora do agente
troca o modelo dela e libera ferramentas que ela não deveria ter.

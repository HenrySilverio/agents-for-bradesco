---
name: sdd-implement
description: "Atalho de compatibilidade do comando /sdd-implement do fluxo SDD. A etapa roda no agente sdd-implement."
argument-hint: "<change-id> [contexto]"
disable-model-invocation: true
---

# /sdd-implement

Esta etapa roda no agente `sdd-implement`, que fixa o modelo e as ferramentas dela.

Se as instruções deste chat começam com `# Agente sdd-implement`, siga-as usando o texto que veio depois
do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `sdd-implement` no
seletor de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a etapa fora do agente
troca o modelo dela e libera ferramentas que ela não deveria ter.

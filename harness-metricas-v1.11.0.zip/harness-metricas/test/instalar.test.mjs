import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { RAIZ } from '../lib/config.mjs';

const CLI = join(RAIZ, 'bin', 'hm.mjs');
function rodar(args, cwd) {
  try {
    return { ok: true, saida: execFileSync(process.execPath, [CLI, ...args], { cwd, encoding: 'utf8', env: { ...process.env, HARNESS_METRICAS_DADOS: mkdtempSync(join(tmpdir(), 'hm-d-')) } }) };
  } catch (e) {
    return { ok: false, saida: `${e.stdout || ''}${e.stderr || ''}` };
  }
}

// Campo real: `hm instalar --workspace` sem valor escreveu o hook em `true/.github/hooks/`.
// resolve(String(true)) === <cwd>/true, e o mkdir recursivo criou a pasta sem reclamar.
test('--workspace sem caminho falha em vez de criar a pasta "true"', () => {
  const cwd = mkdtempSync(join(tmpdir(), 'hm-ws-'));
  const r = rodar(['instalar', '--workspace'], cwd);
  assert.equal(r.ok, false, 'tinha de sair com erro');
  assert.match(r.saida, /precisa do caminho/i);
  assert.ok(!existsSync(join(cwd, 'true')), 'não pode criar pasta chamada "true"');
  assert.deepEqual(readdirSync(cwd), [], 'nada pode ser escrito');
});

test('--workspace apontando para pasta que não é repositório é recusado', () => {
  const cwd = mkdtempSync(join(tmpdir(), 'hm-ws-'));
  const alvo = join(cwd, 'pasta-qualquer');
  mkdirSync(alvo);
  const r = rodar(['instalar', '--workspace', alvo], cwd);
  assert.equal(r.ok, false);
  assert.match(r.saida, /não parece um repositório git/i);
  assert.ok(!existsSync(join(alvo, '.github')), 'nada pode ser escrito');
});

test('--workspace num repositório de verdade escreve no lugar certo', () => {
  const cwd = mkdtempSync(join(tmpdir(), 'hm-ws-'));
  const repo = join(cwd, 'meu-repo');
  mkdirSync(join(repo, '.git'), { recursive: true });
  const r = rodar(['instalar', '--workspace', repo], cwd);
  assert.equal(r.ok, true, r.saida);
  assert.ok(existsSync(join(repo, '.github', 'hooks', 'harness-metricas.json')));
});

test('--workspace numa pasta inexistente avisa e não cria nada', () => {
  const cwd = mkdtempSync(join(tmpdir(), 'hm-ws-'));
  const r = rodar(['instalar', '--workspace', join(cwd, 'nao-existe')], cwd);
  assert.equal(r.ok, false);
  assert.match(r.saida, /não existe/i);
  assert.deepEqual(readdirSync(cwd), []);
});

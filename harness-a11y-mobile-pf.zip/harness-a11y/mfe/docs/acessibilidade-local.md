# Acessibilidade: como testar sem subir em HOM

Guia para quem está implementando uma tela. Nenhum passo exige HOM nem o app de contas.

## Conceitos em 1 minuto

- **Leitor de tela**: o app que fala o conteúdo da tela para quem não enxerga. TalkBack no Android, VoiceOver no iPhone. A pessoa navega deslizando o dedo: cada gesto vai para o próximo elemento.
- **Árvore de acessibilidade**: a versão da tela que o leitor de tela recebe. Para cada elemento, ela tem um **papel** (botão, título, texto), um **nome** (o que é falado) e um **estado** (marcado, expandido). O HTML gera essa árvore. É ela que testamos.
- **Anotação da designer**: o print com `[Botão]`, `[H1]`, `[Texto]` e a ordem numerada. É a especificação da árvore esperada.
- **Fixture**: um JSON salvo com a resposta do BFF, para testar a tela sem o BFF rodando.

## Quem é dono do texto falado

| A tela... | O texto falado vem de... | Se estiver errado, corrija em... |
|---|---|---|
| vem do BFF (tem `tag` `TELA_...`) | campos `acessibilidade` / `texto_leitor` do JSON | FTL do BFF |
| é montada só no front | componente Angular | front |

Papel (botão, título), ordem, foco e `aria-*` são sempre do front.

## Nível 0 — checagem estática (menos de 1 segundo)

```bash
node tools/a11y/a11y-check.mjs src/app/caminho/do/componente
```

Aponta erros conhecidos com linha e correção. Exemplo:

```
card-lista-dividas.component.html:6  [ERRO A02] tabindex="0" em <div role="heading"> não interativo → remova o tabindex
```

Com o Copilot, isso roda sozinho a cada arquivo que o agente edita (hook).

## Nível 1 — teste do componente (~10 segundos)

```bash
npx jest a11y.spec
```

Roda no Jest que o time já usa. Testa um componente isolado: "existe um título nível 2 com este texto?". Modelo em `exemplos/card-lista-dividas.component.a11y.spec.ts`.

O Jest roda em **jsdom**, um navegador simulado que não calcula layout nem aplica CSS. Ele confere papel, nome, nível e estado, mas não confere ordem visual nem contraste; isso fica com o nível 2.

## Nível 2 — a tela inteira contra a anotação (~10 segundos)

```bash
npx playwright test -c e2e-a11y lista-dividas
```

Sobe o MFE sozinho (sem shell, sem BFF), responde as chamadas com a fixture e compara a árvore de acessibilidade com `e2e-a11y/telas/__aria__/lista-dividas.aria.yml`.

Quando falha, o terminal mostra um diff (exemplo simplificado):

```
- heading "Empréstimo Var. Valor 1 , contrato 9 0 0 0 0 0" [level=2]   ← esperado (anotação)
+ heading "Contrato 9 0 0 0 0 0, Empréstimo Var. Valor 1" [level=2]   ← o que a tela tem
```

Também roda o **axe-core**, que acusa violações WCAG (contraste, imagem sem `alt`...). Atenção: **axe passar não significa que está acessível**. O card original, com leitura duplicada e foco em título, passa no axe. Quem pega esses problemas é o `.aria.yml`.

**Tela nova:** copie `lista-dividas.a11y.pw.ts`, rode com `--update-snapshots` para gerar o `.aria.yml`, **compare linha a linha com a anotação** e só então faça o commit. Se preferir, a skill `a11y-spec-from-annotation` gera o `.aria.yml` a partir do print.

**Fixture nova:** com MFE e BFF rodando localmente, abra DevTools > Network, clique na chamada da tela > Response, copie e salve em `src/testing/a11y/fixtures/<TAG>.json`.

## Nível 3 — ouvir de verdade (opcional, antes de HOM)

**No navegador (sempre disponível):** Chrome/Edge > DevTools > Elements > aba **Accessibility**. Clique no ícone de árvore ("Switch to Accessibility Tree view") para ver a tela inteira como o leitor recebe.

**TalkBack real (Android):** requer Android Studio (confirme se é permitido na sua máquina).
1. Crie um emulador com Google Play e ative TalkBack em Configurações > Acessibilidade.
2. Com `ng serve` rodando, abra no Chrome do emulador: `http://10.0.2.2:4200/<rota>` (`10.0.2.2` é o seu computador visto de dentro do emulador).
3. Deslize para a direita para ir ao próximo elemento. Compare o que é falado com a anotação.

**VoiceOver (iOS):** exige Mac com Xcode (Simulator + Accessibility Inspector). Sem Mac, fique no nível 2 e valide no iPhone em HOM.

## O que só HOM mostra

Foco inicial ao abrir a WebView e o título nativo do app de contas. Faça **uma** validação em HOM no final, e não a cada mudança.

## Comandos úteis para o `package.json`

```json
"a11y": "node tools/a11y/a11y-check.mjs src/app",
"a11y:e2e": "playwright test -c e2e-a11y",
"a11y:e2e:atualizar": "playwright test -c e2e-a11y --update-snapshots"
```

// Trechos para o card-lista-dividas.component.ts e .scss. Não é um componente completo.

// ---- .ts ------------------------------------------------------------------------------------
// Contrato lido dígito a dígito ("9 0 0 0 0 0"), não como número ("novecentos mil").
get contratoLeitura(): string {
  return (this.lista?.cabecalho?.titulo ?? '').replace(/\D/g, '').split('').join(' ');
}

// Regra de ownership: se o BFF mandou texto_leitor, ele é o dono do texto. O fallback do front
// só roda quando TODOS vierem null — e é aqui que o layout em grade vira frase linear.
get corpoAcessibilidade(): string {
  const itens = this.lista?.corpo?.itens ?? [];
  const doBff = itens
    .flatMap((i) => [i?.texto_esquerda?.texto_leitor, i?.texto_direita?.texto_leitor])
    .filter((t): t is string => !!t?.trim());
  if (doBff.length) return doBff.join('. ');
  return this.corpoLeituraFallback(itens); // mantém a lógica que o time já tem hoje
}

// ---- .scss ----------------------------------------------------------------------------------
// .squad-sr-only {
//   position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
//   overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; border: 0;
// }
// h2 e p trazem margem padrão do navegador; zere para não mudar o visual ao trocar a <div>:
// .squad-card-dividas h2, .squad-card-dividas p { margin: 0; }

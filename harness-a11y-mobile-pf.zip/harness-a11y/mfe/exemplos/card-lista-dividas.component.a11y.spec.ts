// Nível 1: roda no Jest que o time já usa (jsdom), em segundos, sem servidor nem browser.
// Pré-requisitos:
//   npm i -D @testing-library/angular@^17 @testing-library/dom@^10
//   tsconfig.spec.json → "compilerOptions": { "resolveJsonModule": true }
// AJUSTE: caminhos de import conforme a pasta do componente.
//
// Limite do jsdom: não calcula layout nem aplica o SCSS do componente. Ordem visual, contraste
// e sobreposição ficam para o nível 2 (Playwright). Aqui entram papel, nome, nível e estado.
import { render, screen } from '@testing-library/angular';
import { CardListaDividasComponent } from './card-lista-dividas.component';
import resposta from '../../../testing/a11y/fixtures/TELA_LISTA_DIVIDAS_COMPOR_BRADESCO.json';

// AJUSTE: troque `any` pela interface do modelo do card, se existir.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const lista: any = resposta.dados.lista_dividas[0];

const renderizar = (l = lista) => render(CardListaDividasComponent, { inputs: { lista: l, indice: 0 } });

describe('CardListaDividasComponent: acessibilidade', () => {
  it('expõe o card como heading nível 2 com descrição e contrato dígito a dígito', async () => {
    await renderizar();
    // getByRole calcula o nome acessível como o navegador (dom-accessibility-api).
    // `\s?` antes da vírgula: o cálculo insere espaço na fronteira do <span> oculto; TalkBack/VoiceOver leem igual.
    expect(
      screen.getByRole('heading', { level: 2, name: /^Empréstimo Var\. Valor 1\s?, contrato 9 0 0 0 0 0$/ }),
    ).toBeTruthy();
  });

  it('não cria paradas de foco em elementos não interativos', async () => {
    const { container } = await renderizar();
    const intrusos = [...container.querySelectorAll('[tabindex="0"]:not(a,button,input,select,textarea)')];
    // Mensagem útil na falha: mostra QUAIS elementos, não só "expected 0, received 2".
    expect(intrusos.map((e) => e.outerHTML.slice(0, 80))).toEqual([]);
  });

  it('tem frase de leitura do corpo, sem "R$ … reais"', async () => {
    const { container } = await renderizar();
    const leitura = container.querySelector('.squad-card-dividas__corpo .squad-sr-only')?.textContent?.trim() ?? '';
    expect(leitura).not.toBe('');
    expect(leitura).not.toMatch(/R\$\s*[\d.,]+\s*reais/i);
  });

  it('grade visual do corpo fica fora da árvore de acessibilidade', async () => {
    await renderizar();
    // Se a grade vazar, o leitor fala "R$ 12.000,00, Economize, R$ 10.800,00…" fora de contexto.
    // getByText NÃO respeita aria-hidden (acha o texto de qualquer forma), então checamos o ancestral.
    expect(screen.getByText('Economize').closest('[aria-hidden="true"]')).not.toBeNull();
  });

  it('checkbox, quando existe, tem nome acessível', async () => {
    const comCheckbox = { ...lista, cabecalho: { ...lista.cabecalho, checkbox: { value: false, readonly: false } } };
    await renderizar(comCheckbox);
    expect(screen.getByRole('checkbox', { name: /.+/ })).toBeTruthy();
  });
});

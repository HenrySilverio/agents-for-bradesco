# Mapa: marcação da anotação → ARIA snapshot

| Anotação | `.aria.yml` | HTML esperado |
|---|---|---|
| `Voltar [Botão]` (ícone) | `- button "Voltar"` | `<button type="button" aria-label="Voltar">` |
| `[Botão]` com "Exemplo de leitura" | `- button "<exemplo de leitura>"` | `aria-label` só se o texto visível não bastar |
| `[Titulo]` (barra superior) | `- text: <título>` (ou `heading [level=1]` se a designer confirmar) | depende do `app-cabecalho` |
| `[H1]` / `[H2]` / `[H3]` | `- heading "<texto>" [level=N]` | `<h1>`–`<h3>` nativo |
| `[Texto]` | `- paragraph: <texto>` ou `- text: <texto>` | `<p>` / texto |
| `[Texto]` com "Exemplo de leitura" | `- paragraph: "<exemplo>"` | `<p class="squad-sr-only">` + visual `aria-hidden` |
| `<recolhido>[Botão expansivo]` | `- button "<texto>" [expanded=false]` | `<button aria-expanded="false">` |
| `<1 de 2>[Botão]` (carrossel) | `- group "1 de 2":` + filho `- button "..."` | `role="group" aria-roledescription="slide" aria-label="1 de 2"` |
| Card repetido | `- list:` → `- listitem:` | `<ul role="list"><li>` |
| Checkbox | `- checkbox "<nome>" [checked=false]` | `<input type="checkbox" aria-label>` |
| Imagem decorativa | (não aparece) | `aria-hidden="true"` ou `alt=""` |

Formato: https://playwright.dev/docs/aria-snapshots — o match é parcial: atributo omitido não é checado, então liste os que a anotação exige (`level`, `expanded`, `checked`).

Texto dentro de heading com `<span>` oculto aparece com espaço antes da vírgula (`"Valor 1 , contrato"`). É normalização do Playwright; TalkBack/VoiceOver leem normal.

---
name: a11y-spec-from-annotation
description: Converte a anotação de acessibilidade da designer (print do Figma com [Botão], [H1], [Texto], ordem numerada, "Exemplo de leitura") em um arquivo .aria.yml testável pelo Playwright. Use quando alguém anexar a anotação de uma tela ou pedir a spec/snapshot de acessibilidade de uma tela.
---
# Anotação → `.aria.yml`

A anotação da designer já é uma especificação. Este playbook a transforma em teste.

## Entrada
- Print da anotação (obrigatório). Se não houver, peça e pare.
- Tag da tela (`TELA_...`) ou nome do componente, para saber se o texto vem do BFF ou do front.

## Passos
1. Liste os elementos na ORDEM numerada da anotação (1, 2, 3…). A ordem da anotação é a ordem de leitura esperada.
2. Converta cada um usando [mapa-anotacao-aria.md](references/mapa-anotacao-aria.md).
3. Onde houver "Exemplo de leitura", o texto do nó é esse exemplo — não o texto visível.
4. Agrupe na hierarquia real: `banner` (cabeçalho), `main`, `list`/`listitem` para cards repetidos.
5. Valores monetários e números: literais. Nunca regex — o texto lido é o que está sob teste.
6. Salve em `e2e-a11y/telas/__aria__/<tela>.aria.yml` e crie o `<tela>.a11y.pw.ts` copiando `lista-dividas.a11y.pw.ts` (ajuste rota e fixture).

## Revise a anotação antes de aceitar (a designer também erra)
Aponte, sem corrigir por conta própria:
- "R$ X Reais" → leitura duplicada.
- Estado escrito no texto ("<recolhido>") → deve ser `[expanded=false]`, não parte do nome.
- Dois `[level=1]` na mesma tela (título da barra + H1 do conteúdo).
- Número de contrato sem indicação de leitura dígito a dígito.
- Dados de exemplo contraditórios (ex.: "20 de 50" e "21 de 40 parcelas").

## Saída
1. O `.aria.yml`.
2. Tabela curta: nº da anotação → linha do yml → dono do texto (BFF/front).
3. Lista de problemas na anotação para levar à designer.

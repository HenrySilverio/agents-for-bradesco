---
applyTo: "src/app/**/*.html,src/app/**/*.component.ts"
description: Regras de acessibilidade para templates e componentes Angular do MFE (TalkBack/VoiceOver em WebView)
---
# Acessibilidade — templates Angular

O app roda em WebView Android/iOS. Quem valida é TalkBack e VoiceOver, não teclado de desktop.

## Dono do texto de leitura
- Tela com `tag` vinda do BFF (FTL): o texto de leitura é do BFF (`acessibilidade`, `texto_leitor`). O front USA o campo; só monta fallback quando vier `null`. Nunca sobrescreva texto do BFF no front.
- Tela montada só no front: o componente é dono da semântica e do texto.
- Na dúvida sobre qual é o caso, pergunte antes de editar.

## Proibido (o `a11y-check` acusa)
- `role="heading"` em `div` → use `<h1>`–`<h6>`.
- `tabindex="0"` em elemento não interativo (heading, `div`, grupo). Leitor de tela navega por gesto sem ele.
- `aria-hidden="true"` em elemento focável.
- `(click)` em `div`/`span` → `<button type="button">`.
- `aria-label` em `div`/`span` sem role → texto oculto `.squad-sr-only`.
- Estado dentro do texto ("recolhido", "selecionado") → `aria-expanded`, `aria-checked`, `aria-selected`.
- "R$ 4.000,00 reais" → "R$" já é lido como "reais".
- `role="group"` nomeado pelo próprio heading → leitura duplicada.

## Padrões do projeto
- Heading com dado dinâmico: `@if (texto; as t) { <h1>{{ t }}</h1> }` — o BFF às vezes manda `""`.
- Lista de cards: `<ul role="list"><li>` (Safari remove semântica de lista sem `role`).
- Bloco visual em grade que não faz sentido lido linha a linha: frase em `<p class="squad-sr-only">` + grade inteira com `aria-hidden="true"`.
- Número de contrato/protocolo: lido dígito a dígito ("9 0 0 0 0 0").
- Botão só com ícone: `[attr.aria-label]` com o verbo ("Voltar", "Fechar").
- Exemplo completo: `exemplos/card-lista-dividas.component.html`.

## Ao terminar uma mudança
Rode `/a11y-verificar`. Snapshot `.aria.yml` só é atualizado depois de conferido contra a anotação da designer.

---
description: Implementa a acessibilidade de uma tela a partir da anotação da designer (anexe o print)
agent: a11y-implementador
---
Implemente a acessibilidade desta tela seguindo a anotação anexada.

Tela: ${input:tela:tag TELA_... ou nome do componente}

Se não houver print da anotação anexado, peça e pare.

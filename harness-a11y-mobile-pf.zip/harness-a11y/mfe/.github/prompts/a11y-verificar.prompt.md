---
description: Verifica localmente a acessibilidade de uma tela (níveis 0 a 2) e explica as falhas
tools: ['read', 'search', 'execute']
---
Use a skill `a11y-verificar` para a tela ${input:tela:nome do spec em e2e-a11y/telas, ex.: lista-dividas}.

Não edite arquivos. Termine com: nível que falhou, elemento divergente, onde corrigir (front ou FTL).

import type { Page } from '@playwright/test';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

// Fixtures = cópia versionada de respostas reais do BFF (nunca pacote compartilhado com o BFF).
// Para capturar uma nova: rode MFE + BFF locais, DevTools > Network > clique na chamada >
// Response > copie para src/testing/a11y/fixtures/<TAG>.json.
const FIXTURES = resolve(__dirname, '../../src/testing/a11y/fixtures');

// AJUSTE: trecho de URL que identifica chamadas ao BFF feitas pelo MFE.
export const PADRAO_URL_BFF = /\/(bff|api)\//i;

/**
 * Responde as chamadas ao BFF com fixtures.
 * @param respostas  chave = trecho procurado na URL OU no corpo da requisição (ex.: a tag da tela)
 *                   valor = nome do arquivo em src/testing/a11y/fixtures
 * Chamada sem fixture falha com 501 — de propósito: teste de acessibilidade nunca bate no BFF real.
 */
export async function mockBff(page: Page, respostas: Record<string, string>): Promise<void> {
  await page.route(PADRAO_URL_BFF, async (route) => {
    const req = route.request();
    const alvo = `${req.url()} ${req.postData() ?? ''}`;
    const chave = Object.keys(respostas).find((k) => alvo.includes(k));
    if (!chave) {
      await route.fulfill({ status: 501, body: `mock-bff: sem fixture para ${req.method()} ${req.url()}` });
      return;
    }
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: readFileSync(resolve(FIXTURES, respostas[chave]), 'utf8'),
    });
  });
}

---
description: Revisa a acessibilidade do JSON gerado por um FTL e cria o cenário de teste que faltar
tools: ['read', 'search', 'edit', 'execute']
---
FTL: ${input:ftl:nome do arquivo .ftl}

1. Rode `node tools/a11y/a11y-check.mjs` no FTL.
2. Se não existir cenário em `src/test/resources/a11y/cenarios/` para cada ramo `<#if>` do FTL, crie (use dados com acento e aspas — é o que quebra escape).
3. Rode `mvn test -Dtest=A11yContratoFtlTest -Da11y.modo=erro`.
4. Corrija só o que é do FTL. Se a correção exigir campo novo no contrato, NÃO crie: liste o campo proposto e o impacto no MFE.

Saída: achados antes → depois, cenários criados, campos de contrato propostos.

---
applyTo: "**/*.ftl"
description: Regras para FTL que gera JSON de tela (server-driven) — escape e contrato de acessibilidade
---
# FTL → JSON de tela

Este FTL gera JSON que o MFE renderiza. O BFF é dono do layout E do texto que o leitor de tela fala.

## Obrigatório
- Toda interpolação dentro de string JSON usa escape: `"${(produto)?json_string}"`, com default: `"${(acaoVoltar!'TELA_X')?json_string}"`. Sem isso, aspas ou `\` no dado quebram o JSON e a tela não abre.
- Todo nó com `acao` tem nome acessível: `"acessibilidade": "Voltar"` (verbo da ação). Ícone sozinho não tem nome.
- Texto de leitura nunca `""`. Sem texto → `null` (o front aplica padrão).
- Valor monetário: "R$ 4.000,00", nunca "R$ 4.000,00 reais" — "R$" já é lido como "reais".
- Número de contrato/protocolo no texto de leitura: dígito a dígito (`contratoAcessibilidade`).
- Significado não pode existir só em `classes` (ex.: `squad-texto-tachado` = preço antigo). Mande texto de leitura "de R$ X por R$ Y" ou um campo `tipo`.
- Bloco em grade (esquerda/direita em linhas) precisa de texto de leitura linear no nó pai — lido linha a linha, a grade não faz sentido.
- `<#if>` que adiciona campo: a vírgula fica DENTRO do bloco condicional.

## Mudança de contrato
Campo novo de acessibilidade é aditivo e opcional — o front tem fallback. Renomear ou remover campo existente é breaking: combine com o MFE antes.

## Verificar
`node tools/a11y/a11y-check.mjs <arquivo.ftl>` (estático, <1s) e `mvn test -Dtest=A11yContratoFtlTest` (renderiza com os cenários de `src/test/resources/a11y/cenarios`). Todo `<#if>` novo ganha um cenário.

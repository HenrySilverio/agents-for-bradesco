package a11y; // AJUSTE: pacote de testes do BFF

import freemarker.template.Configuration;
import freemarker.template.Template;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.fail;

/**
 * Renderiza cada FTL com um modelo de exemplo e aplica RegrasA11yContrato ao JSON gerado.
 * Não sobe Spring, não chama serviço: roda em ~1s e funciona sem rede.
 *
 * Cenários: src/test/resources/a11y/cenarios/*.json
 *   { "template": "detalhe-divida.ftl", "modelo": { ...variáveis do FTL... } }
 * Um cenário por ramo relevante do FTL (com alerta / sem alerta), senão o <#if> não é testado.
 *
 * Saída: target/a11y/<cenario>.json — o JSON exato que o MFE recebe. É dele que o MFE copia a fixture.
 *
 * Modo (-Da11y.modo=...):
 *   relatorio (padrão) — imprime achados, nunca falha. Para adotar sem quebrar o build no dia 1.
 *   erro               — falha em ERRO.
 *   estrito            — falha em ERRO e AVISO.
 * JSON inválido falha em QUALQUER modo: aí o MFE nem renderiza.
 */
class A11yContratoFtlTest {

    // AJUSTE: pasta dos .ftl no BFF.
    private static final Path TEMPLATES = Path.of(System.getProperty("a11y.templates", "src/main/resources/templates"));
    private static final Path CENARIOS = Path.of("src/test/resources/a11y/cenarios");
    private static final Path SAIDA = Path.of("target/a11y");
    private static final String MODO = System.getProperty("a11y.modo", "relatorio");

    @TestFactory
    Stream<DynamicTest> contratoAcessivel() throws IOException {
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_32);
        cfg.setDirectoryForTemplateLoading(TEMPLATES.toFile());
        cfg.setDefaultEncoding("UTF-8");
        // AJUSTE: se o BFF registra auto-imports/shared variables na config do FreeMarker, replique aqui.
        Files.createDirectories(SAIDA);

        try (Stream<Path> arquivos = Files.list(CENARIOS)) {
            List<Path> lista = arquivos.filter(p -> p.toString().endsWith(".json")).sorted().toList();
            return lista.stream().map(c -> DynamicTest.dynamicTest(c.getFileName().toString(), () -> verificar(cfg, c)));
        }
    }

    @SuppressWarnings("unchecked")
    private void verificar(Configuration cfg, Path cenario) throws Exception {
        Map<String, Object> def = (Map<String, Object>) JsonEstrito.parse(Files.readString(cenario, StandardCharsets.UTF_8));
        Template t = cfg.getTemplate((String) def.get("template"));
        StringWriter w = new StringWriter();
        t.process(def.get("modelo"), w);
        String renderizado = w.toString();

        String nome = cenario.getFileName().toString().replace(".json", "");
        Files.writeString(SAIDA.resolve(nome + ".json"), renderizado, StandardCharsets.UTF_8);

        Object json;
        try {
            json = JsonEstrito.parse(renderizado);
        } catch (IllegalArgumentException e) {
            fail(nome + ": " + e.getMessage() + " (veja target/a11y/" + nome + ".json). Causa comum: ${var} sem ?json_string.");
            return;
        }
        List<RegrasA11yContrato.Achado> achados = RegrasA11yContrato.avaliar(json);
        achados.forEach(a -> System.out.println(nome + " " + a));

        boolean falha = switch (MODO) {
            case "estrito" -> !achados.isEmpty();
            case "erro" -> achados.stream().anyMatch(a -> a.severidade() == RegrasA11yContrato.Severidade.ERRO);
            default -> false;
        };
        if (falha) fail(nome + ": " + achados.size() + " achado(s) de acessibilidade no contrato (modo " + MODO + ")");
    }
}

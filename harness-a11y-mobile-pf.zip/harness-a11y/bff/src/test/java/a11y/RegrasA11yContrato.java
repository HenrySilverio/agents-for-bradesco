package a11y; // AJUSTE: pacote de testes do BFF

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * Regras de acessibilidade sobre o JSON JÁ RENDERIZADO pelo FTL (o que o MFE realmente recebe).
 *
 * Não testa como a tela fica — isso é do MFE. Testa se o contrato carrega o que o front precisa
 * para ser acessível: nome em tudo que é acionável, texto de leitura não vazio, sem "R$ … reais",
 * sem significado só visual.
 */
public final class RegrasA11yContrato {

    public enum Severidade { ERRO, AVISO }

    public record Achado(Severidade severidade, String codigo, String caminho, String mensagem, String correcao) {
        @Override public String toString() {
            return "[%s %s] %s — %s → %s".formatted(severidade, codigo, caminho, mensagem, correcao);
        }
    }

    // AJUSTE: vocabulário de acessibilidade do contrato. Enquanto a squad não unificar, aceita os dois estilos.
    static final List<String> CAMPOS_NOME = List.of("acessibilidade", "texto_leitor", "textoLeitor", "rotulo", "titulo", "label");
    static final List<String> CAMPOS_LEITURA = List.of("acessibilidade", "texto_leitor", "textoLeitor");

    private static final Pattern REAIS_DUPLICADO = Pattern.compile("R\\$\\s*[\\d.,]+\\s*reais", Pattern.CASE_INSENSITIVE);
    private static final Pattern TERMINA_EM_CONECTOR = Pattern.compile("(\\s(é|de|do|da|em|com|por)|:)\\s*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern TEXTO_TECNICO = Pattern.compile("\\b(null|undefined|NaN)\\b");
    private static final Pattern VISUAL_SEM_SEMANTICA = Pattern.compile("tachad|riscad|strike", Pattern.CASE_INSENSITIVE);

    private RegrasA11yContrato() {}

    public static List<Achado> avaliar(Object json) {
        List<Achado> out = new ArrayList<>();
        visitar(json, "$", out);
        return out;
    }

    @SuppressWarnings("unchecked")
    private static void visitar(Object no, String caminho, List<Achado> out) {
        if (no instanceof Map<?, ?> m) {
            avaliarObjeto((Map<String, Object>) m, caminho, out);
            m.forEach((k, v) -> visitar(v, caminho + "." + k, out));
        } else if (no instanceof List<?> l) {
            for (int i = 0; i < l.size(); i++) visitar(l.get(i), caminho + "[" + i + "]", out);
        }
    }

    private static void avaliarObjeto(Map<String, Object> o, String caminho, List<Achado> out) {
        // C02 — acionável sem nome acessível (ex.: iconeEsquerda { icone, acao })
        if (o.get("acao") != null && CAMPOS_NOME.stream().noneMatch(c -> naoVazio(o.get(c))))
            out.add(new Achado(Severidade.ERRO, "C02", caminho,
                    "nó acionável sem nome acessível (chaves: " + String.join(", ", o.keySet()) + ")",
                    "adicione \"acessibilidade\" com o verbo da ação (\"Voltar\", \"Fechar\")"));

        for (String c : CAMPOS_LEITURA) {
            if (!o.containsKey(c) || o.get(c) == null) continue;
            String t = Objects.toString(o.get(c));
            // C03 — texto de leitura vazio
            if (t.isBlank())
                out.add(new Achado(Severidade.ERRO, "C03", caminho + "." + c, "texto de leitura vazio",
                        "mande null (front aplica padrão) ou o texto real"));
            // C04 — "R$ … reais"
            if (REAIS_DUPLICADO.matcher(t).find())
                out.add(new Achado(Severidade.ERRO, "C04", caminho + "." + c, "\"" + t + "\" — \"R$\" já é lido como \"reais\"",
                        "remova a palavra \"reais\""));
            // C06 — interpolação que saiu vazia/técnica ("Produto da dívida é ")
            if (TERMINA_EM_CONECTOR.matcher(t).find() || TEXTO_TECNICO.matcher(t).find())
                out.add(new Achado(Severidade.AVISO, "C06", caminho + "." + c, "\"" + t + "\" — parece interpolação vazia ou valor técnico",
                        "confira o dado do modelo e o default ${var!'...'}"));
        }

        // C05 — significado só visual (valor tachado = preço antigo)
        Object classes = o.get("classes");
        if (classes instanceof String cl && VISUAL_SEM_SEMANTICA.matcher(cl).find()
                && CAMPOS_LEITURA.stream().noneMatch(c -> naoVazio(o.get(c))))
            out.add(new Achado(Severidade.AVISO, "C05", caminho, "valor tachado sem texto de leitura — \"preço antigo\" só existe visualmente",
                    "mande texto de leitura (\"de R$ X por R$ Y\") ou um \"tipo\" semântico"));

        // C07 — cabeçalho com descricao "" (o front usa como <h1>: heading vazio)
        if (caminho.endsWith(".cabecalho") && "".equals(o.get("descricao")))
            out.add(new Achado(Severidade.AVISO, "C07", caminho + ".descricao", "descricao \"\" — vira heading vazio se o front renderizar",
                    "mande null ou omita o campo"));
    }

    private static boolean naoVazio(Object v) {
        return v instanceof String s ? !s.isBlank() : v != null;
    }
}

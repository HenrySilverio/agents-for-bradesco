# Harness de acessibilidade — Mobile PF

Objetivo: implementar e validar acessibilidade **sem subir em HOM a cada mudança**.

Dois pacotes independentes: `mfe/` vai para o repo do MFE e `bff/` vai para **cada** BFF, como cópia. Nada é compartilhado entre repos, pelo mesmo motivo do harness federado: se a configuração de IA vira dependência de build, uma atualização quebra os três repos ao mesmo tempo.

## Duas camadas com regras de versionamento diferentes

| Camada | O que é | Onde fica | Commit? |
|---|---|---|---|
| **Ferramentas determinísticas** | `tools/a11y/a11y-check.mjs`, testes, fixtures, `.aria.yml` | pastas normais do repo | **sim**: é código de teste, roda na CI e sem IA |
| **Harness Copilot** | instructions, skills, agents, prompts, hooks | `.github/` | **não** (política do banco). Copiar localmente e adicionar ao `.git/info/exclude` |

A verificação não pode depender da IA. Se alguém não usar Copilot, os níveis 0–2 funcionam igual. O harness só torna o caminho correto mais barato de seguir.

Não há `copilot-instructions.md` (a política não permite). O roteamento é feito pelas `description` das skills e pelo `applyTo` das instructions. Custo fixo por requisição: só as duas descriptions de skill (~90 tokens). Todo o resto carrega sob demanda.

## Instalação

**MFE**
```bash
cp -r mfe/tools mfe/e2e-a11y mfe/docs <repo-mfe>/
cp -r mfe/src/testing <repo-mfe>/src/
cp -r mfe/.github/. <repo-mfe>/.github/ && printf ".github/instructions/a11y-*\n.github/skills/a11y-*\n.github/agents/a11y-*\n.github/prompts/a11y-*\n.github/hooks/a11y.json\n" >> <repo-mfe>/.git/info/exclude
npm i -D @playwright/test@^1.56 @axe-core/playwright@^4.10 @testing-library/angular@^17 @testing-library/dom@^10
```
O nível 1 roda no Jest existente. Os testes Playwright usam o sufixo `.a11y.pw.ts`, e não `.spec.ts`, para o Jest não tentar executá-los. Se o `jest.config` tiver `roots` ou `testMatch` customizado, confira que `e2e-a11y/` fica de fora.

Não rode `npx playwright install`: o config usa o Edge instalado (`channel: msedge`). Se o Edge for bloqueado, use `A11Y_CHANNEL=chrome`.

**BFF (em cada um)**
```bash
cp -r bff/tools <repo-bff>/
cp -r bff/src/test/. <repo-bff>/src/test/
cp -r bff/.github/. <repo-bff>/.github/   # + .git/info/exclude, igual ao MFE
```
O teste depende só de `freemarker` (já no classpath) e do JUnit 5 do `spring-boot-starter-test`. Não usa Jackson (ver `JsonEstrito.java`).

## AJUSTES antes de usar (`grep -rn AJUSTE`)

| Arquivo | O quê |
|---|---|
| `e2e-a11y/playwright.config.ts` | comando que sobe o remote standalone |
| `e2e-a11y/support/mock-bff.ts` | padrão de URL das chamadas ao BFF |
| `e2e-a11y/telas/lista-dividas.a11y.pw.ts` | rota que abre a tela direto |
| `e2e-a11y/telas/__aria__/lista-dividas.aria.yml` | é um **exemplo**: `banner`/`main` dependem do `app-cabecalho` real. Regere com `--update-snapshots` e revise contra a anotação |
| `A11yContratoFtlTest.java` | pasta dos `.ftl` e config do FreeMarker (auto-imports) |
| `a11y-check.mjs` / `RegrasA11yContrato.java` | `CAMPOS_NOME`: vocabulário de acessibilidade do contrato |

## Adoção sem quebrar o build

1. BFF em `-Da11y.modo=relatorio` (padrão): só imprime. No `detalhe-divida.ftl`, aparecem 2 × C02 (ícones sem nome) e C07; no JSON da lista, C02 e C05. **Exceção: JSON inválido falha em qualquer modo**, porque em produção a tela não abre. O cenário `com-alerta` tem aspas no `produto` de propósito, então falha até o FTL ganhar `?json_string`. Essa correção é a primeira a fazer.
2. Squad decide o vocabulário (`acessibilidade` × `texto_leitor`) → CI passa para `modo=erro`.
3. MFE: o `.aria.yml` entra tela a tela, conforme cada tela for mexida. Não vale fazer mutirão.

## Trade-offs aceitos

- **`JsonEstrito` (~90 linhas) em vez de Jackson.** Com Boot 4, o projeto pode estar em Jackson 2 ou 3, e a API mudou entre eles. Ganho: teste imune à versão e estrito com vírgula sobrando. Custo: um parser de teste para manter.
- **Checker por regex, não parser HTML.** Pega os anti-padrões que já apareceram no código, com zero dependências e <1s no hook. Pode dar falso positivo em template muito incomum. Para cobertura ampla, a alternativa é o preset `templateAccessibility` do `@angular-eslint`, se o repo já usar ESLint.
- **Playwright é dependência nova.** É a única forma de testar a ordem de leitura da tela inteira. Os níveis 0 e 1 funcionam sem ele.
- **Nada disso substitui TalkBack/VoiceOver reais.** O Playwright calcula a árvore com o próprio motor. Uma validação em HOM continua necessária no final, não a cada mudança.

## O que foi executado antes da entrega

- `a11y-check.mjs` contra os arquivos originais enviados: 13 erros e 4 avisos, incluindo todos os problemas apontados na análise.
- Playwright 1.56 + axe numa página equivalente ao DOM dos templates corrigidos: 3/3 passando. Com a marcação original: snapshot e teste de foco **falham**, **axe passa**. Isso prova que axe sozinho não basta.
- `JsonEstrito` + `RegrasA11yContrato` compilados em Java 21 e executados contra o JSON renderizado do `detalhe-divida.ftl`. Com aspas no dado e sem `?json_string`, o parse falha (JSON inválido na linha 35).
- Asserções do teste Jest executadas em Jest 29 + jsdom sobre o DOM equivalente: corrigido 4/4; original falha em 3 (heading, foco, "R$ … reais"). O `render` do Angular em si não foi executado (precisa do componente real).
- **Não executado:** a renderização FreeMarker dentro do JUnit (Maven Central bloqueado no ambiente de validação). As chamadas usadas são API estável do FreeMarker 2.3.

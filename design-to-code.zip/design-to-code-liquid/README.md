# Configuração do Figma MCP Server no VS Code

De acordo com a documentação oficial da Figma, existem duas formas de configurar o Figma MCP Server remoto no VS Code. Escolha uma das opções abaixo:

## Opção 1: Configuração Rápida via Atalho do VS Code (Recomendado)

1. No VS Code, utilize o atalho **`⌘ Shift P`** (macOS) ou **`Ctrl Shift P`** (Windows/Linux) para abrir a Paleta de Comandos.
2. Pesquise por **`MCP: Add Server`** e selecione essa opção.
3. No seletor de tipo de transporte, escolha **`HTTP`**.
4. Cole a URL oficial do servidor remoto da Figma na barra de pesquisa e pressione `Enter`:

```link
   https://mcp.figma.com/mcp
```

1. Quando for solicitado o ID do servidor (Server ID), digite **`figma`**.
2. Selecione se deseja adicionar este servidor **globalmente** (disponível para todos os projetos) ou apenas para o **workspace atual**.

---

### Opção 2: Configuração Manual via Arquivo `mcp.json`

1. Use o atalho **`⌘ Shift P`** (macOS) ou **`Ctrl Shift P`** (Windows/Linux) e selecione uma das opções:
   * **`MCP: Open User Configuration`**: para utilizar o servidor globalmente em todos os seus projetos.
   * **`MCP: Open Workspace Folder MCP Configuration`**: para restringir o uso ao seu workspace atual.
2. Se o arquivo não existir, o VS Code solicitará que você crie um arquivo chamado **`mcp.json`**.
3. Cole o seguinte código JSON dentro do arquivo:

```json
{
  "inputs": [],
  "servers": {
    "figma": {
      "url": "https://mcp.figma.com/mcp",
      "type": "http"
    }
  }
}
```

1. Salve o arquivo e clique no botão **Start** que aparecerá acima do nome do servidor (`figma`) no VS Code.
2. Clique em **Allow Access** (Permitir Acesso) para autorizar a integração com a sua conta do Figma.

---

## Doc: Agente design-to-code (`ai-dlc-design-to-code`) — Documentação de Uso

* **Definição real do agente:** `ai-dlc-design-to-code.agent.md` — `name: "design-to-code"`, `user-invocable: true`.

---

## Resumo

* **Objetivo:** Orquestrar a análise, documentação e geração de componentes Angular + Liquid a partir de nodes do Figma, delegando às skills `figma-liquid-component-selection`, `figma-node-json-generator` e `figma-angular-component-generation`, sempre com aprovação do usuário entre etapas.
* **Público-alvo:** Desenvolvedores frontend, engenheiros de design-to-code e revisores de integração.

---

## Como usar no Copilot Chat (prático)

1. Abra o **Chat** no VS Code e selecione o modo/agente **`design-to-code`** no seletor de agentes (ou digite `@design-to-code` se o mention estiver disponível no seu picker).
2. Envie o pedido em uma mensagem descrevendo a URL do Figma e os nodes desejados.

Exemplo de prompt:

```text
@design-to-code
figma_url: https://figma.com/design/abc123/MyFile?node-id=1-2
component_node_ids: ["1:2", "1:5"]
integration_node_id: "1:1"
target_path: src/app/components/
```

1. O agente executa em 3 etapas, **pedindo autorização explícita antes de avançar para a próxima**:
   * **Etapa 1:** Delega para a skill `figma-liquid-component-selection` e apresenta a análise/mapeamento Liquid sugerido. Responda algo como *"aprovado, pode continuar"* para seguir.
   * **Etapa 2:** Delega para `figma-node-json-generator`, gerando os `component_node_details_json` / `integration_node_details_json`. Aprove novamente para prosseguir.
   * **Etapa 3:** Delega para `figma-angular-component-generation`, criando os componentes Angular + Liquid. Confirme o resultado final.
2. Caso não responda com aprovação, o agente **não avança** — isso é intencional (regra não negociável do agente).

---

### Dica rápida (prompt mínimo)

Se você só tiver a URL do Figma, pode simplesmente escrever:

```text
@design-to-code Gere os componentes Angular para este node do Figma: https://figma.com/design/abc123/MyFile?node-id=1-2
```

O agente perguntará os dados faltantes (ex.: `target_path`, node de integração) antes de iniciar.

---

### Observações importantes para quem for utilizar o agente

* **Quanto mais nodes filhos, melhor a qualidade da geração:** Prefira passar todos os nodes relevantes da tela em vez de nodes isolados — isso dá mais contexto para o mapeamento Liquid e para a composição final.
* **Indique o node de integração** (`integration_node_id`) para consolidar os nodes filhos em uma única tela/composição. Sem ele, o agente não sabe como montar a composição final.
* **Passe contexto por node se necessário**, usando `node_hints` (ex.: comportamento esperado, estados, regras de negócio) — isso evita suposições incorretas por parte do agente.
* **Etapas podem ser puladas, desde que já tenham sido cumpridas previamente:** Se a análise Liquid ou o JSON de nodes já foram gerados e aprovados em uma execução anterior, você pode instruir o agente a pular direto para a etapa seguinte.
* **A conferência entre etapas é necessária** para garantir a seleção correta dos componentes Liquid e evitar retrabalho — não aprove às pressas, revise o mapeamento sugerido antes de avançar.
* **Leia e critique as descrições de tela e de comportamento apresentadas pelo agente:** Quanto mais precisa e detalhada for a validação (nomes de estados, interações, regras), melhor será a geração final dos componentes.

---

## Quando usar

* Converter nodes do Figma aprovados em componentes Angular + Liquid, com exatamente 1 componente por node.
* Gerar documentação de análise (justificativa da escolha Liquid) antes de qualquer geração de código.
* Compor telas com múltiplos nodes filhos + 1 node de integração/pai.

---

## Entradas esperadas (conforme `argument-hint` do agente)

* `figma_url` **(obrigatório)**: URL do arquivo Figma (contém `fileKey` e `node-id`).
* `component_node_ids` ou `nodes` **(obrigatório)**: lista de node ids a processar (ex: `["1:2","2:5"]`).
* `integration_node_id` (opcional): node pai de composição, quando os filhos formam uma tela.
* `node_hints` (opcional): restrições, observações ou decisões de UX a considerar.
* `target_path`: pasta destino no repositório onde os arquivos de componente serão criados.

---

## Saídas geradas

* Análise por node com justificativa da escolha Liquid, gravada em documento para revisão do usuário.
* `component_node_details_json` e `integration_node_details_json` (quando houver node pai).
* Um ou mais componentes Angular por node (`.ts`, `.html`, `.scss`) + templates Liquid associados.
* Resumo final com o mapeamento node $\rightarrow$ componente Liquid $\rightarrow$ componente Angular gerado.

---

## Fluxo de trabalho (resumido)

1. Delega para `figma-liquid-component-selection` $\rightarrow$ aguarda aprovação do usuário.
2. Delega para `figma-node-json-generator` $\rightarrow$ aguarda aprovação do usuário.
3. Delega para `figma-angular-component-generation` $\rightarrow$ confirma geração final com o usuário.

---

## Regras não negociáveis do agente

* Usa o MCP do Figma como fonte primária dos dados (não improvisa layout).
* Segue sempre a ordem: `figma-liquid-component-selection` $\rightarrow$ `figma-node-json-generator` $\rightarrow$ `figma-angular-component-generation`.
* Não avança de etapa sem autorização expressa do usuário.
* Não inventa bindings sem base no layout, fluxo ou `node_hints` recebidos.
* Se o node de integração/pai existir, ele é analisado e gerado separadamente, como composição dos filhos.

---

## Boas práticas e recomendações

* Responda às aprovações intermediárias de forma explícita (*"aprovado"*, *"pode continuar"*) para o agente avançar de etapa.
* Manter exatamente 1 componente gerado por node — se o node representar múltiplos conceitos, dividir o node ou criar nodes auxiliares no Figma.
* Validar manualmente os `component_node_details_json` antes de aceitar a geração final dos componentes Angular.
* Forneça `node_hints` quando houver decisões de UX ou restrições que o Figma sozinho não capture.

---

## Integração com Skills do repositório

* O agente delega, nesta ordem obrigatória, para: [`figma-liquid-component-selection`](https://chat-editing-snapshot-text-model+.vscode-resource.vscode-cdn.net/c%3A/workspace_temp/.github/agents/.github/skills/figma-liquid-component-selection/SKILL.md), [`figma-node-json-generator`](https://chat-editing-snapshot-text-model+.vscode-resource.vscode-cdn.net/c%3A/workspace_temp/.github/agents/.github/skills/figma-node-json-generator/SKILL.md) e `figma-angular-component-generation`.
* Cada skill recebe os parâmetros repassados pelo orquestrador e retorna artefatos que alimentam a etapa seguinte.

---

## Testes e verificação

* Após geração, executar testes de lint e build do projeto Angular (ex.: `npm run build` / `ng build`) e revisar warnings.
* Verificar se os snapshots visuais (se houver) batem com os designs aprovados.

---

## Erros comuns e como resolver

* **Falha ao localizar `fileKey` ou `node-id` na `figma_url`:** verifique o formato da URL e converta `node-id` de `1-2` para `1:2` quando necessário.
* **Agente parece "travado" entre etapas:** ele está aguardando sua aprovação explícita — responda confirmando para continuar.
* **Componente gerado não corresponde ao esperado:** revise o `node_hints` e reforce restrições de UX antes de reexecutar.

---

## Checklist pré-execução

* [ ] `figma_url` e `component_node_ids`/`nodes` disponíveis.
* [ ] `target_path` existe e tem permissões de escrita.
* [ ] `integration_node_id` identificado, se a tela for composta por múltiplos nodes.

---

## Como contribuir

* Atualize esta documentação quando as regras do agente (`.github/agents/ai-dlc-design-to-code.agent.md`) mudarem.
* Alterações no fluxo de etapas ou nas skills delegadas devem ser refletidas aqui.

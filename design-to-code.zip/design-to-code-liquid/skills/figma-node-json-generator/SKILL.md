---
name: figma-node-json-generator
description: "Use quando precisar gerar component_node_details_json por node e integration_node_details_json do node pai a partir do Figma via MCP, no formato padrao para composicao Angular."
argument-hint: "Informe figma_url, lista de node_ids de componentes e integration_node_id."
---

# Gerador de JSON por Node (Figma MCP)

Para cada node de componente e para o node pai de integracao, gere um JSON detalhado com metadados para uso na geracao de codigo Angular na pasta `docs/designToCode/<componente>/node` onde <componente> é o nome do componente a ser documentado. Siga o seguinte processo por node:

1. Receber dados do planejamento de construção do componente (liquid_mapping, node_hints, etc).
2. Gerar arquivo JSON para o node selecionado.
3. Se o node for de integração, gerar arquivo JSON com prefixo `integration_`.
4. O JSON deve ter os seguintes campos obrigatórios:
   - `component_name`
   - `inputs`
   - `outputs`
   - `states`
   - `liquid_preference`
   - `fallback_allowed`
   - `notes`
   - `screen_description`
   - `behavior`
  - `selected_component`
  - `catalog_titles`
  - `docs_urls`
  - `screenshots_path`
  - `selection_reason`
  - `approval_status`
5. Para o node pai, campos obrigatórios inferir:
   - `component_name`
   - `layout_rules`
   - `ordering`
   - `bindings`
   - `parent_inputs`
   - `parent_outputs`
   - `notes`
   - `behavior`
   - `screen_description`
  - `selected_component`
  - `catalog_titles`
  - `docs_urls`
  - `screenshots_path`
  - `selection_reason`
  - `approval_status`
6. Se houver ambiguidade nas decisões (ex: fallback não permitido mas sem componente oficial), solicitar clarificacao minima antes de fechar o JSON.
7. Gera artefatos JSON para uso na geracao/composicao Angular no seguinte diretorio: `docs/designToCode/node`, com os seguintes nomes:
  - `component_node_details_json` (um por node de componente)
  - `integration_node_details_json` (um por node pai de integracao)
8. Antes de concluir cada node, baixe a screenshot do MCP do Figma para `docs/designToCode/<componente>/node/screenshots/<nodeId>.png` e só preencha `screenshots_path` depois que o arquivo existir no workspace. Se a imagem nao puder ser materializada, interrompa o node e solicite confirmacao minima em vez de gravar um caminho inexistente.
9. Retornar `component_node_details_json` e `integration_node_details_json` no formato obrigatorio abaixo.

## Quando usar
- Quando precisa detalhar cada componente antes de gerar codigo Angular.
- Quando precisa padronizar o payload para agentes geradores.

## Formato de saida obrigatorio

```json component_node_details_json
{"nodes":[{
    "210:301": {
      "component_name": "customer-summary-card",
      "inputs": ["customer", "loading"],
      "outputs": ["openDetails"],
      "states": ["default", "loading", "error", "empty"],
      "liquid_preference": ["brad-card", "brad-tag"],
      "fallback_allowed": true,
      "selected_component": ["brad-card", "brad-tag"],
      "catalog_titles": ["DesignSystem/Components/Card/HTML","DesignSystem/Components/Tag/HTML"],
      "docs_urls": ["https://example.com/Card/docs","https://example.com/Tag/docs"],
      "selection_reason": "Card oficial mais aderente ao bloco de resumo.",
      "approval_status": "approved",
      "notes": "Card de resumo do cliente com status. Tag de cpv do cliente",
      "behavior": "antes de carregar as informações usar um skeleton, depois exibir as informações resumidas do cliente. Ao clicar no card, disparar evento openDetails. ao clicar em um icone ao lado do cpf copiar informação para a area de transferencia. Ao clicar na tag de cpv, disparar evento openDetails.",
      "screen_description": "card com informações resumidas do cliente, incluindo nome, cpf, status e tag de cpv. campos dispostos um ao lado do outro, com label acima e em negrito, com quebra de linha quando necessário, em layout responsivo",
    }
  }]
}
```
```json integration_node_details_json
  {
    "component_name": "customer-dashboard-parent",
    "layout_rules": "grid 2 col desktop, 1 col mobile",
    "ordering": ["210:301"],
    "bindings": ["customer-summary-card.customer <- vm.customer"],
    "parent_inputs": ["customerId"],
    "parent_outputs": ["navigateTo"],
    "selected_component": ["customer-dashboard-parent"],
    "catalog_titles": ["DesignSystem/Components/Layout/HTML"],
    "docs_urls": ["https://example.com/docs-parent"],
    "selection_reason": "Agrupamento pai necessário para compor os blocos filhos.",
    "approval_status": "approved",
    "notes": "Componente pai da tela de dashboard.",
    "behavior": "ao clicar em voltar retornar para a tela anterior.",
    "screen_description": "botão de voltar no canto superior esquerdo, título da tela centralizado, e abaixo os blocos de resumo do cliente."
  }

```

## Regras não negociáveis
- Usar MCP do Figma como fonte primaria.
- Priorizar componente oficial Liquid em `liquid_preference`.
- Marcar `fallback_allowed: false` quando houver componente oficial claro.
- Nao inventar bindings sem base no layout/fluxo ou hints recebidos.
- Nao gerar JSON se houver ambiguidade sem clarificacao minima.
- Nao gravar `screenshots_path` apontando para arquivo inexistente; o caminho so pode ser registrado depois da imagem ser salva no workspace.
- Não prosseguir até que todas as duvidas sejam esclarecidas.
- Limite a resposta ao resumo tecnico definido na secao 'Saida esperada'. Nao adicione explicacoes, justificativas ou comentarios alem do que for listado nessa secao.

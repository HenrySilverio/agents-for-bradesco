---
name: figma-liquid-component-selection
description: "Use quando precisar analisar nodes do Figma e selecionar os componentes Liquid adequados, com mapeamento por intencao e decisao arquitetural AI-DLC baseada nos agentes existentes."
argument-hint: "Informe link/frames do Figma e o contexto (Shell, MFE ou Auto)."
---

Para cada node do figma recebido selecione um ou mais componentes Liquid adequados para a futura construcao do componente Angular seguindo as referencias `../../references/ai-dlc-liquid-*`. Siga o seguinte processo por node:

Se a entrada for um link ou frame do Figma, siga o **Procedimento** completo a partir do passo 1. Se a entrada for uma imagem, código ou arquivo de design, pule o passo 1, execute a etapa de **Etapas De Análise** correspondente ao tipo de entrada recebido e, em seguida, retome o **Procedimento** a partir do passo 2.

## Procedimento
1. Consulte o frame no **MCP do Figma** e extraia os metadados do layout e imagem de referencia.
2. Grave os context e metadados do figma como arquivo de texto no diretorio `docs/designToCode/<componente>/metadataContext` para uso futuro, onde <componente> é o nome do componente a ser analisado.
4. Mapeie cada bloco do Figma por intencao (acao, entrada, feedback, navegacao, conteudo) e selecione componentes Liquid oficiais para cada item ou conjunto de itens. Veja [guia liquid](../../references/ai-dlc-liquid.md) para detalhes.
   - Prioridade obrigatoria e canonica: componentização maxima com componente oficial exato -> variante/padrao oficial -> HTML semantico com utilitarios Liquid -> fallback customizado somente com aprovacao explicita.
	 - Não use URLs fornecidas pelo Figma ou do zeroheight como fonte canônica da documentação.
	- NUNCA utilize como referencia exata o `title` e o `docsUrl` que o figma fornecer. use-os apenas como referencia inicial, mas sempre confirme a cobertura e aderencia com o `../../assets/liquid-storybook-docs-text.json` oficial.
	 - Se um node puder ser decomposto em varios blocos Liquids oficiais, prefira a decomposicao para cobrir todos os blocos possiveis com Liquid em vez de manter um bloco unico com fallback. A decomposicao em blocos oficiais nao e considerada fallback e nao requer aprovacao do usuario; fallback customizado aplica-se apenas a blocos residuais que nao puderem ser cobertos por nenhum componente Liquid oficial apos a decomposicao.
   - Se o Figma trouxer uma restricao textual de "não usar", peça confirmação para usar.
   - Para cada escolha, cite a entrada do catalogo usada (`title` e `docsUrl`) e registre a justificativa.
	 - A referencia de `title` e `docsUrl` deve ser a mesma do `liquid-storybook-docs-text.json` oficial, nao a do Figma.
	 - Se `title` e `docsUrl` tiverem conteudo diferente do `liquid-storybook-docs-text.json` oficial, use o valor do `liquid-storybook-docs-text.json` oficial.
   - A selecao deve ser derivada dos exemplos, markup e observacoes do `liquid-storybook-docs-text.json` correspondente; nao use apenas o nome do componente como referencia.
   - A `docsUrl` a ser registrada deve vir da propria entrada do `liquid-storybook-docs-text.json`; se a entrada nao trouxer `docsUrl` correspondente, pare e pergunte explicitamente: "Este componente pode seguir sem docsUrl registrado, ou voce pode informar a URL correta?".
   - Se existir baseline anterior em `liquid_mapping`, `component_node_details_json` ou `integration_node_details_json`, aplique as regras da seção **Regras de Preservação de Baseline**.
5. Reavalie o contexto visual e funcional do Figma antes da selecao final, mesmo quando o node nao indicar explicitamente um componente Liquid; busque sempre o componente Liquid mais aderente ao bloco analisado.
6. Descreva textualmente o visual do componente.
7. Se requisitado, descreva textualmente provaveis comportamentos esperados, incluindo interacoes, responsividade e acessibilidade, para que a etapa de geracao Angular possa ser realizada com base no mapeamento.


## Etapas De Análise
- Quando receber uma especificação do Figma, identifique todos os elementos disponiveis e sua hierarquia.
- Quando receber uma imagem, identifique todos os elementos visíveis da UI e sua hierarquia visual.
- Quando receber código, analise templates HTML, diretivas e classes CSS.
- Quando receber um arquivo de design, identifique os componentes e suas propriedades.
- Use a biblioteca Liquid/Brad como referência principal para o componente ou padrão equivalente.

## Regras de Preservação de Baseline
1. Considere ganho objetivo apenas quando um componente oficial substituir um fallback, a nova variante cobrir mais propriedades visiveis do bloco, ou a entrada do docs-text explicitar um comportamento ou requisito de acessibilidade nao coberto pelo baseline.
2. Se a nova analise nao trouxer ganho objetivo de cobertura, aderencia ou comportamento, preserve o baseline anterior.
3. Em empates entre alternativas oficiais igualmente validas, mantenha a ultima decisao validada em vez de alternar o mapeamento.

## Regras de selecao Liquid
- Siga a ordem canonica definida no Procedimento.
- Referenciar sempre a entrada do catalogo Liquid usada, incluindo `title` e `docsUrl` do `liquid-storybook-docs-text.json`.
- Se a especificacao do Figma trouxer restricao de nao usar, respeitar a restricao.
- Nao criar fallback visual proprio quando houver cobertura oficial Liquid adequada.
- Nao assumir componentes Liquid sem relacao clara com a intencao do bloco.

## Catálogo E `docs-text` (JSON)
Ao mapear elementos visuais para componentes Liquid, use os arquivos JSON canônicos para garantir consistência:

- Local esperado: `../../assets/liquid-storybook-catalog.json` e `../../assets/liquid-storybook-docs-text.json`.
- `docs-text` contém descrições e notas de uso por componente; `catalog` lista componentes, variantes e `docsUrl`.
- Antes de criar fallback, consulte `docs-text` para confirmar o comportamento e a acessibilidade esperados.
- A implementação Angular deve ser derivada dos exemplos e trechos de uso presentes em `docs-text`, e a `docsUrl` registrada deve ser a mesma da entrada correspondente em `docs-text`.
- Se a entrada de `docs-text` não trouxer `docsUrl` correspondente, interrompa a decisão e solicite a confirmação mínima antes de seguir.
- Se adicionar um novo mapeamento, atualize os JSONs e valide com um linter de JSON.

## Regras De Responsividade E Layout

### Flexbox (Classes Liquid/Brad)
- Use `brad-flex` para `display: flex`
- Use `brad-flex-align-items-center`, `brad-flex-align-items-start`, `brad-flex-align-items-end` para alinhamento vertical
- Use `brad-flex-justify-content-center`, `brad-flex-justify-content-start`, `brad-flex-justify-content-end` para alinhamento horizontal
- Use `brad-flex-direction-column` para layout em coluna

### Breakpoints Responsivos
- Use classes responsivas do Liquid/Brad (por exemplo, `brad-p-md-t`, `brad-m-lg-t` para padding/margin em diferentes breakpoints)
- Quando não existir classe Liquid, use media queries CSS com `@media` no SCSS:
	```scss
	@media (max-width: 768px) {
		// estilos para mobile
	}
	@media (min-width: 1024px) {
		// estilos para desktop
	}
	```

### Fallback HTML Puro
- Se não existir classe responsiva do Liquid/Brad, use style inline ou CSS local com flexbox:
	```html
	<div style="display: flex; align-items: center; justify-content: space-between;">
		<!-- conteúdo -->
	</div>
	```
- Documente na coluna de observações que este é um fallback temporário e que deve ser substituído por uma classe Liquid quando disponível.

## Saida esperada
- Mapeamento Liquid por node e por bloco, com node-ids, componentes selecionados e justificativa.
- Referencias claras ao catalogo usado, incluindo `title` e `docsUrl`.
- Regras de integracao e observacoes suficientes para a etapa de geracao Angular.

## Regras não negociáveis
- Usar MCP do Figma como fonte primaria.
- Priorizar cobertura maxima com componente oficial Liquid em todos os blocos possiveis do node.
- Nao criar fallback a menos que seja expressamente aprovado pelo usuario ou esteja explicitamente declarado no `liquid_mapping`.
- Respeitar anotacoes de "nao usar" do Figma.
- Nao gerar artefatos Angular nesta etapa.
- Nao inventar bindings sem base no layout, fluxo ou hints recebidos.
- Nao gerar JSON se houver ambiguidade sem clarificacao minima.
- Não prosseguir até que todas as duvidas sejam esclarecidas.
- Se a chamada ao MCP do Figma falhar ou retornar dados incompletos para um node, interrompa o processamento desse node, informe o erro ao usuario e aguarde instrução antes de prosseguir com os demais nodes.
- Limite a resposta ao resumo tecnico definido na secao 'Saida esperada'. Nao adicione explicacoes, justificativas ou comentarios alem do que for listado nessa secao.

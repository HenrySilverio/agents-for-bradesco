---
name: spec-to-angular-component-generation
description: "Use quando precisar ler spec e snapshot aprovados, validar o mapeamento por node e gerar componentes Angular + Liquid com padrao AI-DLC, sempre com exatamente 1 componente por node."
argument-hint: "Informe o caminho de component_node_details_json, integration_node_details_json, snapshots/spec do lote, caminho alvo no workspace e node_ids."
---

# Spec para Angular + Liquid (merged)

Use esta skill quando a tarefa for transformar nodes aprovados em componentes Angular funcionais, com base em spec estruturado e validacao visual por snapshot.

## Objetivo

Ler os artefatos aprovados, validar os mapeamentos dos componentes liquid por node e gerar 1 ou mais componente Angular por node, preservando contrato visual, contrato de integracao e arquitetura do alvo (Shell ou MFE).

## Entradas obrigatorias
- `component_node_details_json`
- `integration_node_details_json` (quando houver node pai de composicao)

## Entradas opcionais
- snapshots/screenshot correspondentes ao lote
- caminho alvo no workspace para geracao
- `node_ids` do lote a processar

## Regra principal

1. as Specs sao a base de contexto do lote.
2. `component_node_details_json` e `integration_node_details_json` sao a normalizacao estruturada obrigatoria para a geracao.
3. O JSON e a fonte primaria das aprovações de componente, estado, bindings e integracao.
4. Snapshots/screenshot servem apenas para validar posicionamento, alinhamento, escala e hierarquia visual.
5. Nao inferir comportamento fora do mapeamento aprovado.
6. conferir exemplo de implementação de componente liquid primariamente em `../../assets/liquid-storybook-catalog.json` e `../../assets/liquid-storybook-docs-text.json`.
7. Só utilizar `docs_urls` para acesso caso os arquivos `../../assets/liquid-storybook-catalog.json` e `../../assets/liquid-storybook-docs-text.json` não estejam disponíveis.
8. `selected_component` e a escolha final obrigatoria para a geracao; nao substituir por HTML customizado, heuristica visual ou componente equivalente nao registrado.
9. Quando `fallback_allowed` for `false`, qualquer tentativa de gerar markup fora do componente Liquid selecionado deve interromper o lote com inconsistencia objetiva.
10. Nao gerar estilos proprios para o componente Liquid selecionado; apenas aplicar classes e atributos de acordo com o mapeamento aprovado.

## Validacao inicial (obrigatoria)

Antes de gerar qualquer arquivo, confirme explicitamente:

- arquivos de spec `component_node_details_json` e `integration_node_details_json`

Se qualquer entrada estiver ausente, vazia, inconsistente ou nao associavel ao node correto:

- interrompa a geracao de todo o lote
- liste quais nodes estao bloqueados e quais estariam prontos
- responda exatamente com:

`mapeamento ausente ou inconsistente. Forneça um mapeamento válido [spec-files] antes de prosseguir.`

## Estrutura minima esperada do spec

### component_node_details_json

Cada node de componente deve conter, no minimo:

- `component_name`
- `inputs`
- `outputs`
- `states`
- `liquid_preference`
- `fallback_allowed`
- `selected_component`
- `catalog_titles`
- `docs_urls`
- `screenshots_path`
- `selection_reason`
- `approval_status`
- `notes`

### integration_node_details_json

Cada node pai de integracao deve conter, no minimo:

- `component_name`
- `layout_rules`
- `ordering`
- `bindings`
- `parent_inputs`
- `parent_outputs`
- `selected_component`
- `catalog_titles`
- `docs_urls`
- `screenshots_path`
- `selection_reason`
- `approval_status`
- `notes`

## Fluxo de execucao

1. Validar existencia dos arquivos e compatibilidade entre `node_ids` e chaves do JSON.
2. Validar `approval_status` de cada node.
4. extrair a forma de uso dos componentes no `../../assets/liquid-storybook-catalog.json` e `../../assets/liquid-storybook-docs-text.json`.
5. Para cada node de componente, interpretar:
   - `selected_component` como escolha final
   - `inputs` e `outputs` como contrato publico Angular
   - `states` como variacoes suportadas
   - `notes` e `selection_reason` como restricoes
   - o template gerado deve usar o componente Liquid selecionado ou sua composicao oficial prevista; nao trocar por tags HTML nativas quando houver componente Liquid aprovado
6. Para cada node de integracao, interpretar:
   - `ordering` para ordem dos filhos
   - `bindings` para composicao
   - `layout_rules` para estrutura do container
   - `parent_inputs` e `parent_outputs` para contrato do pai
7. Gerar 1 ou mais componentes Angular por node.
8. Criar `.ts`, `.html`, `.scss` e `.spec.ts` para cada componente.
9. Validar a saida contra JSON e snapshot antes de encerrar.

## Regras de geracao

- Para cada node de `component_node_details_json`: gerar 1 ou mais componentes Angular visuais.
- Para cada node de `integration_node_details_json`: gerar 1 ou mais componentes Angular de integracao/composicao.
- Nao consolidar multiplos nodes em um unico componente.
- Nao inventar fallback quando `fallback_allowed` for `false`.
- Nao trocar `selected_component` sem inconsistenca objetiva documentada.
- Nao substituir `selected_component` por markup customizado, mesmo quando o componente Liquid exigir composicao de varios elementos.
- Se a geracao nao conseguir mapear o componente Liquid selecionado, interrompa e reporte a inconsistencia objetiva em vez de criar um fallback visual.
- Nao criar bindings, eventos, estados ou dados sem base no spec aprovado.
- Nao introduzir markup extra sem base objetiva no mapeamento.
- Nao usar screenshot para selecionar componente, variante ou fallback.
- Nunca utilizar componente Liquid como WebComponent neste fluxo; usar apenas variante HTML.
- Se componente Liquid for selecionado, seguir `../../references/ai-dlc-liquid-typescript.md` para inicializacao e uso de servico JS do Liquid.

## Preservacao arquitetural

- Em Shell: respeitar roteamento, carga inicial, providers globais, guards e configuracoes compartilhadas.
- Em MFE: preservar bootstrap, federacao, exposicao de modulo, isolamento e configuracoes locais.
- Se não houver projeto Angular existente, criar componente isolado na pasta raiz do workspace, com estrutura de pastas e arquivos padrao Angular.
- Ajustar somente o necessario para integrar ao fluxo existente, sem reestruturar a aplicacao.
- Manter regra de negocio fora da camada visual.

## Inconsistencias objetivas

- Componente nao existir no catalogo Liquid e o node exigir essa estrutura/comportamento.
- Componente Liquid selecionado no tipo WebComponent (nao permitido neste fluxo).
- Componente Liquid selecionado nao suportar comportamento/estrutura exigidos pelo node.
- Componente Liquid conflitar com outro do mesmo node (slot/dependencia/inicializacao).
- Componente Liquid conflitar com outro node integrado ao mesmo pai.

Ao identificar qualquer inconsistencia objetiva, interrompa e responda exatamente com:

`inconsistencia objetiva detectada no node [node-id]: [descreva o conflito]. Corrija o mapeamento antes de prosseguir.`

## Saida esperada

- componente(s) Angular funcional(is) por node aprovado do lote.
- Template HTML aderente ao node e ao componente/utilitario Liquid aprovado.
- Estilos e testes gerados na mesma unidade do componente.
- Componente pai de integracao (quando houver) compondo os filhos conforme `integration_node_details_json`.
- Resumo tecnico com node-ids, mapeamento Liquid aplicado, decisoes de integracao e pendencias.

## Regras nao negociaveis

- Usar spec/snapshot aprovados como contexto obrigatorio do lote.
- Usar `component_node_details_json` e `integration_node_details_json` como fonte primaria de validacao estrutural.
- Manter exatamente 1 componente Angular por node.
- Nao prosseguir com ambiguidade sem clarificacao minima.
- Nao usar componente Liquid como WebComponent; somente HTML.
- Nao implementar fallback aproximado quando houver componente Liquid selecionado.
- Limitar a textos durante geracao.
- Limitar a resposta final ao resumo tecnico da secao "Saida esperada".

## Objetivo

Sempre procure a solução oficial do Liquid que preserve o comportamento, a hierarquia e a semântica pretendidos.

Prefira esta ordem:

1. Componente Liquid existente
2. Template ou padrão Liquid documentado
3. Classes utilitárias do Liquid + HTML semântico
4. Pequeno fallback de CSS ou markup com escopo restrito

Não parta para componentes customizados se o Liquid já tiver uma opção próxima.

## Fluxo de Seleção

Ao escolher um componente:

1. Consulte o catálogo extraído (`assets/liquid-storybook-docs-text.json`) para componentes candidatos e variantes (`HTML` vs `WebComponent`).
2. Verifique se a necessidade é resolvida por um único componente, por um componente com utilitários ou apenas por utilitários.
3. Escolha a opção mais simples que preserve acessibilidade e comportamento responsivo.
4. Se vários componentes forem plausíveis, prefira aquele cujo comportamento seja mais explícito e reutilizável.

## Escolha Pela Intenção

### Ações

Use um componente de ação ou padrão de botão quando o usuário aciona uma operação imediata.

Prefira:

- Padrões de botão para ações de enviar, confirmar, continuar, tentar novamente, baixar ou abrir fluxo
- Padrões de link apenas quando a ação for navegação verdadeira

Regras:

- Ações primárias devem ser visualmente distintas, mas mantenha apenas uma ação primária por seção quando possível.
- Ações secundárias e terciárias não devem competir com a decisão principal.
- Evite estilizar links para parecerem botões, a menos que navegação seja a intenção real.

### Entradas E Formulários

Use componentes de formulário quando o usuário precisar fornecer, escolher ou confirmar informações.

Prefira:

- Padrões de input de texto para valores curtos digitados
- Padrões de select ou opção para escolhas restritas
- Padrões de checkbox para escolhas booleanas independentes
- Padrões de radio para escolhas mutuamente exclusivas
- Padrões de textarea apenas para texto livre realmente mais longo

Regras:

- Mantenha sempre label, texto de ajuda e estado de erro associados ao controle.
- Não substitua controles padrão de formulário por contêineres customizados, a menos que o Liquid documente esse padrão.
- Se um campo tiver validação ou mascaramento, prefira o comportamento documentado do Liquid antes de script customizado.

### Feedback E Status

Use componentes de feedback quando a interface precisar comunicar resultado, aviso, interrupção ou progresso.

Prefira:

- Padrões de alerta ou mensagem para status inline
- Padrões de notificação para feedback transitório
- Padrões de carregamento ou skeleton para conteúdo pendente
- Padrões de estado vazio quando uma seção não tiver dados

Regras:

- Combine o componente com a urgência e a permanência da mensagem.
- Não use estilos destrutivos ou de aviso para conteúdo informativo.
- Não comunique status apenas por cor.

### Navegação

Use componentes de navegação quando o usuário se mover entre páginas, seções ou fluxos.

Prefira:

- Tabs para alternar entre visões pares no mesmo contexto
- Padrões de menu ou navegação para mudanças de seção
- Padrões de breadcrumb quando a hierarquia importar
- Padrões de paginação para listas longas de resultados

Regras:

- Não use tabs para destinos não relacionados.
- Não use botões quando o usuário estiver claramente navegando.
- Preserve claramente os estados ativo e atual.

### Contêineres De Conteúdo

Use contêineres quando conteúdo relacionado precisar de agrupamento, separação ou ênfase.

Prefira:

- Padrões semelhantes a card para informações e ações agrupadas
- Padrões semelhantes a accordion para detalhes opcionais ou recolhíveis
- Wrappers de seção com utilitários quando nenhum componente formal for necessário

Regras:

- Use um componente apenas quando o agrupamento acrescentar significado, e não só decoração.
- Evite contêineres aninhados que criem ruído visual desnecessário.
- Mantenha títulos de seção e ações alinhados com a finalidade do contêiner.

### Exibição De Dados

Use componentes de exibição de dados quando as informações precisarem ser examinadas, comparadas ou revisadas.

Prefira:

- Padrões semelhantes a tabela para comparação estruturada e densa
- Padrões de lista para itens simples repetidos
- Padrões de chave-valor ou resumo para telas compactas de revisão

Regras:

- Use tabelas somente quando linhas e colunas realmente importarem.
- Prefira layouts de resumo mais simples para conjuntos pequenos de dados.
- Preserve espaçamento legível e títulos claros para facilitar a leitura rápida.

### Overlays E Interrupções

Use padrões de overlay apenas quando o usuário precisar focar em uma tarefa ou decisão.

Prefira:

- Padrões semelhantes a modal para confirmação bloqueante ou subfluxos focados
- Padrões de drawer ou painel quando o contexto lateral for suficiente e suportado

Regras:

- Evite overlays para informações estáticas simples.
- Mantenha o conteúdo do overlay curto e orientado à tarefa.
- Nunca esconda um caminho crítico atrás de confirmações desnecessárias repetidas.

### Mídia, Ícones E Ilustração

Use mídia e ativos visuais apenas quando eles esclarecem significado, status ou contexto de marca.

Prefira:

- Ícones quando reforçarem uma ação ou status conhecido
- Ilustrações para onboarding, estados vazios ou narrativa de marca
- Logotipos e bandeiras apenas quando fizerem sentido no contexto de negócio

Regras:

- Não use ícones como único rótulo para ações ambíguas.
- Não adicione ilustração decorativa em áreas transacionais densas, a menos que ela apoie a experiência.

## Utilitários Versus Componentes

Use utilitários do Liquid em vez de um componente quando:

- A necessidade for puramente de layout ou espaçamento
- O conteúdo for HTML semântico simples
- Nenhum comportamento reutilizável de componente for necessário
- Um componente completo adicionaria estrutura desnecessária

Use um componente real quando:

- O padrão tiver estados de interação
- O padrão precisar de comportamento de acessibilidade já resolvido pelo sistema
- O padrão se repetir o suficiente para ganhar consistência
- O significado da UI ficar pouco claro apenas com utilitários

Exemplos:

- Use utilitários para espaçamento de seção, alinhamento, largura e layout flex.
- Use um componente documentado para alertas, inputs, tabs, menus e feedback interativo.

## Mapeamento A Partir De Screenshot Ou Mockup

Quando a entrada for apenas visual:

1. Identifique cada bloco visível pela finalidade, não pela forma em CSS.
2. Marque primeiro os padrões repetidos, porque eles são os melhores candidatos a um componente Liquid reutilizável.
3. Mapeie as áreas de interação de maior risco antes dos detalhes decorativos.
4. Use utilitários do Liquid para reproduzir o ritmo de espaçamento e layout.
5. Só recorra a markup de fallback quando nenhum componente documentado for adequado.

## Regras De Acessibilidade

Toda decisão de componente deve preservar a semântica:

- Links navegam
- Botões executam ações
- Labels permanecem conectadas aos inputs
- Títulos definem hierarquia
- Mensagens de status continuam compreensíveis sem depender apenas de cor ou ícones

Se existirem duas opções visualmente parecidas, prefira a que tiver semântica mais clara.

## Regras De Fallback

Se não for possível encontrar um componente exato:

- Escolha o padrão Liquid documentado mais próximo
- Complete a lacuna com HTML semântico e utilitários do Liquid
- Adicione CSS mínimo e com escopo restrito somente se necessário
- Mantenha o fallback fácil de substituir depois por um componente oficial

Não faça:

- Inventar uma biblioteca de componentes customizada ao lado do Liquid
- Codificar um design language separado
- Adicionar estrutura custom pesada para um problema já resolvido por um padrão Liquid

## Expectativas De Saída

Ao usar esta instrução em uma resposta ou edição:

- Informe qual componente, utilitário ou padrão Liquid foi escolhido quando o mapeamento não for óbvio
- Cite o título da entrada extraída correspondente e a URL da documentação usada na decisão
- Prefira escolhas explícitas de componente em vez de orientações vagas de estilo
- Mantenha o uso de fallback customizado claramente limitado e justificado
- Otimize para consistência, reutilização e manutenção entre projetos
- Mantenha as mudanças de código restritas ao escopo da funcionalidade e evite churn desnecessário em outros arquivos.

## Referências Preferenciais

Use estas referências nesta ordem de prioridade:

1. `.github/assets/liquid-storybook-docs-text.json`
2. `.github/assets/liquid-storybook-catalog.json`
3. URLs do Liquid Storybook (`docsUrl` das entradas extraídas)

## Catálogo E `docs-text` (JSON)

O catálogo e os textos de documentação dos componentes devem existir como arquivos JSON no repositório e ser usados como fonte única de verdade para mapeamentos:

- Arquivos esperados: `.github/assets/liquid-storybook-catalog.json` (lista de componentes/variantes) e `.github/assets/liquid-storybook-docs-text.json` (textos e notas de uso).
- Estrutura mínima: `catalog` é um array de objetos com `id`, `title`, `docsUrl`, `variants`; `docs-text` é um objeto { chave: texto } referenciando `id` ou `title`.
- Processo: ao mapear um elemento, cite a entrada do `catalog` e um trecho do `docs-text` que justifique a escolha.
- Mantenha ambos os arquivos atualizados e com JSON válido (formatado e lintado) antes de merges.

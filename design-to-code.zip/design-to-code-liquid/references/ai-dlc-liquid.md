﻿## Regras para seleção de HTML/componente Liquid

Quando a entrada for um contexto figma, imagem, wireframe, screenshot ou descrição visual:

1. Identifique cada bloco visual pela **intenção**, não apenas pela aparência.
2. Classifique o elemento como: ação, entrada, navegação, feedback, conteúdo, data display, overlay, mídia ou layout.
3. Use a instruction de seleção de Liquid como referência principal para componentes e utilitários.
4. Escolha sempre a menor solução oficial que preserve semântica, comportamento e acessibilidade.
5. Se existir componente oficial Liquid, use-o. Se não existir, combine HTML semântico com classes `brad-*`.
6. Use `declare let LiquidCorp: ILiquidCorp` para acionar serviços JS do Liquid em runtime.
7. Sempre verificar `typeof LiquidCorp !== 'undefined'` antes de qualquer chamada ao LiquidCorp.

---

## Regras de compatibilidade com Liquid

- Antes de escolher os componentes verifique se o projeto já inclui o Liquid.
- Se o projeto não incluir Liquid, a inclusão é obrigatória antes da construção do componente. Pare de imediato e peça pra incluir.
- Considere Liquid presente somente quando houver evidência objetiva no projeto, como index.html com *.css e*.js do liquid disponiveis.
- Use como referência mínima o seguinte padrão no `index.html`:

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
 <meta charset="utf-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1" />
 <title>Design System Liquid demo</title>

 <!-- CDN: das folhas de estilos liquid -->
 <link
  href="https://static.bradesco.com.br/dsysliquid/dist/design-system-3.1.0/reset.bundle.min.css"
  rel="stylesheet"
 />
 <link
  href="https://static.bradesco.com.br/dsysliquid/dist/design-system-3.1.0/design-system.bundle.min.css"
  rel="stylesheet"
 />
 <!-- CDN: das folhas de estilos liquid -->
</head>

<body class="brad-theme-classic">
 <app-root></app-root>

 <!-- CDN: dos serviços liquid -->
 <script
  src="https://static.bradesco.com.br/dsysliquid/dist/design-system-3.1.0/design-system.bundle.min.js"
  integrity="sha256-kgjvGt9LG/8LbJi1yVHRamp/YMHKKpMW5RXoo3G/p6Q="
  crossorigin="anonymous"
 ></script>
 <!-- CDN: dos serviços liquid -->
</body>
</html>
```

- Registre na entrega qual mecanismo de inclusão foi usado e quais premissas de runtime são necessárias para `LiquidCorp` funcionar.
- Consulte as instructions de mapeamento de Liquid antes de criar markup novo.
- Não recrie componente oficial quando o Liquid já cobrir o caso.
- Quando houver componente oficial Liquid, use os exemplos, markup e observações do `liquid-storybook-docs-text.json` como base da implementação Angular e registre a `docsUrl` da mesma entrada desse arquivo.
- Se a entrada correspondente do `docs-text` não trouxer `docsUrl`, pare e solicite confirmação mínima antes de seguir.
- Preserve semântica HTML: links navegam, botões executam ação, `label` associado ao `input`.
- Mensagens de status devem ser acessíveis sem depender apenas de cor.
- Classes de espaçamento: `brad-p-{size}-{dir}` / `brad-m-{size}-{dir}`.
- Ícones: `<em class="i icon-<categoria>-<nome>">`.
- Priorize `aria-label`, `aria-hidden` e `role` para acessibilidade.

## Catálogo e `docs-text` (JSON)

Todas as decisões de mapeamento e seleção de componentes devem, quando possível, referenciar os arquivos JSON canônicos de catálogo e documentação:

- Local esperado: `assets/liquid-storybook-catalog.json` e `assets/liquid-storybook-docs-text.json`.
- Recomenda-se que `catalog.json` seja um array de entradas com `id`, `title`, `docsUrl`, `variants` e `type` e que `docs-text.json` contenha descrições e notas por `id` ou `title`.
- Workflow: ao gerar HTML, inclua a referência à entrada do `catalog` usada (ex.: `catalog[id]`) e, se relevante, um trecho do `docs-text` que justifique o comportamento (ex.: aria, keyboard, lifecycle).
- Atualizações: mantenha os JSONs atualizados a partir do Storybook oficial; valide estrutura JSON e adicione changelog simples quando entradas forem atualizadas.

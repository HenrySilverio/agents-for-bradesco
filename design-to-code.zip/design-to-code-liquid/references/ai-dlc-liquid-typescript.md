---
description: "Use quando escrever código TypeScript/Angular que integre o Design System Liquid Bradesco — incluindo inicialização de serviços LiquidCorp, configuração de BradTable, regras de estabilidade de serviços Angular e premissas de runtime para serviços JS do Liquid."
applyTo: "**/*.ts"
---

## Objetivo

Use esta instrução quando um componente, serviço ou módulo TypeScript precisar inicializar ou interagir com serviços JavaScript do Liquid (`LiquidCorp.*`).

Sempre procure a menor solução oficial do Liquid que preserve o comportamento pretendido.

Prefira esta ordem:

1. Componente Liquid existente com serviço JS documentado
2. Template ou padrão Liquid documentado
3. Classes utilitárias do Liquid + HTML semântico
4. Fallback customizado com escopo reduzido

## Regra Principal

Sempre procure a menor solução oficial do Liquid que preserve o comportamento, a hierarquia e a semântica pretendidos. Não adicione JavaScript apenas para imitar um padrão visual - se nenhum serviço for necessário, omita-o.

## Orientação De Uso Em TypeScript

Se um componente depender de serviços JavaScript documentados do Liquid:

- Declare `LiquidCorp` em TypeScript antes de usar.
- Inicialize o serviço apenas depois que o elemento-alvo estiver presente no DOM.
- Mantenha o binding próximo do componente responsável.
- Evite orquestração global quando um controlador local de página ou seção for suficiente.
- Sempre verifique `typeof LiquidCorp !== 'undefined'` antes de qualquer chamada em runtime.

### Regras De Estabilidade Em Angular

Quando a solução Liquid selecionada depender de um serviço JavaScript em Angular:

- Trate o timing de inicialização, a visibilidade do host e o estado do primeiro render como parte da decisão de seleção do componente.
- Prefira a opção que minimize mutações após a inicialização.
- Se o serviço injetar DOM próprio, planeje como os estilos alcançarão esse DOM antes de assumir que CSS escopado do componente será suficiente.
- Valide o serviço selecionado na rota real quando ele controlar layout, responsividade ou overlays.

### Regras De Seleção E Integração Do BradTable

Quando a solução selecionada for `BradTableService`:

- Prefira primeiro a configuração documentada de tabela HTML e só adicione formatadores customizados depois que o render básico estiver estável.
- Modele o estado visual nos dados da linha (por exemplo, classe de badge ou estado de atraso) em vez de derivá-lo depois a partir do DOM renderizado.
- Mantenha os formatadores determinísticos e limitados a preocupações de renderização.
- Evite um `replaceData` imediato ou refresh equivalente após `getInstance()`, a menos que os dados realmente tenham mudado.
- Se usar `layout: "fitColumns"` com collapse responsivo e a tabela apresentar instabilidade de render ou resize, prefira um `height` documentado explícito antes de considerar fallback.
- Quando o modo collapse for usado, valide tanto no desktop quanto em larguras menores antes de considerar o mapeamento concluído.

## Expectativas De Saída

Ao usar esta instrução em uma resposta ou edição:

- Informe qual serviço JS do Liquid foi escolhido e por quê.
- Quando `BradTableService` for selecionado, mencione as escolhas documentadas de configuração usadas para responsividade e atualização de dados, se isso for relevante para a correção.
- Quando um serviço JavaScript do Liquid for selecionado, descreva as premissas de runtime que importam para um render estável.
- Mantenha as mudanças de código restritas ao escopo da funcionalidade e evite churn em arquivos não relacionados.

## Referências Preferenciais

Use estas referências nesta ordem de prioridade:

1. `.github/assets/liquid-storybook-docs-text.json`
2. `.github/assets/liquid-storybook-catalog.json`
3. URLs do Liquid Storybook (`docsUrl` das entradas extraídas)

## Catálogo E `docs-text` (JSON)

Os dados de catálogo e os textos de documentação dos componentes devem existir como arquivos JSON no repositório e ser a fonte canônica para mapeamentos e decisões de implementação.

- Localização esperada: `.github/assets/liquid-storybook-catalog.json` e `.github/assets/liquid-storybook-docs-text.json`.
- Formato mínimo recomendado:
  - `liquid-storybook-catalog.json`: array de entradas `{ "id": string, "title": string, "docsUrl": string, "variants": [string], "type": "HTML"|"WebComponent"|"Utility" }`.
  - `liquid-storybook-docs-text.json`: mapeamento `{ "componentIdOrTitle": "descrição detalhada ou notas de uso" }`.
- Uso: consulte primeiro `docs-text` para entender comportamento e restrições; use `catalog` para localizar variantes e URLs de documentação.
- Atualizações: ao atualizar mapeamentos ou extrair novas entradas do Storybook, atualize os arquivos JSON e valide o JSON (lint/format) antes de commitar.

@echo off
rem Atalho do harness-metricas: roda de qualquer pasta, sem depender do diretório aberto no VS Code.
rem Uso:  C:\Users\<voce>\.copilot\harness-metricas\hm.cmd doutor
where node >nul 2>nul || (echo [ERRO] Node nao encontrado no PATH. Instale o Node 18+ ou abra um terminal com o Node disponivel. & exit /b 1)
node -e "const m=+process.versions.node.split('.')[0];if(m<18){console.error('[ERRO] harness-metricas precisa de Node 18+. Voce tem '+process.version);process.exit(1)}" || exit /b 1
node "%~dp0bin\hm.mjs" %*

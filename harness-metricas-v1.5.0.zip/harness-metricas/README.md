# harness-metricas

Mede o que o seu harness de IA entrega — tempo, guard-rails, tokens, custo e qualidade — e gera um
dashboard HTML autocontido, em cores Bradesco, para apresentar à gerência e ao negócio.

Funciona sobre o que você já tem: **SDD** (`plan → implement → review → archive`), **discovery**
(`rota`, `triagem`, `grill`, `prototipo`) e **design-to-code-liquid**. Nenhum arquivo desses toolkits
é alterado — a camada de métricas só observa.

---

## A decisão de projeto que sustenta tudo

**Agente nenhum coleta métrica.** Um LLM não tem acesso ao próprio consumo de tokens, ao relógio nem
ao custo; se você pedir, ele inventa um número plausível. Número inventado em slide de gerência é
risco de credibilidade, não ganho de produtividade.

| Papel | Quem faz | Por quê |
|---|---|---|
| Coletar evento (tempo, ferramenta, artefato, guard-rail) | **hook** em Node, zero dependência | Determinístico, roda sempre, custa **zero token** |
| Medir token, modelo e cache | **exportador OpenTelemetry do Copilot Chat** (arquivo JSONL) | Única fonte real de consumo |
| Agregar, precificar, correlacionar | **script** (`hm build`) | LLM erra conta; script é reprodutível e auditável |
| Escrever a leitura executiva | **agente** (`metricas-narrador`, modelo barato) | Texto é o que LLM faz bem |
| Conferir a leitura executiva | **script** (portão anti-alucinação) | Todo número precisa citar a chave de origem |

O fluxo inteiro:

```
VS Code + Copilot
   │  hooks (8 eventos)            OTel file exporter
   ▼                                     │
dados/eventos/<sessao>.jsonl        dados/otel/*.jsonl
   │                                     │
   └──────────────┬──────────────────────┘
                  ▼
        hm build  (correlaciona, precifica, agrupa em atividades)
                  │
      ┌───────────┼─────────────────────┐
      ▼           ▼                     ▼
  dados.json  resumo-narrativa.json  dashboard.html
                  │                     ▲
                  ▼                     │
         agente metricas-narrador → narrativa.md → portão de números
```

---

## Fase 0 — spike de 1 dia (faça isto antes de qualquer outra coisa)

Três coisas não dá para saber sem rodar na máquina do banco. O comando `hm diagnostico` responde as três.

1. **Hooks são permitidos?** Ver a seção abaixo — criar `.github/hooks` não prova nada.
2. **Hook de usuário vale nos repos que já têm `.github/hooks`?** A documentação diz que *"workspace
   hooks take precedence over user hooks for the same event type"*. Se o diagnóstico mostrar eventos
   em um repo e nenhum no outro, rode `hm instalar --workspace <repo>` no repositório afetado.
3. **`session_id` do hook bate com `gen_ai.conversation.id` do OTel?** O diagnóstico imprime
   `conversation.id = session_id  N/M`. Se for baixo, a correlação cai para a janela de horário
   (funciona, mas gera o alerta "correlação ambígua" quando duas sessões rodam em paralelo).

### Hooks estão liberados nesta máquina? (5 minutos)

**Conseguir criar a pasta e os arquivos não prova nada** — isso é permissão de sistema de arquivos.
O bloqueio é por política: `ChatHooks` desligado configura o setting `chat.useHooks`, e aí *"hook
configurations are ignored and no hook commands are executed during agent sessions"*. O VS Code ignora
o arquivo em silêncio, sem erro, sem aviso.

**A prova definitiva — canário (roda em 1 prompt):**

```bat
node bin\hm.mjs verificar-hooks
:: feche e reabra o VS Code, mande UM prompt em modo agente que leia um arquivo, e:
node bin\hm.mjs verificar-hooks --conferir
node bin\hm.mjs verificar-hooks --limpar
```

O canário instala um hook nos 8 eventos que só acrescenta uma linha num arquivo. Se nenhuma linha
aparecer, hooks não executam nesta máquina; se aparecer, o veredito mostra quais eventos chegaram, em
quais repositórios e se o `session_id` vem preenchido.

**As checagens manuais, na ordem (faça em paralelo com o canário):**

| # | Onde | O que olhar | Leitura |
|---|---|---|---|
| 1 | Paleta de comandos → `Chat: Configure Hooks` (ou `/hooks` no chat) | o comando existe? | Não existe → sua versão do VS Code não tem a superfície de hooks |
| 2 | Settings (`Ctrl+,`) → `chat.useHooks` | valor e se está marcado como gerenciado pela organização | `false` gerenciado → **bloqueado por política** |
| 3 | Paleta → `Developer: Policy Diagnostics` | procure `ChatHooks` na lista de políticas aplicadas | aparece com `false` → confirmado, é política; fale com o admin |
| 4 | `%USERPROFILE%\.copilot\settings.json` | chave `disableAllHooks` | `true` → desligado por você mesmo, não pela empresa |
| 5 | Output (`Ctrl+Shift+U`) → canal **GitHub Copilot Chat Hooks** | erro de JSON ou de comando | hook cai aqui quando o arquivo está malformado ou o comando falha |
| 6 | Paleta → `Developer: Show Agent Debug Logs` | o que o agente executou na sessão | confirma execução evento a evento |

**Se o passo 3 confirmar a política:** o pedido ao admin é específico — liberar a política `ChatHooks`
(setting `chat.useHooks`) para o seu grupo. Vale pedir com o argumento certo: os hooks aqui são
*read-only* de telemetria, não alteram comportamento do agente, não injetam contexto e não enviam nada
para fora da máquina.

**Se estiver bloqueado mesmo assim**, o pacote degrada em vez de morrer: sem hooks, o build usa só o
JSONL do OpenTelemetry. Você perde tempo ativo por sessão, guard-rails, sondas de artefato e o vínculo
com atividade; continua tendo tokens, custo, modelo por conversa e cache. Cada conversa vira uma sessão
"sem toolkit", e o painel marca a cobertura como parcial.

O diagnóstico ainda imprime o inventário de atributos dos spans (para você apontar, em
`toolkits.json > otel`, qual atributo carrega a decisão `deny`/`ask` dos hooks de guarda), os nomes
reais das ferramentas (para ajustar as categorias) e os modelos sem preço.

---

## Deu erro? Comece pelo doutor

```bat
node bin\hm.mjs doutor --repo C:\Users\<voce>\Documents\Projetos\<seu-repo>
```

Checa Node (18+), integridade do pacote, config, pasta de dados gravável, hook de usuário (inclusive
se aponta para um caminho que não existe mais), hooks do repositório e a precedência de workspace,
`.git/info/exclude`, OpenTelemetry (variáveis e arquivo), sessões ativas, eventos gravados e o log de
erros do coletor — e termina com a lista do que fazer.

### Qual terminal

O terminal integrado do VS Code no Windows é **PowerShell**, não `cmd`. Os blocos deste README usam
`cmd` (comentário `::`, variável `%VAR%`). Se você estiver no PowerShell, três coisas mudam:

| | PowerShell | cmd |
|---|---|---|
| variável de ambiente | `$env:USERPROFILE` | `%USERPROFILE%` |
| comentário | `#` | `::` |
| executar um caminho guardado em variável | `& $env:HM ajuda` | `"%HM%" ajuda` |

**Não crie atalho com `%HM%`.** No PowerShell, `"%HM%" ajuda` falha com
`ParserError: Token 'ajuda' inesperado` — ele lê a linha inteira como texto. A forma que funciona nos
dois shells, de qualquer pasta, é o caminho completo do arquivo:

```
node "%USERPROFILE%\.copilot\harness-metricas\bin\hm.mjs" doutor
```

(no PowerShell, troque `%USERPROFILE%` pelo caminho literal, ex.: `C:\Users\i459249`). Se quiser mesmo
um atalho no PowerShell, a forma correta é uma função no `$PROFILE`:

```powershell
function hm { node "$env:USERPROFILE\.copilot\harness-metricas\bin\hm.mjs" @args }
```

O `hm.cmd` do pacote continua existindo e funciona no `cmd`; no PowerShell ele exige o operador de
chamada: `& "C:\...\harness-metricas\hm.cmd" doutor`.

---

## Instalação (Windows, máquina do banco)

```bat
:: 1. copie a pasta
xcopy /E /I harness-metricas "%USERPROFILE%\.copilot\harness-metricas"
cd /d "%USERPROFILE%\.copilot\harness-metricas"

:: 2. escreva o arquivo de hooks e veja as instruções do OTel
node bin\hm.mjs instalar

:: 3. ligue o OTel do Copilot (uma vez; reabra o VS Code depois)
setx COPILOT_OTEL_ENABLED true
setx COPILOT_OTEL_FILE_EXPORTER_PATH "%USERPROFILE%\.copilot\harness-metricas\dados\otel\copilot-otel.jsonl"

:: 4. agente da narrativa
copy agents\metricas-narrador.agent.md "%USERPROFILE%\.copilot\agents\"
```

Requisitos: Node 18+ (usa só módulos nativos), VS Code com a superfície atual de customização do
Copilot. Nenhum pacote npm, nenhum install global, nada commitado em repositório de produto.

> **`captureContent` fica em `false`.** Com `true`, o OTel grava prompt, resposta e conteúdo de
> arquivo em disco — inaceitável com dados de cliente. O padrão já é `false`; não mude.

### Se o repositório já tiver hooks

```bat
node bin\hm.mjs instalar --workspace C:\dev\recr-fed-agc-posvenda
```

Escreve `.github/hooks/harness-metricas.json` no repo. **Não commite**: adicione a linha em
`.git\info\exclude`.

---

## Quais sessões são medidas

Modo padrão: **`marcador`** — nada é gravado até você pedir. Chat exploratório, pergunta rápida e
teste de prompt ficam fora do painel.

```bat
:: no chat, em qualquer prompt da sessão (de preferência o primeiro):
::   /sdd-implement REAB-412 primeira fatia   #medir
::   analisa esse bug   +medir          (o prefixo + evita o seletor de contexto do VS Code)
::
:: parar no meio:  #nao-medir

node bin\hm.mjs medir status          :: modo, marcador e sessões ativas
node bin\hm.mjs medir parar <sessao>  :: desliga uma sessão
node bin\hm.mjs medir limpar          :: remove ativações com mais de 7 dias
```

Quando o marcador aparece, o coletor sintetiza um `SessionStart` com repositório, branch e commit do
momento e passa a gravar a sessão inteira. O que veio antes do marcador não é gravado.

Outros modos em `config/parametros.json` → `coleta.modo`: `comandos` (mede sozinho toda sessão com
`/sdd-*`, `/discovery-*` ou design-to-code), `marcador+comandos`, `interruptor` (`hm medir on|off`) e
`tudo`. Em qualquer modo, `coleta.repos_permitidos` restringe por repositório.

---

## Registrar um fluxo seu (ex.: depuração)

Sessões que não usam SDD, discovery ou design-to-code aparecem como "sem toolkit" até você registrar
o comando ou o agente correspondente:

```bat
node bin\hm.mjs harness listar --repo C:\dev\seu-repo      :: descobre os nomes reais
node bin\hm.mjs toolkit depuracao --comandos depurar --agentes depurador --rotulo "Depuração"
```

Isso edita `config/toolkits.json` — o mesmo arquivo que você pode ajustar à mão. `--remover` desfaz.

---

## Puxar os artefatos do harness de cada repositório

```bat
:: o que existe num repo e no seu nível de usuário
node bin\hm.mjs harness listar --repo C:\dev\recr-fed-agc-posvenda

:: levar de um repo para outro (sempre simule antes)
node bin\hm.mjs harness copiar --de C:\dev\repo-a --para C:\dev\repo-b --tipos prompts,skills --simular
node bin\hm.mjs harness copiar --de C:\dev\repo-a --para C:\dev\repo-b --tipos prompts,skills

:: promover para o nível de usuário (vale em todos os repos da máquina)
node bin\hm.mjs harness promover --de C:\dev\repo-a --tipos agents,skills
```

Tipos e destinos: `instructions` (`.github/instructions/` · `~/.copilot/instructions/`), `prompts`
(`.github/prompts/` · `~/.copilot/prompts/`), `agents` (`.github/agents/`, `.claude/agents/` ·
`~/.copilot/agents/`), `skills` (`.github/skills/`, `.agents/skills/`, `.claude/skills/` ·
`~/.copilot/skills/`), `hooks` (`.github/hooks/` · `~/.copilot/hooks/`). Nada é sobrescrito sem
`--forcar`.

---

## Manual para o time

```bat
node bin\hm.mjs manual
```

Gera um HTML autocontido com os caminhos já resolvidos para a máquina onde o comando rodou:
instalação, verificação dos hooks, como escolher o que é medido, rotina de uma tarefa, como puxar os
artefatos, privacidade, problemas comuns e glossário. É o arquivo para anexar no Teams.

---

## Uso diário

```bat
:: antes de começar a tarefa (é isto que dá credibilidade ao número)
node bin\hm.mjs estimar REAB-412 32 --nota "planning poker da squad"

:: ou, sem sair do chat, dentro do primeiro prompt do /sdd-plan:
::   /sdd-plan REAB-412 ... estimativa-sem-ia: 32h

:: o que está faltando para o painel ficar honesto
node bin\hm.mjs pendencias

:: gerar o painel
node bin\hm.mjs build --de 2026-09-01 --ate 2026-09-30
```

Comandos de apoio: `verificar-hooks` (canário), `vincular <sessao> <atividade>` (corrige agrupamento), `ignorar <sessao>`,
`concluir <atividade>` (para fluxos que não terminam em `/sdd-archive`, como o design-to-code),
`guardar-otel` (arquiva o JSONL do OTel antes que ele seja truncado — spans repetidos são
deduplicados no build).

### Leitura executiva (opcional, um modelo barato)

```
node bin\hm.mjs build
```
O build grava `resumo-narrativa.json` (≈1 KB). No Copilot Chat, com o agente `metricas-narrador`:

```
#readFile <pasta do relatório>\resumo-narrativa.json
```

O agente cria `narrativa.md` na mesma pasta. Rode o build de novo: ele **confere cada número contra a
chave citada** e só então embute o texto no dashboard. Número sem chave, chave inexistente ou valor
diferente → narrativa recusada, com a lista de problemas no terminal.

---

## Como cada número é calculado

| Métrica | Tipo | Como |
|---|---|---|
| Tempo ativo | Medido | Soma dos intervalos entre eventos da sessão; intervalo acima de `limiar_ociosidade_min` (10 min) não conta |
| Tempo com IA | Derivado | Tempo ativo × (1 + `sobrecarga_humana_fora_sessao_pct`), hoje 30%, para cobrir revisão de PR e teste manual |
| Horas sem IA — cega | Estimado | O dev registra **antes** da primeira edição de código. Registrou depois? Vira "não cega" e sai do KPI |
| Horas sem IA — paramétrica | Estimado | Unidades observadas (fatias de `tarefas.md`, testes criados, briefings, componentes e páginas do design-to-code) × `calibracao.json` |
| Referência | Estimado | `estrategia_referencia` = `minimo`: o **menor** valor entre cega e paramétrica. Resistente a estimativa inflada |
| Horas economizadas | Estimado | Referência − tempo com IA, só para atividades **concluídas**, reconhecidas na data de conclusão |
| Tokens | Medido | `gen_ai.usage.*` dos spans `chat` do OTel; detecta sozinho se `input_tokens` já inclui cache |
| Custo de consumo | Derivado | Tokens × `precos.json`. **Valor de lista, não desembolso** — o Business inclui créditos por usuário |
| Economia do roteamento | Estimado | Os mesmos tokens precificados no `modelo_referencia_roteamento`. Mostra o ganho da doutrina de modelo por etapa |
| Guard-rails | Medido | Decisões `deny`/`ask` (spans `execute_hook` e contrato file-drop), falhas de portão do validador, git de escrita interrompido |
| Aprovação na 1ª revisão | Medido | Primeiro veredito de cada eixo em `revisao/<eixo>-<commit>.md` |
| Lacunas explicitadas | Medido | Marcadores `[NÃO RESPONDIDO]` na última versão de cada briefing |
| Aderência ao Liquid | Derivado | Elementos `brad-*` no template vs. declarações CSS custom por componente gerado |

### Como as sessões viram uma atividade

Cada sessão produz chaves: ticket (do prompt, da proposta ou do nome da branch), mudança SDD, slug de
briefing e branch. Chaves que aparecem **na mesma sessão** são unidas (união-busca). É assim que a
sessão de discovery entra na mesma atividade do ticket: o `/sdd-plan` lê o briefing e escreve a
proposta, ligando `briefing:<slug>` a `ticket:<ABC-1>`. Branches de integração (`main`, `develop`,
`release/*`) não viram chave. Quando o agrupamento errar, `hm vincular` resolve.

### O que o painel **não** mede — e diz isso na cara

- **Causalidade por camada.** O painel mostra uso e custo de cada toolkit, não quanto do ganho vem de
  cada um. Isso só sai de experimento controlado: a mesma tarefa com e sem a camada.
- **Tempo humano fora da sessão.** Coberto apenas pela sobrecarga fixa de 30%.
- **Qualidade em produção.** Incidentes, defeitos pós-merge e achados do Mend ainda não entram.
- **Desembolso.** O custo é de lista.

---

## Calibrar a tabela paramétrica (obrigatório antes de apresentar)

`config/calibracao.json` vem com valores de exemplo, e o painel avisa isso em vermelho no topo.
Para calibrar: pegue 8 a 10 tarefas já entregues **sem IA**, três devs estimam cada uma sem ver o tempo
real, divida pelo número de unidades de cada tarefa e registre a mediana. Preencha `calibrado_por` e
`calibrado_em` — o dashboard exibe os dois.

---

## Privacidade e LGPD

O coletor **nunca** grava: texto de prompt, conteúdo de arquivo, texto de comando de terminal
(pode conter credencial), caminho absoluto (o nome da pasta do usuário é dado pessoal) e resposta de
ferramenta. O que vai para disco é: carimbo de tempo, nome da ferramenta, categoria, caminho relativo,
classe do comando, resultado (sucesso/falha) e o fato extraído pela sonda (ticket, nº de fatias,
veredito, contagem de marcadores). O teste `test/coletor.test.mjs` verifica isso a cada mudança.

Consequência prática: o arquivo de sessão pode ser compartilhado com a tribo sem revisão de conteúdo —
é o que torna a fase 2 (agregação por squad, com o dev pseudonimizado) barata.

---

## Contrato para os hooks de guarda que já existem

O `guard-invariants.mjs` (e qualquer outro hook de guarda) não importa nada deste pacote. O acoplamento
é uma variável de ambiente e um formato de linha:

```js
// no fim da decisão do seu hook de guarda:
const destino = process.env.HARNESS_METRICAS_GUARDRAILS;
if (destino) {
  try {
    fs.appendFileSync(destino, JSON.stringify({
      v: 1, t: new Date().toISOString(), sid: entrada.session_id,
      hook: 'guard-invariants', regra: 'contrato-federation',
      decisao: 'ask', categoria: 'contrato', alvo_tipo: 'arquivo-contrato',
    }) + '\n');
  } catch { /* métrica nunca atrapalha a guarda */ }
}
```

Sem a variável, nada acontece. Formato completo em `schemas/guardrail-evento.schema.json`.

Se os spans `execute_hook` do OTel já expuserem a decisão (o `hm diagnostico` mostra), **não use as duas
fontes ao mesmo tempo** — o mesmo bloqueio contaria duas vezes. Escolha uma.

---

## Estrutura

```
bin/hook.mjs       coletor (observador puro: sempre exit 0, stdout "{}", zero token)
bin/hm.mjs         CLI: doutor, medir, toolkit, harness, manual, verificar-hooks, instalar, diagnostico, estimar, build, demo
hm.cmd             atalho Windows: roda de qualquer pasta e confere o Node antes
bin/canario.mjs    canário independente: prova se o Copilot executa hooks nesta máquina
lib/coletor.mjs    lógica do hook (sondas, classificação, diff)
lib/otel.mjs       parser tolerante do JSONL do OTel + agregação por conversa
lib/projecao.mjs   eventos + OTel + estimativas → dados.json (função pura, reprodutível)
lib/narrativa.mjs  resumo para o agente + portão anti-alucinação
lib/dashboard.mjs  HTML autocontido, paleta Bradesco
lib/harness.mjs    inventário e cópia de skills/agents/prompts/instructions/hooks
lib/manual.mjs     manual HTML autocontido (hm manual)
lib/demo.mjs       gerador de dados sintéticos (6 semanas, 13 atividades)
config/*.json      toolkits (como observar), calibracao (quanto vale), precos, parametros
schemas/*.json     contrato do evento bruto e do file-drop de guard-rails
test/*.test.mjs    node --test "test/*.test.mjs"
```

Adicionar um toolkit novo é editar `config/toolkits.json`: comando, agente ou arquivo de gatilho,
sondas de artefato e regra de contagem de unidade. Nenhuma linha de código.

---

## Demonstração

```bat
node bin\hm.mjs demo
```

Gera 6 semanas de dados sintéticos (65 sessões, 13 atividades, incluindo uma reprovação de revisão,
uma estimativa inflada, uma registrada tarde e uma violação de invariante) e abre o mesmo caminho de
build dos dados reais. O painel resultante fica marcado como **DADOS SINTÉTICOS** em dois lugares.

## Testes

```bat
node --test "test/*.test.mjs"
```

41 testes: porta de entrada da coleta (marcador liga, frase normal não liga, `#nao-medir` desliga),
privacidade do coletor, sondas, diff, parser OTel (dois formatos, cache, subagente, dedup), união de
atividades, regra da estimativa cega, tempo ativo, precificação, portão da narrativa, cópia de
artefatos (não sobrescreve sem `--forcar`), geração do manual e autocontenção do HTML.

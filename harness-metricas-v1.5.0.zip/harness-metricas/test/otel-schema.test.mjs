import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { formatarSonda, sondarOtel } from '../lib/otel-schema.mjs';

const SEGREDO = 'refinanciar a divida do cliente 123 na agencia 4567';

function arquivo(linhas) {
  const dir = mkdtempSync(join(tmpdir(), 'hm-otel-'));
  const arq = join(dir, 'copilot-otel.jsonl');
  writeFileSync(arq, `${linhas.map((l) => JSON.stringify(l)).join('\n')}\n`);
  return arq;
}

test('a sonda revela a forma e os nomes de atributo', async () => {
  const arq = arquivo([
    { resourceSpans: [{ scopeSpans: [{ spans: [{ name: 'chat', traceId: 't', attributes: [{ key: 'gen_ai.usage.input_tokens', value: { intValue: '27242' } }] }] }] }] },
    { body: { eventName: 'turn', prompt: SEGREDO } },
  ]);
  const r = await sondarOtel(arq);
  assert.equal(r.linhas, 2);
  assert.equal(r.invalidas, 0);
  assert.ok(r.nomesAtributo.includes('gen_ai.usage.input_tokens'));
  assert.ok([...r.mapa.keys()].some((k) => k.includes('scopeSpans[].spans[].name')));
  assert.ok([...r.topo.keys()].includes('resourceSpans'));
});

// A sonda existe para ser colada num chat de suporte. Se ela vazar conteúdo de prompt,
// é pior que o problema que resolve.
test('a sonda nunca imprime valor de string fora dos campos de esquema', async () => {
  const arq = arquivo([
    { body: { prompt: SEGREDO, userText: SEGREDO, arguments: { query: SEGREDO } } },
    { name: 'chat', model: 'gpt-5.6-luna', attributes: { 'gen_ai.prompt': SEGREDO } },
  ]);
  const texto = formatarSonda(await sondarOtel(arq), arq);
  assert.ok(!texto.includes(SEGREDO), 'vazou conteúdo de prompt');
  assert.ok(!texto.includes('refinanciar'), 'vazou fragmento de prompt');
  assert.ok(texto.includes('<string:'), 'deveria mostrar o tamanho no lugar do valor');
  assert.ok(texto.includes('"chat"'), 'campo de esquema name deveria sair inteiro');
});

test('arquivo só com linhas inválidas não quebra a sonda', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'hm-otel-'));
  const arq = join(dir, 'copilot-otel.jsonl');
  writeFileSync(arq, 'isso nao e json\n{quebrado\n');
  const r = await sondarOtel(arq);
  assert.equal(r.linhas, 2);
  assert.equal(r.invalidas, 2);
  assert.doesNotThrow(() => formatarSonda(r, arq));
});

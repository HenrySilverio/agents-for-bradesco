import { test } from 'node:test';
import assert from 'node:assert/strict';
import { carregarTudo } from '../lib/config.mjs';
import { gerarManual } from '../lib/manual.mjs';

const cfg = carregarTudo();

test('o manual sai autocontido e com as seções que o time precisa', () => {
  const html = gerarManual(cfg, { baseExibida: 'C:\\Users\\fulano\\.copilot\\harness-metricas' });
  assert.ok(!/<script[^>]+src=/i.test(html), 'script externo');
  assert.ok(!/<link[^>]+href=/i.test(html), 'css externo');
  for (const t of ['Instalar o pacote na sua máquina', 'Escolher quais sessões são medidas', 'Medir uma sessão avulsa', 'Puxar os harnesses', 'O que é e o que não é gravado', 'Glossário']) {
    assert.ok(html.includes(t), `faltou a seção: ${t}`);
  }
});

test('nenhum escape de template vira caractere de controle no HTML', () => {
  const html = gerarManual(cfg, { baseExibida: 'C:\\Users\\fulano\\.copilot\\harness-metricas' });
  const controle = [...html].filter((c) => c.charCodeAt(0) < 32 && !'\n\r\t'.includes(c));
  assert.equal(controle.length, 0, `caracteres de controle no HTML: ${controle.map((c) => c.charCodeAt(0))}`);
  assert.ok(html.includes('C:\\Users\\fulano\\.copilot\\harness-metricas\\bin\\hm.mjs'), 'o caminho do hm.mjs saiu quebrado');
});

test('o caminho exibido é o que foi pedido, não o da máquina que gerou', () => {
  const html = gerarManual(cfg, { baseExibida: 'D:\\ferramentas\\hm' });
  assert.ok(html.includes('D:\\ferramentas\\hm\\dados\\otel\\copilot-otel.jsonl'));
  assert.ok(!html.includes('/home/claude'));
});

// Regressão da falha real em campo: o manual mandava "%HM%" ajuda, que é sintaxe de cmd.
// No PowerShell (terminal padrão do VS Code no Windows) isso morre com ParserError, e o
// usuário lê o erro como bug do pacote. Todo comando colável precisa ser neutro de dialeto.
test('nenhum comando colável depende do dialeto do shell', () => {
  const base = 'C:\\Users\\fulano\\.copilot\\harness-metricas';
  const html = gerarManual(cfg, { baseExibida: base });
  const blocos = [...html.matchAll(/<pre id="cmd\d+">([\s\S]*?)<\/pre>/g)].map((m) => m[1]);
  assert.ok(blocos.length > 5, 'esperava vários blocos de comando');

  const executaveis = blocos.flatMap((b) => b
    .split('\n')
    .filter((l) => !l.includes('data-nc'))
    .map((l) => l.replace(/<[^>]+>/g, '').replace(/&quot;/g, '"').replace(/&amp;/g, '&').trim())
    .filter(Boolean));

  for (const linha of executaveis) {
    assert.ok(!/%[A-Z_]+%/.test(linha), `variável de cmd em comando colável: ${linha}`);
    assert.ok(!/^::/.test(linha), `comentário de cmd fora de data-nc: ${linha}`);
    assert.ok(!/^node\s+bin[\\/]/.test(linha), `caminho relativo (só roda dentro da pasta): ${linha}`);
  }

  const invocacoes = executaveis.filter((l) => l.includes('hm.mjs') && l.startsWith('node'));
  assert.ok(invocacoes.length > 8, 'esperava a CLI invocada por caminho absoluto em vários passos');
  for (const l of invocacoes) assert.ok(l.startsWith(`node "${base}\\bin\\hm.mjs"`), `invocação fora do padrão: ${l}`);
});

test('comentários são marcados para não irem no copiar', () => {
  const html = gerarManual(cfg, { baseExibida: 'C:\\Users\\fulano\\.copilot\\harness-metricas' });
  assert.ok(html.includes('data-nc'), 'nenhum comentário marcado');
  assert.ok(html.includes('[data-nc]'), 'o script de copiar não remove os comentários');
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TIPOS, copiarItem, listarTipo } from '../lib/harness.mjs';

function repoFake() {
  const base = mkdtempSync(join(tmpdir(), 'hm-harness-'));
  mkdirSync(join(base, '.github/prompts'), { recursive: true });
  mkdirSync(join(base, '.github/skills/federation-triage/references'), { recursive: true });
  mkdirSync(join(base, '.agents/skills/d2c'), { recursive: true });
  mkdirSync(join(base, '.github/instructions'), { recursive: true });
  writeFileSync(join(base, '.github/prompts/sdd-plan.prompt.md'), 'plan');
  writeFileSync(join(base, '.github/prompts/leia-me.md'), 'nao é prompt');
  writeFileSync(join(base, '.github/instructions/angular.instructions.md'), 'ang');
  writeFileSync(join(base, '.github/skills/federation-triage/SKILL.md'), 'skill');
  writeFileSync(join(base, '.github/skills/federation-triage/references/catalogo.md'), 'cat');
  writeFileSync(join(base, '.agents/skills/d2c/SKILL.md'), 'd2c');
  return base;
}

test('inventário pega só os arquivos do tipo, nas três convenções de pasta', () => {
  const repo = repoFake();
  assert.deepEqual(listarTipo(repo, 'prompts').map((i) => i.nome), ['sdd-plan.prompt.md']);
  assert.deepEqual(listarTipo(repo, 'instructions').map((i) => i.nome), ['angular.instructions.md']);
  const skills = listarTipo(repo, 'skills');
  assert.deepEqual(skills.map((i) => i.nome).sort(), ['d2c', 'federation-triage']);
  assert.deepEqual(skills.find((s) => s.nome === 'd2c').origem, '.agents/skills');
});

test('skill é copiada com a subárvore inteira', () => {
  const origem = repoFake();
  const destino = mkdtempSync(join(tmpdir(), 'hm-destino-'));
  const item = listarTipo(origem, 'skills').find((i) => i.nome === 'federation-triage');
  const r = copiarItem(item.caminho, join(destino, '.github/skills/federation-triage'), { pasta: true, forcar: false, simular: false });
  assert.equal(r, 'copiado');
  assert.equal(readFileSync(join(destino, '.github/skills/federation-triage/references/catalogo.md'), 'utf8'), 'cat');
});

test('não sobrescreve sem --forcar e simulação não escreve nada', () => {
  const origem = repoFake();
  const destino = mkdtempSync(join(tmpdir(), 'hm-destino-'));
  const alvo = join(destino, '.github/prompts/sdd-plan.prompt.md');
  mkdirSync(join(destino, '.github/prompts'), { recursive: true });
  writeFileSync(alvo, 'VERSAO DO DESTINO');
  const item = listarTipo(origem, 'prompts')[0];
  assert.equal(copiarItem(item.caminho, alvo, { pasta: false, forcar: false, simular: false }), 'existe');
  assert.equal(readFileSync(alvo, 'utf8'), 'VERSAO DO DESTINO');
  const novo = join(destino, '.github/prompts/outro.prompt.md');
  assert.equal(copiarItem(item.caminho, novo, { pasta: false, forcar: false, simular: true }), 'copiaria');
  assert.equal(existsSync(novo), false, 'simulação não pode escrever');
  assert.equal(copiarItem(item.caminho, alvo, { pasta: false, forcar: true, simular: false }), 'copiado');
  assert.equal(readFileSync(alvo, 'utf8'), 'plan');
});

test('os cinco tipos estão declarados com destino de usuário', () => {
  assert.deepEqual(Object.keys(TIPOS).sort(), ['agents', 'hooks', 'instructions', 'prompts', 'skills']);
  for (const [nome, def] of Object.entries(TIPOS)) {
    assert.ok(def.repo.length, `${nome} sem pasta de repositório`);
    assert.ok(def.usuario, `${nome} sem pasta de usuário`);
  }
});

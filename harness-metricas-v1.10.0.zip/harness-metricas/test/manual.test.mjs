import { test } from 'node:test';
import assert from 'node:assert/strict';
import { carregarTudo } from '../lib/config.mjs';
import { gerarManual } from '../lib/manual.mjs';

const cfg = carregarTudo();

test('o manual sai autocontido e com as seções que o time precisa', () => {
  const html = gerarManual(cfg, { baseExibida: 'C:\\Users\\fulano\\.copilot\\harness-metricas' });
  assert.ok(!/<script[^>]+src=/i.test(html), 'script externo');
  assert.ok(!/<link[^>]+href=/i.test(html), 'css externo');
  for (const t of ['Instalar', 'Medir uma tarefa do começo ao fim', 'Gerar o relatório', 'Fora do fluxo SDD', 'Onde mora cada artefato', 'O que é e o que não é gravado', 'Quando não funciona', 'Todos os comandos', 'Glossário']) {
    assert.ok(html.includes(t), `faltou a seção: ${t}`);
  }
});

test('nenhum escape de template vira caractere de controle no HTML', () => {
  const html = gerarManual(cfg, { baseExibida: 'C:\\Users\\fulano\\.copilot\\harness-metricas' });
  const controle = [...html].filter((c) => c.charCodeAt(0) < 32 && !'\n\r\t'.includes(c));
  assert.equal(controle.length, 0, `caracteres de controle no HTML: ${controle.map((c) => c.charCodeAt(0))}`);
  assert.ok(html.includes('C:\\Users\\fulano\\.copilot\\harness-metricas\\bin\\hm.mjs'), 'o caminho do hm.mjs saiu quebrado');
});

test('o caminho exibido é o que foi pedido, não o da máquina que gerou', () => {
  const html = gerarManual(cfg, { baseExibida: 'D:\\ferramentas\\hm' });
  assert.ok(html.includes('D:\\ferramentas\\hm\\dados\\otel'));
  assert.ok(html.includes('D:/ferramentas/hm/bin/hm.mjs'), 'o alias do bash usa barra normal');
  assert.ok(!html.includes('/home/claude'));
});

// Regressão da falha real em campo: o manual mandava "%HM%" ajuda, que é sintaxe de cmd.
// No PowerShell (terminal padrão do VS Code no Windows) isso morre com ParserError, e o
// usuário lê o erro como bug do pacote. Todo comando colável precisa ser neutro de dialeto.
test('nenhum comando colável depende do dialeto do shell', () => {
  const base = 'C:\\Users\\fulano\\.copilot\\harness-metricas';
  const html = gerarManual(cfg, { baseExibida: base });
  const blocos = [...html.matchAll(/<pre id="cmd\d+">([\s\S]*?)<\/pre>/g)].map((m) => m[1]);
  assert.ok(blocos.length > 5, 'esperava vários blocos de comando');

  const executaveis = blocos.flatMap((b) => b
    .split('\n')
    .filter((l) => !l.includes('data-nc'))
    .map((l) => l.replace(/<[^>]+>/g, '').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&#39;/g, "'").trim())
    .filter(Boolean));

  for (const linha of executaveis) {
    assert.ok(!/%[A-Z_]+%/.test(linha), `variável de cmd em comando colável: ${linha}`);
    assert.ok(!/^::/.test(linha), `comentário de cmd fora de data-nc: ${linha}`);
    assert.ok(!/^node\s+bin[\\/]/.test(linha), `caminho relativo (só roda dentro da pasta): ${linha}`);
  }

  // O manual usa o alias `hm` do começo ao fim; o caminho absoluto aparece só onde o alias
  // é definido. Se alguém trocar isso sem trocar o passo 3, o documento vira instrução quebrada.
  const comHm = executaveis.filter((l) => /^hm\s/.test(l));
  assert.ok(comHm.length > 12, `esperava o manual inteiro usando o alias, achei ${comHm.length}`);
  // O caminho completo só pode aparecer onde o alias é definido e na conferência do passo 1.
  const comCaminho = executaveis.filter((l) => l.includes('bin/hm.mjs') || l.includes('bin\\hm.mjs'));
  assert.ok(comCaminho.length >= 2 && comCaminho.length <= 3, `caminho completo em ${comCaminho.length} linhas`);
  for (const l of comCaminho) assert.ok(/^(alias hm=|function hm |dir ")/.test(l), `linha inesperada com caminho completo: ${l}`);
  assert.ok(comCaminho.some((l) => l.startsWith('alias hm=')), 'faltou o alias do bash');
  assert.ok(comCaminho.some((l) => l.startsWith('function hm ')), 'faltou a função do PowerShell');
});

test('comentários são marcados para não irem no copiar', () => {
  const html = gerarManual(cfg, { baseExibida: 'C:\\Users\\fulano\\.copilot\\harness-metricas' });
  assert.ok(html.includes('data-nc'), 'nenhum comentário marcado');
  assert.ok(html.includes('[data-nc]'), 'o script de copiar não remove os comentários');
});

// O script do botão "copiar" vive dentro de um template literal do gerador: um '\n' escrito
// sem escape duplo vira quebra de linha DE VERDADE no HTML e quebra a página inteira em
// SyntaxError. Aconteceu e passou despercebido porque nenhum teste abria a página.
test('o script embutido no manual é JavaScript válido', () => {
  const html = gerarManual(cfg, { baseExibida: 'C:\\Users\\fulano\\.copilot\\harness-metricas' });
  const scripts = [...html.matchAll(/<script(?![^>]*\ssrc=)[^>]*>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
  assert.ok(scripts.length >= 1, 'nenhum script inline encontrado');
  for (const js of scripts) {
    assert.doesNotThrow(() => new Function(js), 'script inline do manual não compila');
    assert.ok(!/\.split\('\n/.test(js), "'\\n' virou quebra de linha literal dentro de string");
  }
});

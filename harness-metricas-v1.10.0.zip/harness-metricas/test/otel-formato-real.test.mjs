import { test } from 'node:test';
import assert from 'node:assert/strict';
import { agregarConversas, lerOtel } from '../lib/otel.mjs';
import { arquivoReal } from './fixture-otel-real.mjs';

// Formato observado em campo (copilot-chat 0.65.0, máquina Windows corporativa):
// o exportador de arquivo serializa o OBJETO EM MEMÓRIA do SDK, não o envelope OTLP de fio.
//   - métricas: scopeMetrics no topo, nome em descriptor.name, valor em dataPoints[].value.sum
//   - tokens:   logRecords soltos, atributos como objeto simples, tempo em hrTime [s, ns]
//   - sem gen_ai.conversation.id em lugar nenhum
// Um arquivo de 8267 linhas válidas rendia 0 spans e o painel dizia "OTel desligado".
test('formato real do exportador rende tokens, modelo e horário', async () => {
  const arq = arquivoReal([{ inp: 1695, out: 16 }, { inp: 27242, out: 850 }, { inp: 39335, out: 1200 }]);
  const r = await lerOtel([arq]);

  assert.equal(r.invalidas, 0);
  assert.equal(r.spans.length, 3, 'um span por chamada de inferência');
  assert.equal(r.viaVarredura, 3, 'vieram pela varredura, não pelo caminho OTLP');
  assert.ok([...r.metricas.keys()].includes('gen_ai.client.operation.duration'), 'métrica do SDK precisa ser lida');

  const total = r.spans.reduce((t, s) => t + Number(s.attrs['gen_ai.usage.input_tokens'] || 0), 0);
  assert.equal(total, 1695 + 27242 + 39335);
  for (const s of r.spans) assert.ok(Number.isFinite(s.inicio), 'hrTime [s,ns] tem de virar timestamp');
});

test('chamadas sem conversation.id viram conversas próprias em vez de sumirem', async () => {
  const arq = arquivoReal([{ inp: 100, out: 10 }, { inp: 200, out: 20 }]);
  const { spans } = await lerOtel([arq]);
  const { conversas, conversasSinteticas } = agregarConversas(spans, {});

  assert.equal(conversas.length, 2);
  assert.equal(conversasSinteticas, 2);
  const tokens = conversas.flatMap((c) => Object.values(c.modelos)).reduce((t, m) => t + m.entrada_nova + m.saida, 0);
  assert.equal(tokens, 330, 'nenhum token pode se perder na síntese do id');
  for (const c of conversas) assert.ok(c.inicio > 0 && c.inicio < 4e12, `conversa sem horário utilizável: ${c.inicio}`);
});

test('linha de métrica não vira conversa fantasma', async () => {
  const arq = arquivoReal([]);
  const { spans } = await lerOtel([arq]);
  assert.equal(spans.length, 0, 'métrica de duração não carrega token: não pode virar chamada');
});

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cpSync, mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { RAIZ, carregarTudo } from '../lib/config.mjs';

function configComLocal(nome, conteudo) {
  const dir = mkdtempSync(join(tmpdir(), 'hm-cfg-'));
  cpSync(join(RAIZ, 'config'), dir, { recursive: true });
  writeFileSync(join(dir, `${nome}.local.json`), JSON.stringify(conteudo, null, 2));
  return dir;
}

// Atualizar o pacote é descompactar por cima, e isso reescreve config/parametros.json.
// Quem tinha mudado coleta.modo para "marcador+comandos" voltava para "marcador" sem aviso,
// e as sessões seguintes deixavam de ser medidas em silêncio. O arquivo .local.json nunca
// vem no zip, então sobrevive à atualização.
test('parametros.local.json sobrepõe o que vem no pacote', () => {
  const cfgDir = configComLocal('parametros', { coleta: { modo: 'marcador+comandos' } });
  const cfg = carregarTudo({ configDir: cfgDir, dadosDir: mkdtempSync(join(tmpdir(), 'hm-d-')) });
  assert.equal(cfg.parametros.coleta.modo, 'marcador+comandos');
  assert.ok(cfg.locais.includes('parametros'));
});

test('a sobreposição é por chave: o que não foi declarado continua vindo do pacote', () => {
  const cfgDir = configComLocal('parametros', { coleta: { modo: 'tudo' } });
  const cfg = carregarTudo({ configDir: cfgDir, dadosDir: mkdtempSync(join(tmpdir(), 'hm-d-')) });
  assert.equal(cfg.parametros.coleta.modo, 'tudo');
  assert.equal(cfg.parametros.coleta.marcador, '#medir', 'marcador não declarado deve sobreviver');
  assert.equal(cfg.parametros.limiar_ociosidade_min, 10, 'chave de topo intocada deve sobreviver');
});

test('sem arquivo local, nada muda e nada é reportado', () => {
  const cfg = carregarTudo({ dadosDir: mkdtempSync(join(tmpdir(), 'hm-d-')) });
  assert.deepEqual(cfg.locais, []);
});

test('preços e calibração também aceitam sobreposição local', () => {
  const cfgDir = configComLocal('calibracao', { versao: '2026-09-squad', calibrado_por: 'squad reneg' });
  const cfg = carregarTudo({ configDir: cfgDir, dadosDir: mkdtempSync(join(tmpdir(), 'hm-d-')) });
  assert.equal(cfg.calibracao.versao, '2026-09-squad');
  assert.ok(cfg.calibracao.unidades, 'unidades não declaradas continuam vindo do pacote');
  assert.ok(cfg.locais.includes('calibracao'));
});

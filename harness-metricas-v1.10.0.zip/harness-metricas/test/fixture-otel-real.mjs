// Réplica fiel do formato real da máquina do Henrique (v0.65.0 do copilot-chat),
// reconstruída a partir da saída de `diagnostico --otel-cru`.
import { writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const hr = (iso) => { const ms = Date.parse(iso); return [Math.floor(ms / 1000), (ms % 1000) * 1e6]; };

export function arquivoReal(chamadas, base = '2026-09-16T09:40:00-03:00') {
  const linhas = [];
  // 386 linhas de métrica cumulativa (duração), como no arquivo dele
  for (let i = 0; i < 5; i++) {
    linhas.push({
      resource: { _asyncAttributesPending: false, _rawAttributes: [['service.name', 'copilot-chat']] },
      scopeMetrics: [{
        scope: { name: 'copilot-chat', version: '0.65.0' },
        metrics: [{
          descriptor: { name: 'gen_ai.client.operation.duration', type: 'HISTOGRAM', description: '', unit: '', valueType: 1, advice: { explicitBucketBoundaries: [0.01, 0.1, 1] } },
          aggregationTemporality: 1,
          dataPointType: 0,
          dataPoints: [{
            attributes: { 'gen_ai.operation.name': 'chat', 'gen_ai.provider.name': 'github', 'gen_ai.request.model': 'gpt-5.6-luna' },
            value: { min: 0.279, max: 0.334, sum: 0.914, count: 3 },
            startTime: hr(base), endTime: hr(base),
          }],
        }],
      }],
    });
  }
  // logRecords: é aqui que o token mora
  chamadas.forEach((c, i) => {
    const t = new Date(Date.parse(base) + i * 60000).toISOString();
    linhas.push({
      _body: 'gen_ai.client.inference.operation.details',
      _isReadonly: true,
      _logRecordLimits: { attributeCountLimit: 128, attributeValueLengthLimit: null },
      attributes: {
        'event.name': 'gen_ai.client.inference.operation.details',
        'gen_ai.operation.name': 'chat',
        'gen_ai.request.model': c.modelo ?? 'gpt-5.6-luna',
        'gen_ai.response.id': `resp-${i}-aaaaaaaaaaaaaaaaaaaaaaaaaaaa`,
        'gen_ai.usage.input_tokens': c.inp,
        'gen_ai.usage.output_tokens': c.out,
        'gen_ai.request.temperature': 0,
        'gen_ai.response.finish_reasons': ['stop'],
      },
      hrTime: hr(t), hrTimeObserved: hr(t),
      instrumentationScope: { name: 'copilot-chat', version: '0.65.0' },
      resource: { _asyncAttributesPending: false },
      totalAttributesCount: 8,
    });
  });
  const dir = mkdtempSync(join(tmpdir(), 'hm-real-'));
  const arq = join(dir, 'copilot-otel.jsonl');
  writeFileSync(arq, `${linhas.map((l) => JSON.stringify(l)).join('\n')}\n`);
  return arq;
}

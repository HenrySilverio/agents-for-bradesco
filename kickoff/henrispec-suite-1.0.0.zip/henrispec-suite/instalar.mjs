#!/usr/bin/env node
// Instalador único da HenriSpec Suite. Arquivo único, sem dependência, Node 18+.
// Não reinventa a instalação: cada componente (componentes/<nome>/) já traz o seu motor e o seu
// manifesto, com lock, backup, detecção de conflito e proteção do que você alterou à mão.
// Este arquivo escolhe o alvo, escolhe os componentes, chama o motor de cada um na ordem e
// resume o resultado. Lê só o disco: não usa rede, não usa npm, não escreve em Git.
//
//   node instalar.mjs                                (interativo, num terminal)
//   node instalar.mjs repo [caminho] [opções]        local: dentro de um repositório
//   node instalar.mjs global          [opções]       global: na máquina, para todos os repositórios
//   node instalar.mjs status [caminho]               o que está instalado, em cada alvo
//   node instalar.mjs listar                         os componentes da suite
//
// Opções:  --so=a,b      instala só estes componentes
//          --sem=a,b     instala todos, menos estes
//          --dry-run     mostra o que faria, sem escrever
//          --forcar      sobrescreve arquivo alterado à mão (guarda backup antes)
//          --sem-github  no modo repo, não toca em .github/ (use junto com a instalação global)

import { spawnSync } from 'node:child_process';
import { readFileSync, existsSync, statSync } from 'node:fs';
import { join, dirname, resolve, relative, sep } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline/promises';

const SUITE = dirname(fileURLToPath(import.meta.url));

const barra = (p) => p.split(sep).join('/').replace(/\\/g, '/');

function sair(codigo, msg) {
  if (msg) (codigo === 0 ? console.log : console.error)(msg);
  process.exit(codigo);
}

function lerJson(p) {
  try {
    return JSON.parse(readFileSync(p, 'utf8'));
  } catch (e) {
    return { __erro: e.message };
  }
}

function compararVersao(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return Math.sign(d);
  }
  return 0;
}

// ------------------------------------------------------------------ componentes

function carregarSuite() {
  const suite = lerJson(join(SUITE, 'suite.json'));
  if (suite.__erro || !Array.isArray(suite.componentes)) sair(2, `suite.json ausente ou inválido em ${SUITE}`);
  for (const c of suite.componentes) {
    c.dir = join(SUITE, c.pasta);
    c.motor = join(c.dir, 'instalar.mjs');
    const manifesto = lerJson(join(c.dir, 'manifesto.json'));
    if (manifesto.__erro || !manifesto.versao || !existsSync(c.motor)) {
      sair(2, `componente ${c.id}: faltam manifesto.json ou instalar.mjs em ${c.pasta}`);
    }
    c.manifesto = manifesto;
    c.nome = manifesto.nome || c.id;
    c.versao = manifesto.versao;
  }
  return suite;
}

function escolher(suite, so, sem) {
  const ids = suite.componentes.map((c) => c.id);
  for (const id of [...so, ...sem]) {
    if (!ids.includes(id)) sair(2, `componente desconhecido: ${id}. Os da suite: ${ids.join(', ')}`);
  }
  if (so.length && sem.length) sair(2, 'use --so ou --sem, não os dois');
  const escolhidos = suite.componentes.filter((c) => (so.length ? so.includes(c.id) : !sem.includes(c.id)));
  if (!escolhidos.length) sair(2, 'nenhum componente selecionado');
  return escolhidos;
}

// ----------------------------------------------------------------------- execução

function executar(escolhidos, modo, caminho, repassar) {
  const resultados = [];
  escolhidos.forEach((c, i) => {
    console.log(`\n=== [${i + 1}/${escolhidos.length}] ${c.nome} ${c.versao} ===`);
    const args = [c.motor, modo, ...(modo === 'repo' ? [caminho] : []), ...repassar];
    const r = spawnSync(process.execPath, args, { stdio: 'inherit' });
    resultados.push({ c, codigo: r.status ?? 2 });
  });
  return resultados;
}

function resumir(resultados, modo, simulado) {
  console.log('\n=== Resumo ===');
  for (const { c, codigo } of resultados) {
    const estado = codigo === 0 ? (simulado ? 'simulado (nada foi escrito)' : 'ok') : codigo === 1 ? 'CONFLITO: nada foi escrito' : 'ERRO';
    console.log(`  ${c.id.padEnd(24)} ${c.versao.padEnd(8)} ${estado}`);
  }
  const conflitos = resultados.filter((r) => r.codigo === 1);
  const erros = resultados.filter((r) => r.codigo > 1);
  if (conflitos.length) {
    console.log('\nArquivo alterado à mão aparece como CONFLITO e o instalador não o sobrescreve. Compare com o pacote;');
    console.log('se o conteúdo do pacote é o que você quer, rode de novo com --forcar (o instalador guarda backup antes).');
  }
  if (erros.length) console.log('\nHouve erro em pelo menos um componente: leia a mensagem acima dele.');
  if (!conflitos.length && !erros.length && modo === 'global' && !simulado) {
    console.log('\nGlobal instala só agentes e skills. Em cada repositório, rode: instalar.sh repo <caminho> --sem-github');
    console.log('para o que fica fora de .github/ (.sdd/, docs/, instruções do projeto).');
  }
  return Math.max(0, ...resultados.map((r) => r.codigo));
}

// ---------------------------------------------------------------------- status

function copilotHome() {
  return resolve(process.env.COPILOT_HOME || join(homedir(), '.copilot'));
}

function situacao(lock, versaoPacote) {
  if (!lock || lock.__erro || !lock.versao) return '—';
  const c = compararVersao(lock.versao, versaoPacote);
  return c === 0 ? `${lock.versao} ok` : c < 0 ? `${lock.versao} (atualizar)` : `${lock.versao} (mais nova que o pacote)`;
}

function status(suite, caminho) {
  const raiz = resolve(caminho || '.');
  const home = copilotHome();
  console.log(`${suite.nome} ${suite.versao}`);
  console.log(`  repo:   ${barra(raiz)}`);
  console.log(`  global: ${barra(home)}\n`);
  const linhas = suite.componentes.map((c) => {
    const m = c.manifesto;
    const lockRepo = existsSync(join(raiz, m.lock || '')) ? lerJson(join(raiz, m.lock)) : null;
    const nomeGlobal = m.lockGlobal || `${m.toolkit}.lock.json`;
    let lockGlobal = existsSync(join(home, nomeGlobal)) ? lerJson(join(home, nomeGlobal)) : null;
    if (!lockGlobal && m.lockGlobalAntigo && existsSync(join(home, m.lockGlobalAntigo))) lockGlobal = lerJson(join(home, m.lockGlobalAntigo));
    return [c.id, c.versao, situacao(lockRepo, c.versao), situacao(lockGlobal, c.versao)];
  });
  const cab = ['componente', 'pacote', 'neste repo', 'global'];
  const larg = cab.map((t, i) => Math.max(t.length, ...linhas.map((l) => l[i].length)));
  const fmt = (l) => `  ${l.map((t, i) => t.padEnd(larg[i])).join('  ')}`;
  console.log(fmt(cab));
  console.log(fmt(larg.map((n) => '-'.repeat(n))));
  linhas.forEach((l) => console.log(fmt(l)));
}

function listar(suite) {
  console.log(`${suite.nome} ${suite.versao}\n`);
  for (const c of suite.componentes) {
    console.log(`  ${c.id.padEnd(24)} ${c.versao.padEnd(8)} ${c.resumo || ''}`);
  }
}

// ------------------------------------------------------------------ argumentos

function lerArgs(argv) {
  const out = { pos: [], so: [], sem: [], repassar: [], dryRun: false };
  const lista = (v) => (v || '').split(',').map((s) => s.trim()).filter(Boolean);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--so' || a === '--sem') out[a.slice(2)].push(...lista(argv[++i]));
    else if (a.startsWith('--so=')) out.so.push(...lista(a.slice(5)));
    else if (a.startsWith('--sem=')) out.sem.push(...lista(a.slice(6)));
    else if (a === '--dry-run') { out.dryRun = true; out.repassar.push(a); }
    else if (a === '--forcar' || a === '--sem-github') out.repassar.push(a);
    else if (a === '--ajuda' || a === '-h' || a === '--help') out.pos.unshift('ajuda');
    else if (a.startsWith('--')) sair(2, `opção desconhecida: ${a}`);
    else out.pos.push(a);
  }
  return out;
}

const USO = `uso:
  instalar.sh                                  interativo (num terminal)
  instalar.sh repo [caminho] [opções]          local, dentro de um repositório
  instalar.sh global          [opções]         global, na máquina
  instalar.sh status [caminho]                 o que está instalado
  instalar.sh listar                           os componentes da suite
opções:
  --so=a,b  --sem=a,b  --dry-run  --forcar  --sem-github`;

// ----------------------------------------------------------------- interativo

async function interativo(suite) {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const perguntar = async (t, padrao) => ((await rl.question(t)).trim() || padrao);
  try {
    listar(suite);
    console.log('');
    const alvo = await perguntar('Onde instalar?\n  1  neste repositório (pasta atual)\n  2  global, na minha máquina\n  3  só ver o que está instalado\n> ', '1');
    if (alvo === '3') { status(suite, '.'); return 0; }
    const modo = alvo === '2' ? 'global' : 'repo';
    let caminho = '.';
    if (modo === 'repo') caminho = await perguntar('Caminho do repositório [pasta atual]: ', '.');

    let escolhidos = suite.componentes;
    if ((await perguntar('Instalar todos os componentes? [S/n]: ', 's')).toLowerCase().startsWith('n')) {
      const ids = (await perguntar(`Quais? (ids separados por vírgula: ${suite.componentes.map((c) => c.id).join(', ')}): `, '')).split(',').map((s) => s.trim()).filter(Boolean);
      escolhidos = escolher(suite, ids, []);
    }
    const repassar = [];
    if (modo === 'repo' && (await perguntar('Instalar também em .github/ deste repositório? [S/n]  (responda n se já instalou global): ', 's')).toLowerCase().startsWith('n')) repassar.push('--sem-github');

    console.log('\nPrimeiro, uma simulação:');
    let resultados = executar(escolhidos, modo, caminho, [...repassar, '--dry-run']);
    let codigo = resumir(resultados, modo, true);
    if (codigo !== 0) return codigo;
    if ((await perguntar('\nAplicar agora? [s/N]: ', 'n')).toLowerCase().startsWith('s')) {
      resultados = executar(escolhidos, modo, caminho, repassar);
      codigo = resumir(resultados, modo, false);
    }
    return codigo;
  } finally {
    rl.close();
  }
}

// ------------------------------------------------------------------------ main

const MAIOR = Number(process.versions.node.split('.')[0]);
if (MAIOR < 18) sair(2, `Node ${MAIOR} encontrado; a suite precisa de 18 ou mais.`);

const args = lerArgs(process.argv.slice(2));
const [modo, caminho] = args.pos;
const suite = carregarSuite();

if (!modo) {
  if (process.stdin.isTTY && process.stdout.isTTY) process.exit(await interativo(suite));
  sair(2, USO);
}
if (modo === 'ajuda') sair(0, USO);
if (modo === 'listar') { listar(suite); process.exit(0); }
if (modo === 'status') { status(suite, caminho); process.exit(0); }
if (modo !== 'repo' && modo !== 'global') sair(2, USO);

const escolhidos = escolher(suite, args.so, args.sem);

let alvoRepo = null;
if (modo === 'repo') {
  alvoRepo = resolve(caminho || '.');
  if (!existsSync(alvoRepo) || !statSync(alvoRepo).isDirectory()) sair(2, `${alvoRepo} não é uma pasta`);
  const dentro = relative(SUITE, alvoRepo);
  if (dentro === '' || (!dentro.startsWith('..') && !dentro.includes(':'))) {
    sair(2, 'o destino está dentro da própria suite: rode a partir do repositório, ou passe o caminho dele');
  }
}

console.log(`${suite.nome} ${suite.versao}  alvo: ${modo === 'repo' ? `repo ${barra(alvoRepo)}` : `global ${barra(copilotHome())}`}${args.dryRun ? '  [dry-run]' : ''}`);
const resultados = executar(escolhidos, modo, alvoRepo, args.repassar);
process.exit(resumir(resultados, modo, args.dryRun));

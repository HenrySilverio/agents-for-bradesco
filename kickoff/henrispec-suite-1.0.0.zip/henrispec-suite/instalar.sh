#!/usr/bin/env bash
# HenriSpec Suite - instalador único para Git Bash, Linux e macOS. A lógica está em instalar.mjs.
#
#   bash <pasta-da-suite>/instalar.sh                         (interativo)
#   bash <pasta-da-suite>/instalar.sh repo [caminho] [opções]
#   bash <pasta-da-suite>/instalar.sh global          [opções]
#   bash <pasta-da-suite>/instalar.sh status [caminho]
#   bash <pasta-da-suite>/instalar.sh listar
set -euo pipefail

AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v node >/dev/null 2>&1; then
  echo "Node 18+ não encontrado no PATH. O instalador e o validador do HenriSpec precisam dele." >&2
  exit 2
fi

MAIOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$MAIOR" -lt 18 ]; then
  echo "Node $MAIOR encontrado; a suite precisa de 18 ou mais." >&2
  exit 2
fi

exec node "$AQUI/instalar.mjs" "$@"

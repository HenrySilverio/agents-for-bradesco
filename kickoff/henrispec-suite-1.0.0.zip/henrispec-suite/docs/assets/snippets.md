<!-- banner -->
<img src="docs/assets/banner.svg" width="900" alt="HenriSpec Suite: Discovery, spec-driven e depuração para o Copilot, em um pacote com instalador local ou global.">

<!-- stats -->
<img src="docs/assets/stats.svg" width="900" alt="Agentes: 9; Skills: 11; Componentes: 3; Modos de instalação: 2">

<!-- flow -->
<img src="docs/assets/flow.svg" width="900" alt="Fluxo: Discovery → Plan → Implement → Review → Archive">

<!-- terminal -->
<img src="docs/assets/terminal.svg" width="900" alt="Terminal executando: bash instalar.sh repo . --dry-run (+7 linhas de saída)">

<!-- section-como-funciona -->
<img src="docs/assets/section-como-funciona.svg" width="900" alt="Como funciona">

<!-- section-instalacao -->
<img src="docs/assets/section-instalacao.svg" width="900" alt="Instalação">

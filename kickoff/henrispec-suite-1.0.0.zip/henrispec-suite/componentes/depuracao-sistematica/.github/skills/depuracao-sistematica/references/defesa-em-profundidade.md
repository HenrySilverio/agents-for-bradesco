# Defesa em profundidade

## Visão geral

Quando você corrige um bug causado por dado inválido, uma validação em um só lugar parece
suficiente. Mas essa checagem pode ser contornada por outro caminho de código, por refatoração ou
por mock.

**Princípio:** valide em CADA camada por onde o dado passa. Torne o bug estruturalmente impossível.

## Por que várias camadas

Uma validação: "corrigimos o bug". Várias camadas: "tornamos o bug impossível".

Cada camada pega um caso diferente:
- a validação de entrada pega a maioria dos bugs;
- a lógica de negócio pega os casos de borda;
- os guards de ambiente evitam perigos de um contexto específico;
- o log de depuração ajuda quando as outras camadas falham.

## As quatro camadas

### Camada 1: validação no ponto de entrada

**Objetivo:** rejeitar entrada obviamente inválida na fronteira da API.

```typescript
function criarCliente(baseUrl: string): ApiClient {
  if (!baseUrl || baseUrl.trim() === '') {
    throw new Error('baseUrl não pode ser vazio');
  }
  if (!/^https?:\/\//.test(baseUrl)) {
    throw new Error(`baseUrl precisa ser absoluto: ${baseUrl}`);
  }
  // ... segue
}
```

### Camada 2: validação de lógica de negócio

**Objetivo:** garantir que o dado faz sentido para esta operação.

```typescript
function carregarLista(cliente: ApiClient, filtro: Filtro) {
  if (!cliente) {
    throw new Error('cliente obrigatório para carregar a lista');
  }
  // ... segue
}
```

### Camada 3: guards de ambiente

**Objetivo:** impedir operação perigosa em contextos específicos.

```typescript
function enviar(url: string) {
  // Em teste, recusa request para fora do servidor simulado
  if (process.env.NODE_ENV === 'test' && !url.startsWith('http://localhost')) {
    throw new Error(`Request real bloqueado em teste: ${url}`);
  }
  // ... segue
}
```

### Camada 4: instrumentação de depuração

**Objetivo:** capturar contexto para investigação posterior.

```typescript
function enviar(url: string) {
  logger.debug('Prestes a chamar a API', { url, origem: location.origin, pilha: new Error().stack });
  // ... segue
}
```

## Aplicando o padrão

Ao achar um bug:

1. **Rastreie o fluxo do dado.** De onde vem o valor ruim? Onde é usado?
2. **Mapeie todos os pontos de passagem.** Liste cada ponto pelo qual o dado atravessa.
3. **Valide em cada camada.** Entrada, negócio, ambiente, depuração.
4. **Teste cada camada.** Tente contornar a camada 1 e confirme que a camada 2 pega.

## Exemplo desta arquitetura

Bug: `baseUrl` vazio fez o request cair na origem do shell e voltar HTML.

**Fluxo do dado:**
1. o shell insere o elemento antes de definir o atributo;
2. o componente lê `baseUrl` vazio;
3. o service monta uma URL relativa;
4. o navegador resolve contra a origem do shell.

**Quatro camadas acrescentadas:**
- Camada 1: a criação do cliente valida `baseUrl` não vazio e absoluto.
- Camada 2: o service que carrega a lista exige o cliente.
- Camada 3: em teste, request para fora do servidor simulado é recusado.
- Camada 4: log da URL e da origem antes de cada chamada.

## Ideia-chave

Todas as camadas são necessárias. Na prática, cada uma pega o que as outras perdem:
- caminhos de código diferentes contornam a validação de entrada;
- mocks contornam as checagens de lógica de negócio;
- casos de borda em outros ambientes pedem guards de ambiente;
- o log de depuração revela uso estrutural errado.

**Não pare em um único ponto de validação.** Acrescente checagens em cada camada.

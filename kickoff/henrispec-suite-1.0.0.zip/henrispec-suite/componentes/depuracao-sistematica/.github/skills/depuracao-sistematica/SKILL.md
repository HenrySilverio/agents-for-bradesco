---
name: depuracao-sistematica
description: "Use ao encontrar bug, teste falhando, build quebrado ou comportamento inesperado, antes de propor qualquer correção."
---

# Depuração sistemática

## Princípio

**Ache a causa raiz antes de tentar qualquer correção.** Corrigir sintoma é falhar. Violar a
letra deste processo é violar o espírito da depuração.

## A Lei de Ferro

**Nenhuma correção sem investigação de causa raiz primeiro.**

Se você não terminou a Fase 1, não pode propor correção.

## Quando usar

Em qualquer problema técnico: teste falhando, bug em produção, comportamento inesperado,
problema de desempenho, build quebrado, falha de integração.

**Use principalmente quando:**
- há pressa, porque emergência faz o palpite parecer atraente;
- "só uma correção rápida" parece óbvia;
- você já tentou várias correções, ou a anterior não funcionou;
- você não entende o problema por inteiro.

**Não pule quando:**
- o problema parece simples: bug simples também tem causa raiz;
- há pressa: pressa garante retrabalho;
- alguém quer o conserto agora: o método é mais rápido que tentativa e erro.

## As quatro fases

Termine cada fase antes de começar a próxima.

### Fase 1: investigar a causa raiz

**Antes de tentar QUALQUER correção:**

1. **Leia as mensagens de erro com atenção.** Não passe por cima de erro ou aviso: muitas vezes
   a solução está escrita ali. Leia o stack trace inteiro. Anote linhas, caminhos de arquivo e
   códigos de erro.

2. **Reproduza de forma consistente.** Dá para disparar sempre? Quais são os passos exatos?
   Acontece toda vez? Se não reproduz, colete mais dados. Não chute.

3. **Veja o que mudou.** O que poderia ter causado isso? Diff, commits recentes, dependência
   nova, mudança de configuração, diferença entre ambientes.

4. **Colete evidência em sistema com várias camadas.** Quando a requisição atravessa várias
   fronteiras (shell, remote, BFF, serviço downstream), **antes de propor correção**, instrumente
   cada fronteira:
   - registre o que entra no componente e o que sai dele;
   - confira se ambiente e configuração chegaram até ali;
   - verifique o estado em cada camada.

   Rode uma vez para ver ONDE quebra. Depois analise a evidência, identifique o componente que
   falha e só então investigue esse componente. Exemplo: o shell mandou o atributo, o remote
   recebeu vazio, o BFF nunca foi chamado. A quebra está entre o shell e o remote, e olhar o BFF
   seria perda de tempo.

5. **Rastreie o fluxo do dado.** Quando o erro está fundo na pilha de chamadas, leia
   `references/rastreio-causa-raiz.md`. Versão curta: de onde vem o valor ruim? Quem chamou com
   esse valor? Suba até achar a origem. Corrija na origem, não no sintoma.

### Fase 2: análise de padrão

**Ache o padrão antes de corrigir:**

1. **Ache exemplos que funcionam.** Localize no mesmo repositório código parecido que funciona.
2. **Compare com a referência.** Se está implementando um padrão, leia a implementação de
   referência COMPLETA. Não leia na diagonal: leia cada linha.
3. **Liste as diferenças.** O que difere entre o que funciona e o que quebra? Liste todas,
   por menores que sejam. Não presuma que "isso não pode importar".
4. **Entenda as dependências.** De que outros componentes isso precisa? Que configuração e
   ambiente? Que suposições faz?

### Fase 3: hipótese e teste

**Método científico:**

1. **Formule uma única hipótese.** Diga claramente: "acho que X é a causa raiz porque Y".
   Escreva. Seja específico, não vago.
2. **Teste o mínimo.** Faça a MENOR mudança possível para testar a hipótese. Uma variável por
   vez. Não corrija várias coisas ao mesmo tempo.
3. **Confirme antes de seguir.** Funcionou? Então Fase 4. Não funcionou? Formule uma hipótese
   NOVA. NÃO empilhe mais correções por cima.
4. **Quando não souber,** diga "não entendo X". Não finja que sabe. Peça ajuda. Pesquise mais.

### Fase 4: implementação

**Corrija a causa raiz, não o sintoma.**

1. **Crie um caso de teste que falha.** A reprodução mais simples possível. Teste automatizado
   se der; script descartável se não houver framework. É OBRIGATÓRIO ter antes de corrigir. Se o
   repositório tiver instruction ou skill de testes, use-a para escrever esse teste.
2. **Implemente uma única correção.** Ataque a causa raiz identificada. UMA mudança por vez.
   Nada de "já que estou aqui". Nada de refatoração junto.
3. **Verifique a correção.** Responda as três perguntas e cole a evidência da saída:
   o teste que falhava passa agora? Os outros testes continuam passando? O sintoma original
   sumiu quando você repete os mesmos passos da reprodução? Sem a evidência colada, não declare
   que resolveu.
4. **Se a correção não funcionou, PARE.** Conte quantas correções você já tentou. Menos de três:
   volte à Fase 1 e reanalise com a informação nova. **Três ou mais: PARE e questione a
   arquitetura (passo 5).** Não tente a correção número 4 sem discutir a arquitetura.
5. **Se três ou mais correções falharam, questione a arquitetura.**

   **Padrão que indica problema de arquitetura:**
   - cada correção revela um novo estado compartilhado, acoplamento ou problema em outro lugar;
   - as correções exigiriam "refatoração enorme" para serem feitas;
   - cada correção cria sintomas novos em outro ponto.

   **PARE e questione o básico:** esse padrão é sólido em essência? Estamos insistindo nele só por
   inércia? Vale refatorar a arquitetura em vez de continuar corrigindo sintoma?

   **Converse com a pessoa que você apoia antes de tentar mais correções.** Isso não é uma
   hipótese que falhou: é arquitetura errada.

## Sinais de alerta: PARE e volte ao processo

Se você se pegar pensando:
- "Correção rápida agora, investigo depois."
- "Vou só tentar mudar X e ver se funciona."
- "Faço várias mudanças e rodo os testes."
- "Pulo o teste, confiro na mão."
- "Provavelmente é X, vou corrigir isso."
- "Não entendo direito, mas isso pode funcionar."
- "O padrão diz X, mas vou adaptar de outro jeito."
- "Os problemas principais são estes:" seguido de correções sem investigação.
- Propor solução antes de rastrear o fluxo do dado.
- **"Mais uma tentativa" quando já foram duas ou mais.**
- **Cada correção revela um problema novo em outro lugar.**

**Todos significam: PARE. Volte à Fase 1.**

**Com três ou mais correções falhas:** questione a arquitetura (Fase 4, passo 5).

## Sinais da pessoa de que você está errando o processo

Fique atento a estas redirecionações:
- "Isso não está acontecendo?" significa que você presumiu sem verificar.
- "Isso vai nos mostrar...?" significa que faltou coletar evidência.
- "Para de chutar" significa que você propõe correção sem entender.
- "Pensa a fundo nisso" significa questionar o básico, não só o sintoma.
- "Estamos travados?" (com frustração) significa que sua abordagem não está funcionando.

**Ao ver isso: PARE. Volte à Fase 1.**

## Racionalizações comuns

| Desculpa | Realidade |
| --- | --- |
| "É simples, não precisa de processo" | Problema simples também tem causa raiz. O processo é rápido para bug simples. |
| "É emergência, sem tempo para processo" | Depurar com método é MAIS rápido que tentativa e erro. |
| "Tento isso primeiro, depois investigo" | A primeira correção define o padrão. Faça certo desde o começo. |
| "Escrevo o teste depois de confirmar a correção" | Correção sem teste não se sustenta. Teste antes prova. |
| "Várias correções de uma vez economiza tempo" | Não dá para isolar o que funcionou, e cria bugs novos. |
| "A referência é longa, adapto o padrão" | Entendimento parcial garante bug. Leia por inteiro. |
| "Já vi o problema, vou corrigir" | Ver o sintoma não é entender a causa raiz. |
| "Mais uma tentativa" (depois de 2 falhas) | Três falhas indicam problema de arquitetura. Questione o padrão, não corrija de novo. |

## Referência rápida

| Fase | Atividades principais | Critério de sucesso |
| --- | --- | --- |
| **1. Causa raiz** | Ler erros, reproduzir, ver mudanças, coletar evidência | Entender O QUE e POR QUÊ |
| **2. Padrão** | Achar exemplos que funcionam, comparar | Identificar as diferenças |
| **3. Hipótese** | Formular teoria, testar o mínimo | Confirmada, ou hipótese nova |
| **4. Implementação** | Criar teste, corrigir, verificar | Bug resolvido, testes passando |

## Quando o processo mostra que não há causa raiz

Se a investigação sistemática mostrar que o problema é de fato ambiental, dependente de timing
ou externo:

1. você completou o processo;
2. documente o que investigou;
3. implemente o tratamento adequado (nova tentativa, timeout, mensagem de erro);
4. acrescente monitoramento ou log para investigar no futuro.

**Mas:** 95% dos casos de "sem causa raiz" são investigação incompleta.

## Técnicas de apoio

Ficam em `references/` e só são lidas quando a fase pedir:

- **`references/rastreio-causa-raiz.md`**: rastrear o bug para trás na pilha de chamadas até o
  gatilho original.
- **`references/defesa-em-profundidade.md`**: depois de achar a causa raiz, validar em várias
  camadas para o bug ficar estruturalmente impossível.
- **`references/espera-por-condicao.md`**: trocar espera por tempo fixo por espera pela condição
  real, a cura para teste intermitente.

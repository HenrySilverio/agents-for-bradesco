# Rastreio de causa raiz

## Visão geral

O bug costuma aparecer fundo na pilha de chamadas: um request que cai na origem errada, um
arquivo criado no lugar errado, um banco aberto com o caminho errado. O instinto é corrigir onde
o erro aparece, mas isso é tratar sintoma.

**Princípio:** rastreie para trás pela cadeia de chamadas até achar o gatilho original, e corrija
na origem.

## Quando usar

```mermaid
flowchart TD
    A{Bug aparece fundo na pilha?} -->|sim| B{Dá para rastrear para trás?}
    B -->|sim| C[Rastrear até o gatilho original]
    B -->|não, beco sem saída| D[Corrigir no ponto do sintoma]
    C --> E[Melhor: acrescentar também defesa em profundidade]
```

**Use quando:**
- o erro acontece fundo na execução, longe da entrada;
- o stack trace mostra uma cadeia longa de chamadas;
- não está claro de onde veio o dado inválido;
- é preciso descobrir qual teste ou trecho de código dispara o problema.

## O processo de rastreio

Exemplo real desta arquitetura: o shell insere um web component de um remote, e a tela de
listagem mostra "Unexpected token '<'".

1. **Observe o sintoma.** A tela falha ao carregar a lista e o console mostra erro de parse de
   JSON.
2. **Ache a causa imediata.** O que causa isso diretamente? O service recebeu uma página HTML em
   vez de JSON. A aba Network mostra um 404 em HTML.
3. **Pergunte: quem chamou isso?** O request foi para a origem do shell, não para o BFF.
   O service montou a URL com `baseUrl` vazio, e URL relativa cai na origem de quem hospeda.
4. **Continue subindo.** Quem entregou o `baseUrl` vazio? O componente leu o atributo
   `baseUrl` dentro do `connectedCallback`.
5. **Ache o gatilho original.** O shell só define o atributo depois de inserir o elemento no DOM.
   No momento da leitura, o atributo ainda não existia.

**Cadeia:** 404 em HTML, service com `baseUrl` vazio, request relativo na origem do shell,
leitura do atributo no `connectedCallback`, shell que define o atributo depois de inserir.

**Causa raiz:** o componente lê a configuração antes de o hospedeiro entregá-la.

**Correção na origem:** ler o atributo quando ele chegar (reagir à mudança), não no momento da
conexão.

**Defesa em profundidade que fica junto:** o service recusa `baseUrl` vazio com erro claro, em
vez de montar uma URL relativa em silêncio.

## Como instrumentar quando não dá para rastrear à mão

Registre o contexto antes da operação suspeita, não depois que ela falha:

```typescript
function chamarApi(baseUrl: string, caminho: string) {
  console.error('DEBUG chamarApi', {
    baseUrl,
    caminho,
    origem: location.origin,
    pilha: new Error().stack,
  });
  // ... segue o fluxo normal
}
```

**Em teste, use `console.error()`**, não o logger: o logger pode estar silenciado.

Rode e capture só o que interessa:

```bash
npx jest 2>&1 | grep 'DEBUG chamarApi'
```

Analise as pilhas: procure nomes de arquivo de teste, a linha que dispara a chamada e o padrão
(mesmo teste? mesmo parâmetro?).

## Descobrir qual teste causa a poluição

Quando algo aparece durante os testes e você não sabe qual teste cria, rode os arquivos um a um e
pare no primeiro que deixa o rastro. Troque `ARTEFATO` pelo arquivo ou pasta que aparece sem
ser esperado:

```bash
ARTEFATO=".git"
for t in $(find src -name '*.spec.ts'); do
  rm -rf "$ARTEFATO"
  npx jest "$t" >/dev/null 2>&1
  if [ -e "$ARTEFATO" ]; then echo "Poluidor: $t"; break; fi
done
```

## Princípio central

```mermaid
flowchart TD
    A([Achei a causa imediata]) --> B{Dá para subir um nível?}
    B -->|sim| C[Rastrear para trás]
    C --> D{Essa é a origem?}
    D -->|não, continua| C
    D -->|sim| E[Corrigir na origem]
    E --> F[Validar em cada camada]
    F --> G([Bug impossível])
    B -->|não| H[/NUNCA corrigir só o sintoma/]
```

**NUNCA corrija só onde o erro aparece.** Volte até achar o gatilho original.

## Dicas de stack trace

- **Em teste:** use `console.error()`, não o logger.
- **Antes da operação:** registre antes da operação perigosa, não depois que ela falha.
- **Inclua contexto:** URL, origem, variáveis de ambiente, horário.
- **Capture a pilha:** `new Error().stack` mostra a cadeia completa.

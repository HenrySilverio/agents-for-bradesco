# Espera por condição

## Visão geral

Teste intermitente costuma adivinhar o tempo com atrasos arbitrários. Isso cria corrida: o teste
passa em máquina rápida e falha sob carga ou no CI.

**Princípio:** espere pela condição que importa, não por um palpite de quanto tempo ela leva.

## Quando usar

```mermaid
flowchart TD
    A{Teste usa setTimeout ou sleep?} -->|sim| B{Está testando comportamento de tempo?}
    B -->|sim| C[Documentar POR QUE o timeout é necessário]
    B -->|não| D[Usar espera por condição]
```

**Use quando:**
- o teste tem atrasos arbitrários (`setTimeout`, `sleep`, `time.sleep()`);
- o teste é intermitente (passa às vezes, falha sob carga);
- o teste estoura o tempo quando roda em paralelo;
- é preciso esperar uma operação assíncrona terminar.

**Não use quando:**
- o que se testa é o próprio comportamento de tempo (debounce, intervalo de throttle);
- nesse caso, sempre documente POR QUE usa um timeout arbitrário.

Em Angular, antes de escrever uma espera própria, veja se `await fixture.whenStable()`, o
`fakeAsync` com `tick()` ou o `waitFor` do Testing Library já resolvem.

## Padrão principal

```typescript
// ANTES: adivinhando o tempo
await new Promise(r => setTimeout(r, 50));
const resultado = obterResultado();
expect(resultado).toBeDefined();

// DEPOIS: esperando a condição
await esperarPor(() => obterResultado() !== undefined, 'resultado disponível');
const resultado = obterResultado();
expect(resultado).toBeDefined();
```

## Padrões rápidos

| Cenário | Padrão |
| --- | --- |
| Esperar um evento | `esperarPor(() => eventos.find(e => e.tipo === 'CONCLUIDO'), 'evento concluído')` |
| Esperar um estado | `esperarPor(() => maquina.estado === 'pronta', 'máquina pronta')` |
| Esperar uma contagem | `esperarPor(() => itens.length >= 5, 'cinco itens')` |
| Esperar um arquivo | `esperarPor(() => existsSync(caminho), 'arquivo criado')` |
| Condição composta | `esperarPor(() => obj.pronto && obj.valor > 10, 'objeto pronto')` |

## Implementação

Função genérica de polling:

```typescript
async function esperarPor<T>(
  condicao: () => T | undefined | null | false,
  descricao: string,
  limiteMs = 5000
): Promise<T> {
  const inicio = Date.now();

  while (true) {
    const resultado = condicao();
    if (resultado) return resultado;

    if (Date.now() - inicio > limiteMs) {
      throw new Error(`Tempo esgotado esperando ${descricao} após ${limiteMs}ms`);
    }

    await new Promise(r => setTimeout(r, 10)); // consulta a cada 10ms
  }
}
```

## Erros comuns

- **Consultar rápido demais**, como `setTimeout(verificar, 1)`, desperdiça CPU. Consulte a cada 10ms.
- **Sem limite de tempo** gera laço infinito se a condição nunca chegar. Sempre inclua um limite
  com erro claro.
- **Dado desatualizado**, quando se guarda o estado antes do laço. Chame o getter dentro do laço
  para ter o dado fresco.

## Quando o timeout arbitrário É correto

```typescript
// A ferramenta emite um tick a cada 100ms; são necessários 2 ticks para ver a saída parcial
await esperarPor(() => gerenciador.iniciou, 'ferramenta iniciada'); // primeiro: a condição
await new Promise(r => setTimeout(r, 200));                        // depois: o comportamento temporal
// 200ms = 2 ticks de 100ms: documentado e justificado
```

**Requisitos:**
1. primeiro espere pela condição que dispara;
2. baseie-se em tempo conhecido, não em palpite;
3. comente POR QUE.

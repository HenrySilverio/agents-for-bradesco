# Depuração Sistemática

Agente `depurar` e skill `depuracao-sistematica`: método em vez de chute para bug, teste falhando
ou build quebrado. Versão 0.2.0.

Baseado na skill `systematic-debugging` do projeto superpowers (obra), adaptado para o harness
Copilot em português.

## Para que serve

A IA tem uma tendência forte a propor uma correção na primeira leitura do erro. Quando o chute
erra, o dev gasta tempo e tokens desfazendo. O agente `depurar` força a ordem certa: entender a
causa raiz primeiro, corrigir depois.

## Como usar

1. Abra um chat novo no VS Code e selecione o agente **depurar** no seletor de agentes.
2. Entregue o erro completo, o log e os passos para reproduzir. Se souber onde acontece, cite o
   arquivo com `#file`.
3. O agente investiga e devolve um relatório com sintoma, evidência, causa raiz e o teste que
   prova o problema. Ele **não** edita código.
4. Para corrigir, abra outro chat no agente padrão, cole o relatório e peça a correção a partir
   do teste que falha. Se o problema faz parte de uma mudança do HenriSpec, o destino é o
   `henrispec-implement`.

## As quatro fases

| Fase | O que acontece | Fica pronto quando |
| --- | --- | --- |
| 1. Causa raiz | Ler o erro, reproduzir, ver o que mudou, coletar evidência por camada, rastrear o dado | Você entende o que quebra e por quê |
| 2. Padrão | Achar código parecido que funciona e comparar | As diferenças estão listadas |
| 3. Hipótese | Uma hipótese por vez, com a menor mudança possível | Confirmada, ou hipótese nova |
| 4. Implementação | Teste que falha, uma correção, verificação com evidência | Bug resolvido e testes passando |

Três correções sem resultado significam problema de arquitetura: o agente para e discute o
desenho em vez de tentar a quarta.

## O que veio de uma versão anterior em prompt

Na versão 0.1 o ponto de entrada era `.github/prompts/depurar.prompt.md`, chamado por `/depurar`.
O GitHub Copilot e o VS Code não leem mais arquivos `.prompt.md`, então a 0.2.0 trocou o prompt
pelo agente `.github/agents/depurar.agent.md`. A skill e as três referências continuam iguais em
lógica.

| Antes (0.1) | Agora (0.2.0) |
| --- | --- |
| `.github/prompts/depurar.prompt.md` | `.github/agents/depurar.agent.md` |
| chamado por `/depurar` | selecionado no seletor de agentes |
| `tools` sem `edit` | `tools` sem `edit` (`read`, `search`, `execute`) |

Se o repositório ainda tiver o `.prompt.md` antigo, apague: o instalador avisa e o lista como
arquivo que saiu do toolkit.

## O que o agente não faz

- Não edita arquivo. O `execute` serve só para observar (rodar teste, ler log, ver diff).
- Não corrige. A Fase 4 acontece em outra conversa, já com a causa provada.
- Só age quando selecionado. Pedido comum no chat continua comum.

## Arquivos

| Arquivo | Papel |
| --- | --- |
| `.github/agents/depurar.agent.md` | ponto de entrada, sem ferramenta de edição |
| `.github/skills/depuracao-sistematica/SKILL.md` | o método: fases, sinais de alerta, regra das três correções |
| `.../references/rastreio-causa-raiz.md` | rastrear o bug para trás até a origem |
| `.../references/defesa-em-profundidade.md` | validar em várias camadas depois de achar a causa |
| `.../references/espera-por-condicao.md` | cura para teste intermitente |

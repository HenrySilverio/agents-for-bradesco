## Depuração sistemática

Quando a causa de um erro não for óbvia (bug, teste que falha sem motivo claro, build quebrado,
comportamento inesperado), sugira **uma vez, sem bloquear** o agente `depurar`, que investiga a
causa raiz antes de qualquer correção. Se o dev quiser seguir direto, siga.

O agente `depurar` só age quando selecionado e não edita arquivos.

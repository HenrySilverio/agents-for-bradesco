# Harness de acessibilidade — Mobile PF

**Fase 1 (atual): auditoria sem editar código.** O agente aponta onde está cada problema, no MFE ou em qual BFF, e grava um relatório dividido em **unidades de trabalho** (um componente Angular ou um `.ftl` por unidade). Cada unidade vira um briefing para o SDD.

**Fase 2 (depois):** o SDD implementa unidade por unidade; o agente `a11y-revisor` confere o resultado contra o "Resultado esperado" da unidade.

→ Uso para o time, incluindo estagiários: [`mfe/docs/a11y/PASSO-A-PASSO.md`](mfe/docs/a11y/PASSO-A-PASSO.md) (passo a passo, comandos e árvore de pastas).

## Como o "não editar" é garantido

| Camada | Mecanismo |
|---|---|
| Agente `a11y-auditor` | `tools` tem `edit/createFile` e **não** `edit/editFiles`: não consegue alterar arquivo existente. Mesma doutrina do `/sdd-review`. |
| Scripts | Leem código e escrevem só em `a11y-relatorios/` (MFE) e `target/a11y/` (BFF). |
| Git | O agente registra `git status --porcelain` antes e depois, e o relatório mostra qualquer diferença fora de `a11y-relatorios/`. |
| Instalação | Tudo vai para `.git/info/exclude`; Playwright com `npm i --no-save`. `git status` fica igual ao de antes. |

Limite honesto: o agente tem terminal (precisa rodar os scripts), e terminal pode escrever arquivo. A allowlist é a alavanca; o `git status` antes/depois é a trilha de auditoria. Bloqueio técnico de verdade só por allowlist da organização, a mesma ressalva do sdd-toolkit.

## Fatos determinísticos × julgamento do LLM

| Quem | Faz o quê | Custo |
|---|---|---|
| `a11y-check.mjs` | anti-padrões em `.html`/`.ts`/`.ftl` | 0 token |
| `A11yContratoFtlTest` (IntelliJ) | renderiza o FTL e aplica regras ao JSON real | 0 token |
| `capturar.mjs` | árvore de acessibilidade atual + axe | 0 token |
| `a11y-relatorio.mjs` | consolida tudo por camada/unidade, com impacto por regra (`regras.json`) | 0 token |
| agente `a11y-auditor` | dono de cada achado, dependências entre unidades, comparação com a anotação, texto do relatório | LLM |

O agente lê `achados-estaticos.json` já agrupado, em vez de varrer o código atrás dos anti-padrões. Ele só abre código para decidir **dono** e **dependência**.

## Instalação

```bash
node instalar.mjs --mfe <repo MFE> --bff <repo BFF 1> --bff <repo BFF 2>
```

Arquivo que já existe no repositório nunca é sobrescrito. O instalador detecta a pasta dos `.ftl` e gera `a11y.config.json`, `a11y.code-workspace` e `config.properties`.

## AJUSTES antes do primeiro uso

| Arquivo | O quê |
|---|---|
| `e2e-a11y/support/mock-bff.ts` | padrão de URL das chamadas ao BFF (só para captura) |
| `e2e-a11y/playwright.config.ts` | comando que sobe o remote standalone (só para captura) |
| `tools/a11y/a11y.config.json` | conferir a pasta dos `.ftl` detectada |
| `A11yContratoFtlTest.java` | pacote `a11y` (se o checkstyle exigir outro) e auto-imports do FreeMarker, se o BFF usar |
| `regras.json` / `CAMPOS_NOME` | vocabulário de acessibilidade do contrato (`acessibilidade` × `texto_leitor`) |

## Trade-offs aceitos

- **Workspace multi-root no VS Code só para auditar.** É o único jeito de um agente ver MFE e BFFs juntos e dizer de qual camada é o problema. O desenvolvimento do BFF continua no IntelliJ. Alternativa rejeitada: um relatório por repositório, que perde as dependências entre camadas.
- **O agente não roda Maven.** O ambiente Java do IntelliJ (JDK, settings.xml do banco) nem sempre existe no terminal do VS Code. O relatório marca a lacuna em "Cobertura incompleta" em vez de falhar.
- **`JsonEstrito` em vez de Jackson** no teste do BFF: imune a Jackson 2 × 3 no Spring Boot 4, ao custo de ~90 linhas de teste.
- **Checker por regex:** cobre os anti-padrões já vistos neste código, zero dependência, menos de 1s. Pode dar falso positivo em template incomum.
- **Nada substitui TalkBack/VoiceOver reais.** Uma validação em HOM continua necessária no final da fase 2.

## Executado antes da entrega

- Instalador em repositórios git de teste: `git status` idêntico antes e depois; segunda execução idempotente.
- Fluxo completo com o código original enviado: teste do BFF (com FreeMarker simulado) → `achados.json` → `a11y-relatorio.mjs` → captura com Playwright 1.56 → relatório agrupado por unidade.
- Asserções Jest (jsdom) e Playwright sobre o DOM corrigido passam; sobre o original, falham nos pontos esperados. Com a marcação original, o axe **passa**: axe sozinho não basta.
- **Não executado:** FreeMarker real (Maven Central bloqueado aqui) e o `render` Angular dos exemplos da fase 2.

---
description: Audita a acessibilidade do JSON gerado por um FTL (sem editar o FTL) e lista o que precisa mudar
tools: ['read', 'search', 'edit/createFile']
---
FTL: ${input:ftl:nome do arquivo .ftl}

Não edite arquivo existente. `edit/createFile` serve só para criar cenário novo em `src/test/resources/a11y/cenarios/`.

1. Se faltar cenário para algum ramo `<#if>` do FTL, crie um arquivo por ramo. Use dados com acento e aspas: é isso que quebra o escape.
2. Peça ao dev para rodar `A11yContratoFtlTest` (IntelliJ: ícone ▶ na classe) e colar a saída, ou leia `target/a11y/*.achados.json`, se já existir.
3. Liste os achados agrupados por causa: `local | regra | hoje | esperado`.
4. Campo novo no contrato vira **[DECISÃO PENDENTE]** com o impacto no MFE. Não proponha nome definitivo.

O relatório consolidado da tela é feito no MFE (`/a11y-auditar`). Este prompt serve para quem está só no IntelliJ.

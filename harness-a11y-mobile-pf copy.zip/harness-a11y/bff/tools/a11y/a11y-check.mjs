#!/usr/bin/env node
// a11y-check.mjs — checagem estática de acessibilidade, zero dependências.
//
// Pega os anti-padrões que JÁ apareceram neste código (não é um linter genérico).
// Complementa — não substitui — os testes de árvore de acessibilidade (Playwright/Testing Library).
//
// Uso:
//   node tools/a11y/a11y-check.mjs src/app            # varre pasta
//   node tools/a11y/a11y-check.mjs a.html b.ftl       # arquivos
//   node tools/a11y/a11y-check.mjs src --json         # saída JSON
//   node tools/a11y/a11y-check.mjs --hook             # modo hook do Copilot (lê stdin)
//
// Saída: arquivo:linha  [ERRO|AVISO CÓDIGO] mensagem → correção
// Exit code: 1 se houver ERRO (CLI). Em modo hook sempre 0 — hook não bloqueia, informa.

import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, extname, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const EXTENSOES = new Set(['.html', '.ts', '.ftl']);
const IGNORAR_DIRS = new Set(['node_modules', 'dist', '.angular', 'target', '.git', 'coverage']);
const MAX_ACHADOS_HOOK = 15; // orçamento de tokens: o modelo não precisa de 80 linhas iguais

// Campos que dão nome acessível a um nó do contrato JSON (FTL). AJUSTE conforme o vocabulário da squad.
const CAMPOS_NOME = ['acessibilidade', 'texto_leitor', 'textoLeitor', 'rotulo', 'titulo', 'label'];
const CAMPOS_LEITURA = ['acessibilidade', 'texto_leitor', 'textoLeitor'];

const RE_REAIS_DUPLICADO = /R\$\s*[\d.,]+\s*reais/i;
const RE_ESTADO_NO_TEXTO = /\b(recolhid[oa]|expandid[oa]|selecionad[oa]|marcad[oa]|desmarcad[oa])\b/i;

// ---------------------------------------------------------------- utilidades
const linhaDe = (src, idx) => src.slice(0, idx).split('\n').length;

function* tags(src) {
  // <tag atributos> — suficiente para templates Angular (não é parser HTML completo).
  const re = /<([a-zA-Z][\w-]*)(\s(?:[^>"']|"[^"]*"|'[^']*')*)?\s*\/?>/g;
  let m;
  while ((m = re.exec(src))) yield { nome: m[1].toLowerCase(), attrs: m[2] ?? '', idx: m.index, fimAbertura: re.lastIndex };
}

const attr = (attrs, nome) => {
  // aceita nome="x", [nome]="x", [attr.nome]="x"
  const re = new RegExp(`(?:^|\\s)(?:\\[(?:attr\\.)?${nome}\\]|${nome})\\s*=\\s*("([^"]*)"|'([^']*)')`, 'i');
  const m = attrs.match(re);
  return m ? { valor: m[2] ?? m[3] ?? '', dinamico: m[0].includes('[') } : null;
};
const temAttr = (attrs, nome) => attr(attrs, nome) !== null;

const INTERATIVOS = new Set(['button', 'a', 'input', 'select', 'textarea', 'summary']);
const ROLES_INTERATIVOS = /^(button|link|checkbox|radio|switch|tab|menuitem|option|slider|textbox|combobox)$/;
const HEADINGS = /^h[1-6]$/;

function conteudoInterno(src, t) {
  const fecha = new RegExp(`</${t.nome}\\s*>`, 'i');
  const resto = src.slice(t.fimAbertura);
  const m = resto.match(fecha);
  return m ? resto.slice(0, m.index) : '';
}

// ---------------------------------------------------------------- regras HTML (templates Angular)
function regrasHtml(original) {
  // Comentários viram espaços do mesmo tamanho: somem das regras, mas preservam as linhas.
  const src = original.replace(/<!--[\s\S]*?-->/g, (c) => c.replace(/[^\n]/g, ' '));
  const out = [];
  const add = (idx, sev, cod, msg, fix) => out.push({ linha: linhaDe(src, idx), sev, cod, msg, fix });

  for (const t of tags(src)) {
    const { nome, attrs, idx } = t;
    const role = attr(attrs, 'role')?.valor ?? '';
    const tabindex = attr(attrs, 'tabindex');
    const interativo = INTERATIVOS.has(nome) || ROLES_INTERATIVOS.test(role);
    const ariaHidden = attr(attrs, 'aria-hidden')?.valor === 'true';
    const ariaLabel = attr(attrs, 'aria-label');

    if (role === 'heading')
      add(idx, 'AVISO', 'A01', `<${nome} role="heading"> — heading por ARIA em elemento genérico`, `troque por <h${attr(attrs, 'aria-level')?.valor || 'N'}> nativo`);

    if (tabindex && /^[1-9]/.test(tabindex.valor))
      add(idx, 'ERRO', 'A04', `tabindex positivo (${tabindex.valor}) quebra a ordem de foco`, 'remova; a ordem vem do DOM');
    else if (tabindex && tabindex.valor === '0' && !interativo && !/\(click\)/.test(attrs))
      add(idx, 'ERRO', 'A02', `tabindex="0" em <${nome}${role ? ` role="${role}"` : ''}> não interativo — parada de foco sem ação`, 'remova o tabindex; leitor de tela navega por gesto sem ele');

    if (ariaHidden && (interativo || (tabindex && tabindex.valor !== '-1')))
      add(idx, 'ERRO', 'A03', `aria-hidden="true" em elemento focável <${nome}> — foco cai num elemento "invisível"`, 'tire o aria-hidden ou torne não-focável');

    if (/\(click\)/.test(attrs) && !interativo)
      add(idx, 'ERRO', 'A10', `(click) em <${nome}> — inacessível por teclado e sem papel de botão`, 'use <button type="button">');

    if (nome === 'img' && !temAttr(attrs, 'alt'))
      add(idx, 'ERRO', 'A06', '<img> sem alt', 'alt="" se decorativa; texto se informativa');

    if (ariaLabel && !role && ['div', 'span', 'p'].includes(nome))
      add(idx, 'AVISO', 'A12', `aria-label em <${nome}> sem role — nome em elemento genérico é ignorado de forma inconsistente (TalkBack/VoiceOver)`, 'use texto visualmente oculto (.squad-sr-only) ou um elemento semântico');

    if (ariaLabel && !ariaLabel.dinamico) {
      if (RE_REAIS_DUPLICADO.test(ariaLabel.valor))
        add(idx, 'ERRO', 'A07', `"${ariaLabel.valor}" — leitor lê "R$" como "reais": fica "reais … reais"`, 'remova a palavra "reais"');
      if (RE_ESTADO_NO_TEXTO.test(ariaLabel.valor))
        add(idx, 'AVISO', 'A08', `estado dentro do aria-label ("${ariaLabel.valor}") congela no valor inicial`, 'use aria-expanded / aria-checked / aria-selected');
    }

    if (nome === 'button') {
      const interno = conteudoInterno(src, t);
      const temTexto = interno.replace(/<[^>]+>/g, '').replace(/\s+/g, '').length > 0;
      const temNome = temAttr(attrs, 'aria-label') || temAttr(attrs, 'aria-labelledby') || temAttr(attrs, 'title');
      if (!temTexto && !temNome)
        add(idx, 'ERRO', 'A05', '<button> sem texto e sem aria-label — leitor anuncia só "botão"', 'adicione texto visível ou [attr.aria-label]');
    }

    if (HEADINGS.test(nome)) {
      const interno = conteudoInterno(src, t).trim();
      if (/^\{\{[^}]+\}\}$/.test(interno)) {
        const antes = src.slice(Math.max(0, idx - 200), idx);
        if (!/@if\s*\([^)]*\)\s*\{\s*$/.test(antes))
          add(idx, 'AVISO', 'A09', `<${nome}> só com interpolação — heading vazio se o dado vier "" ou null`, 'envolva em @if (valor) { … }');
      }
    }

    if (role === 'group' && temAttr(attrs, 'aria-labelledby')) {
      const alvo = attr(attrs, 'aria-labelledby').valor;
      if (/heading|cabecalho|titulo/i.test(alvo))
        add(idx, 'AVISO', 'A11', 'role="group" nomeado pelo próprio heading — o texto tende a ser anunciado duas vezes', 'remova o role="group"; o heading já estrutura o bloco (ou use <li> numa lista)');
    }
  }
  return out;
}

// ---------------------------------------------------------------- regras TS (strings de leitura montadas no componente)
function regrasTs(src) {
  const out = [];
  const re = /(['"`])((?:(?!\1)[^\\]|\\.)*)\1/g;
  let m;
  while ((m = re.exec(src))) {
    if (RE_REAIS_DUPLICADO.test(m[2]) || /\$\{[^}]*\}\s*reais/i.test(m[2]) && /R\$/.test(m[2]))
      out.push({ linha: linhaDe(src, m.index), sev: 'ERRO', cod: 'A07', msg: `texto de leitura com "R$ … reais": ${m[2].slice(0, 60)}`, fix: 'remova a palavra "reais"' });
  }
  return out;
}

// ---------------------------------------------------------------- regras FTL (JSON gerado pelo BFF)
function objetosJson(src) {
  // Casa chaves ignorando ${...} (interpolação FTL) e strings. Retorna {ini, fim, chaves:Map(nome->valorBruto)}.
  const objs = [];
  const pilha = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === '$' && src[i + 1] === '{') { const f = src.indexOf('}', i); i = f < 0 ? src.length : f + 1; continue; }
    if (c === '"') {
      let j = i + 1;
      while (j < src.length && src[j] !== '"') { if (src[j] === '\\') j++; else if (src[j] === '$' && src[j + 1] === '{') j = src.indexOf('}', j); j++; }
      i = j + 1; continue;
    }
    if (c === '{') pilha.push(i);
    else if (c === '}' && pilha.length) {
      const ini = pilha.pop();
      objs.push({ ini, fim: i });
    }
    i++;
  }
  // chaves diretas: remove sub-objetos/arrays do corpo antes de ler as chaves
  return objs.map((o) => {
    let corpo = src.slice(o.ini + 1, o.fim);
    let prev;
    do { prev = corpo; corpo = corpo.replace(/\{[^{}]*\}/g, 'OBJ').replace(/\[[^\[\]]*\]/g, 'ARR'); } while (corpo !== prev);
    const chaves = new Map();
    for (const k of corpo.matchAll(/"(\w+)"\s*:\s*("(?:[^"\\]|\\.)*"|[^,\n]+)/g)) chaves.set(k[1], k[2].trim());
    return { ...o, chaves };
  });
}

function regrasFtl(src) {
  const out = [];
  const add = (idx, sev, cod, msg, fix) => out.push({ linha: linhaDe(src, idx), sev, cod, msg, fix });

  // F01 — interpolação sem escape JSON dentro de string
  for (const m of src.matchAll(/"[^"\n]*\$\{([^}]+)\}[^"\n]*"/g)) {
    for (const exp of m[0].matchAll(/\$\{([^}]+)\}/g)) {
      if (!/\?json_string/.test(exp[1]))
        add(m.index, 'ERRO', 'F01', `\${${exp[1]}} sem ?json_string — aspas ou "\\" no dado quebram o JSON`, `\${(${exp[1]})?json_string}`);
    }
  }

  for (const o of objetosJson(src)) {
    const k = o.chaves;
    // F02 — nó acionável sem nome acessível
    if (k.has('acao') && k.get('acao') !== 'null' && !CAMPOS_NOME.some((c) => k.has(c) && !/^(null|"")$/.test(k.get(c))))
      add(o.ini, 'ERRO', 'F02', `nó com "acao" sem nome acessível (chaves: ${[...k.keys()].join(', ')})`, `adicione "${CAMPOS_LEITURA[0]}": "Voltar" (ou o verbo da ação)`);
    // F03 — texto de leitura vazio
    for (const c of CAMPOS_LEITURA)
      if (k.get(c) === '""') add(o.ini, 'ERRO', 'F03', `"${c}": "" — leitor fica sem texto`, 'use null (front aplica padrão) ou o texto real');
    // F05 — significado só visual
    const classes = k.get('classes') ?? '';
    if (/tachad|riscad|strike/i.test(classes) && !CAMPOS_LEITURA.some((c) => k.has(c) && k.get(c) !== 'null'))
      add(o.ini, 'AVISO', 'F05', 'valor tachado sem texto de leitura — "preço antigo" só existe visualmente', 'mande um "tipo" semântico ou texto de leitura ("de R$ X por R$ Y")');
  }

  // F04 — R$ … reais em qualquer string
  for (const m of src.matchAll(/"([^"\n]*)"/g))
    if (RE_REAIS_DUPLICADO.test(m[1])) add(m.index, 'ERRO', 'F04', `"${m[1]}" — "R$" já é lido como "reais"`, 'remova a palavra "reais"');

  return out;
}

// ---------------------------------------------------------------- execução
export function checar(arquivo) {
  const ext = extname(arquivo);
  if (!EXTENSOES.has(ext) || /\.(spec|test|pw)\.ts$/.test(arquivo)) return [];
  const src = readFileSync(arquivo, 'utf8');
  const achados = ext === '.html' ? regrasHtml(src) : ext === '.ftl' ? regrasFtl(src) : regrasTs(src);
  return achados.map((a) => ({ arquivo, ...a }));
}

export function coletar(caminho, acc = []) {
  if (!existsSync(caminho)) return acc;
  const st = statSync(caminho);
  if (st.isFile()) acc.push(caminho);
  else if (st.isDirectory())
    for (const e of readdirSync(caminho)) if (!IGNORAR_DIRS.has(e)) coletar(join(caminho, e), acc);
  return acc;
}

const formatar = (a) => `${relative(process.cwd(), a.arquivo)}:${a.linha}  [${a.sev} ${a.cod}] ${a.msg} → ${a.fix}`;

function caminhosDoHook(payload) {
  // Tolerante ao formato: coleta qualquer string que pareça caminho com extensão observada.
  const achados = new Set();
  const visitar = (v) => {
    if (typeof v === 'string') { for (const m of v.matchAll(/[\w./\\:-]+\.(?:html|ts|ftl)\b/g)) achados.add(m[0]); }
    else if (Array.isArray(v)) v.forEach(visitar);
    else if (v && typeof v === 'object') Object.values(v).forEach(visitar);
  };
  visitar(payload.tool_input ?? payload.toolInput ?? payload);
  return [...achados].filter((p) => existsSync(p));
}

async function main() {
  const args = process.argv.slice(2);

  if (args.includes('--hook')) {
    let entrada = '';
    for await (const c of process.stdin) entrada += c;
    let payload = {};
    try { payload = JSON.parse(entrada || '{}'); } catch { return; }
    const achados = caminhosDoHook(payload).flatMap(checar);
    if (!achados.length) return; // silêncio = zero tokens
    const linhas = achados.slice(0, MAX_ACHADOS_HOOK).map(formatar);
    if (achados.length > MAX_ACHADOS_HOOK) linhas.push(`… +${achados.length - MAX_ACHADOS_HOOK} achados (rode node tools/a11y/a11y-check.mjs <arquivo>)`);
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: `a11y-check no arquivo editado:\n${linhas.join('\n')}` },
    }));
    return;
  }

  const alvos = args.filter((a) => !a.startsWith('--'));
  const achados = (alvos.length ? alvos : ['src']).flatMap((a) => coletar(a)).flatMap(checar);
  if (args.includes('--json')) process.stdout.write(JSON.stringify(achados, null, 2) + '\n');
  else {
    achados.forEach((a) => console.log(formatar(a)));
    const erros = achados.filter((a) => a.sev === 'ERRO').length;
    console.log(`\n${erros} erro(s), ${achados.length - erros} aviso(s)`);
  }
  process.exitCode = achados.some((a) => a.sev === 'ERRO') ? 1 : 0;
}

// Só executa como CLI; importado (a11y-relatorio.mjs) expõe checar/coletar.
if (resolve(process.argv[1] ?? '') === fileURLToPath(import.meta.url)) main();

import { test } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { mkdirSync, writeFileSync } from 'node:fs';
import { basename, resolve } from 'node:path';
import { mockBff } from './support/mock-bff';

// Captura o ESTADO ATUAL de uma tela, sem teste por tela e sem expectativa.
// Roda só via: node tools/a11y/capturar.mjs --escopo <tela> --rota <rota> --fixture <TAG>.json
// Gera em <relatorios>/<escopo>/: atual.aria.yml, axe.json, captura.log

const ESCOPO = process.env.A11Y_ESCOPO;
const ROTA = process.env.A11Y_ROTA;
const SAIDA = process.env.A11Y_SAIDA;
const FIXTURES = (process.env.A11Y_FIXTURES ?? '').split(',').filter(Boolean);

test.skip(!ESCOPO || !ROTA || !SAIDA, 'captura roda só via tools/a11y/capturar.mjs');

test('captura da árvore de acessibilidade', async ({ page }) => {
  const log: string[] = [];
  page.on('response', (r) => { if (r.status() === 501) log.push(`sem fixture: ${r.request().method()} ${r.url()}`); });
  page.on('pageerror', (e) => log.push(`erro JS: ${e.message}`));

  // chave do mock = nome do arquivo sem .json (a TAG), procurada na URL/corpo da requisição
  await mockBff(page, Object.fromEntries(FIXTURES.map((f) => [basename(f, '.json'), f])));
  await page.goto(ROTA!);
  await page.waitForLoadState('networkidle');

  const dir = resolve(SAIDA!, ESCOPO!);
  mkdirSync(dir, { recursive: true });
  writeFileSync(resolve(dir, 'atual.aria.yml'), await page.locator('body').ariaSnapshot());

  const { violations } = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']).analyze();
  writeFileSync(resolve(dir, 'axe.json'), JSON.stringify(
    violations.map((v) => ({ id: v.id, impact: v.impact, descricao: v.help, ajuda: v.helpUrl, alvos: v.nodes.map((n) => n.target.join(' ')) })),
    null, 2));

  writeFileSync(resolve(dir, 'captura.log'), [`rota: ${ROTA}`, `fixtures: ${FIXTURES.join(', ') || '(nenhuma)'}`, ...log].join('\n'));
});

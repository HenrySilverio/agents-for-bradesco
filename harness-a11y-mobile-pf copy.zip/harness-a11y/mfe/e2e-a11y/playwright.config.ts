import { defineConfig, devices } from '@playwright/test';
import { resolve } from 'node:path';

// Testes de acessibilidade do MFE rodando SOZINHO (sem shell, sem app, sem BFF).
// O BFF é substituído por fixtures em mock-bff.ts. Rodar:
//   npx playwright test -c e2e-a11y                      (verifica)
//   npx playwright test -c e2e-a11y --update-snapshots   (gera/atualiza o .aria.yml)

const PORTA = Number(process.env.A11Y_PORTA ?? 4300);
const BASE_EXTERNA = process.env.A11Y_BASE_URL; // se o ng serve já estiver rodando em outra porta

export default defineConfig({
  testDir: '.',
  // .pw.ts e não .spec.ts: o Jest do projeto pega todo *.spec.ts da raiz e tentaria rodar isto.
  testMatch: /.*\.a11y\.pw\.ts$/,
  // O .aria.yml fica ao lado do teste: é revisado em PR junto com a anotação da designer.
  snapshotPathTemplate: '{testDir}/{testFileDir}/__aria__/{arg}{ext}',
  reporter: [['list']],
  // Artefatos do Playwright fora da raiz do repo (já coberto pelo .git/info/exclude).
  outputDir: resolve(__dirname, '../a11y-relatorios/.playwright'),
  retries: 0,
  use: {
    ...devices['Pixel 7'],
    baseURL: BASE_EXTERNA ?? `http://localhost:${PORTA}`,
    locale: 'pt-BR',
    // Máquina do banco: download de browser pelo Playwright costuma ser bloqueado pelo proxy.
    // Usa o Edge/Chrome já instalado. Fora do Windows, cai no Chromium do Playwright.
    channel: process.env.A11Y_CHANNEL ?? (process.platform === 'win32' ? 'msedge' : undefined),
  },
  webServer: BASE_EXTERNA
    ? undefined
    : {
        // AJUSTE: o comando que sobe o remote standalone hoje (npm start? ng serve <projeto>?).
        command: `npx ng serve --port ${PORTA}`,
        cwd: resolve(__dirname, '..'),
        url: `http://localhost:${PORTA}`,
        reuseExistingServer: true,
        timeout: 180_000,
      },
});

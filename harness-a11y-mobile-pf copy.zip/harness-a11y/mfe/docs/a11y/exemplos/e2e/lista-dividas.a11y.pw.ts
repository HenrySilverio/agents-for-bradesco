// EXEMPLO DE FASE 2 (implementação via SDD). Não roda daqui.
// Para usar: copie para e2e-a11y/telas/ e o .aria.yml para e2e-a11y/telas/__aria__/.
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { mockBff } from '../support/mock-bff';

// AJUSTE: rota que abre esta tela direto no MFE standalone.
const ROTA = process.env.A11Y_ROTA_LISTA ?? '/lista-dividas';

test.describe('TELA_LISTA_DIVIDAS_COMPOR_BRADESCO', () => {
  test.beforeEach(async ({ page }) => {
    await mockBff(page, { TELA_LISTA_DIVIDAS_COMPOR_BRADESCO: 'TELA_LISTA_DIVIDAS_COMPOR_BRADESCO.json' });
    await page.goto(ROTA);
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
  });

  // Ordem, papel, texto lido e estado — o mesmo que a anotação da designer descreve.
  // Primeira vez: rode com --update-snapshots, confira o .aria.yml CONTRA A ANOTAÇÃO e só então commite.
  test('árvore de acessibilidade confere com a anotação', async ({ page }) => {
    await expect(page.locator('body')).toMatchAriaSnapshot({ name: 'lista-dividas.aria.yml' });
  });

  test('sem violações WCAG 2.1 A/AA (axe-core)', async ({ page }) => {
    const { violations } = await new AxeBuilder({ page })
      .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
      .analyze();
    // Mensagem legível no terminal: regra + seletor, não o objeto inteiro.
    expect(violations.map((v) => `${v.id} (${v.impact}): ${v.nodes.map((n) => n.target.join(' ')).join(' | ')}`)).toEqual([]);
  });

  test('nenhum elemento não interativo recebe foco', async ({ page }) => {
    const intrusos = await page.locator('[tabindex="0"]:not(a,button,input,select,textarea,[role=button],[role=link],[role=checkbox])').count();
    expect(intrusos).toBe(0);
  });
});

# Auditoria de acessibilidade — lista-dividas

> **Exemplo ilustrativo** do que o `/a11y-auditar` produz, montado com os arquivos reais enviados (`card-lista-dividas`, `lista-dividas`, `detalhe-divida.ftl`) e com a captura de uma página equivalente. Serve de referência de formato.

- **Data:** 2026-09-24 16:26 · **Tag:** TELA_LISTA_DIVIDAS_COMPOR_BRADESCO
- **Anotação da designer:** não. A árvore esperada é **[NÃO VERIFICADO]**; o "Esperado" abaixo vem das regras.
- **Fontes:** estático MFE ✔ · estático FTL ✔ · contrato BFF ✔ (bff-renegociacao) · captura ✔

## Cobertura incompleta
- O FTL que gera `TELA_LISTA_DIVIDAS_COMPOR_BRADESCO` não foi encontrado nos BFFs do workspace. O JSON dessa tela só foi avaliado pela fixture. Fecha com: abrir o BFF dono no `a11y.code-workspace` e rodar de novo.
- Sem anotação da designer: ordem de leitura e textos esperados não foram comparados.

## Resumo
| Unidade | Camada | Alvo | Severidade | Bloqueia | Bloqueado por |
|---|---|---|---|---|---|
| U1 | BFF bff-renegociacao | detalhe-divida.ftl | BLOQUEANTE | U2 | — |
| U2 | MFE | app-cabecalho | BLOQUEANTE | — | U1 (decisão D1) |
| U3 | MFE | card-lista-dividas | BLOQUEANTE | — | — |
| U4 | MFE | lista-dividas | MELHORIA | — | — |

Ordem sugerida: U1 → U3 → U2 → U4

---

## U1 · BFF bff-renegociacao · detalhe-divida.ftl

- **Camada:** BFF (FTL) · **Arquivos:** `src/main/resources/templates/telas/detalhe-divida.ftl`
- **Dono do texto de leitura:** BFF
- **Severidade:** BLOQUEANTE · **Bloqueia:** U2 · **Bloqueado por:** —

### Problema
Se o nome do produto tiver aspas, a tela de detalhe não abre para ninguém. Quando abre, os botões de voltar e fechar são anunciados só como "botão", e um valor é lido como "quatro mil reais reais".

### Evidência
| # | Local | Regra | Hoje | Esperado | Fonte |
|---|---|---|---|---|---|
| 1 | linhas 9, 18, 24–27, 35, 37 | F01 / C01 | `"${produto}"` sem escape; cenário com `Empréstimo "Var."` gera JSON inválido na linha 35 | `"${(produto)?json_string}"` em toda interpolação | estático + contrato |
| 2 | linha 7 · `$.cabecalho.iconeEsquerda` | F02 / C02 | `{ icone, acao }` | nó com nome acessível ("Voltar") | estático + contrato |
| 3 | linha 16 · `$.modal.cabecalho.iconeDireita` | F02 / C02 | `{ icone, acao }` | nó com nome acessível ("Fechar") | estático + contrato |
| 4 | linha 40 · `$.modal.corpoDetalhe[1].acessibilidade` | F04 / C04 | "Você já pagou R$4.000,00 Reais" | "Você já pagou R$ 4.000,00" | estático + contrato |
| 5 | linha 41 · `$.modal.corpoDetalhe[1].valor` | F05 / C05 | valor com `squad-texto-tachado`, sem texto de leitura | texto de leitura que diga que é o valor antigo | estático + contrato |
| 6 | `$.cabecalho.descricao` | C07 | `""` | `null` ou ausente | contrato |

### Resultado esperado (verificável)
- [ ] `node tools/a11y/a11y-check.mjs <ftl>` sem F01, F02, F04
- [ ] `A11yContratoFtlTest` com `-Da11y.modo=erro` passa nos cenários `com-alerta` e `sem-alerta`

### Decisões pendentes
- **[DECISÃO PENDENTE] D1** Nome do campo de nome acessível no contrato: `acessibilidade` (usado neste FTL) ou `texto_leitor` (usado na lista)? — decide: squad (afeta os dois BFFs e o MFE)
- **[DECISÃO PENDENTE] D2** Texto exato do item 5 ("de R$ X por R$ Y"?) — decide: designer

### Fora do escopo
- Como o MFE consome o campo novo → U2.

---

## U2 · MFE · app-cabecalho

- **Camada:** MFE · **Arquivos:** `[NÃO VERIFICADO]`. Componente identificado pelo seletor `header > button` do axe; caminho a confirmar.
- **Dono do texto de leitura:** BFF (quando D1 for decidida); hoje, ninguém
- **Severidade:** BLOQUEANTE · **Bloqueia:** — · **Bloqueado por:** U1 (D1)

### Problema
O botão de voltar do cabeçalho é anunciado só como "botão". O usuário não sabe que ele volta.

### Evidência
| # | Local | Regra | Hoje | Esperado | Fonte |
|---|---|---|---|---|---|
| 1 | `header > button` | axe `button-name` (critical) | `- button` (sem nome) | `- button "Voltar"` | captura |
| 2 | `lista-dividas.component.html:1-5` | contrato ignorado | título e ícone fixos no template; o `cabecalho` do JSON não é usado | cabeçalho lido do contrato | leitura de código |

### Resultado esperado (verificável)
- [ ] `atual.aria.yml` (nova captura) contém `button "Voltar"` dentro de `banner`
- [ ] `axe.json` sem `button-name`

### Decisões pendentes
- **[DECISÃO PENDENTE] D3** Até o BFF mandar o nome: o front usa um mapa fixo ícone → rótulo (`icon-navigation-arrow-left` → "Voltar") ou espera U1? — decide: squad

---

## U3 · MFE · card-lista-dividas

- **Camada:** MFE · **Arquivos:** `src/app/card-lista-dividas/card-lista-dividas.component.html`
- **Dono do texto de leitura:** MFE hoje (`ariaLabelCard`, `corpoAcessibilidade` montados no componente)
- **Severidade:** BLOQUEANTE · **Bloqueia:** — · **Bloqueado por:** —

### Problema
Cada card é anunciado duas vezes com o mesmo texto: como grupo e como título. O título e o corpo recebem foco de teclado sem fazer nada.

### Evidência
| # | Local | Regra | Hoje | Esperado | Fonte |
|---|---|---|---|---|---|
| 1 | linha 2 + captura | A11 | `group "Contrato 9 0 0 0 0 0, Empréstimo…"` contendo `heading` com o mesmo nome | um único anúncio do card | estático + captura |
| 2 | linha 6 | A01 | `<div role="heading" aria-level="2">` | `<h2>` | estático |
| 3 | linhas 6 e 25 | A02 | `tabindex="0"` no título e no grupo do corpo | sem `tabindex` | estático |

### Resultado esperado (verificável)
- [ ] `node tools/a11y/a11y-check.mjs src/app/card-lista-dividas` sem achados
- [ ] Nova captura: nenhum `group` com o mesmo nome do `heading` filho

### Fora do escopo
- Texto de leitura do corpo vindo do BFF (`texto_leitor` hoje é `null`) — depende de D1.

---

## U4 · MFE · lista-dividas

- **Camada:** MFE · **Arquivos:** `src/app/lista-dividas/lista-dividas.component.html`
- **Severidade:** MELHORIA

### Problema
Se o BFF mandar a descrição vazia, surge um título vazio na navegação por títulos.

### Evidência
| # | Local | Regra | Hoje | Esperado | Fonte |
|---|---|---|---|---|---|
| 1 | linha 8 | A09 | `<h1>{{ …descricao }}</h1>` sem guarda | `<h1>` só quando houver texto | estático |

### Decisões pendentes
- **[DECISÃO PENDENTE] D4** Os cards devem ser anunciados como lista ("lista, 3 itens")? A anotação não cobre. — decide: designer

---

## Para a designer
- Sem anotação nesta auditoria. D2 e D4 dependem dela.

## Achados sem dono claro
- `icone_esquerda` da lista sem nome acessível (fixture). O FTL dono não está no workspace. Ver Cobertura incompleta.

## Conferência
- `git status` antes/depois: sem diferença fora de `a11y-relatorios/`.
- Arquivos criados: `a11y-relatorios/lista-dividas/relatorio-2026-09-24-1626.md`

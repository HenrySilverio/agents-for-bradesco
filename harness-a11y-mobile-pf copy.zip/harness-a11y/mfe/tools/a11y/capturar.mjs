#!/usr/bin/env node
// capturar.mjs — tira uma "foto" da árvore de acessibilidade ATUAL de uma tela (sem alterar código).
//
// Uso:
//   node tools/a11y/capturar.mjs --escopo lista-dividas --rota /lista-dividas --fixture TELA_LISTA_DIVIDAS_COMPOR_BRADESCO.json
//
// Pré-requisitos: MFE sobe com `ng serve` e Playwright instalado SEM tocar no package.json:
//   npm i --no-save @playwright/test@1.56 @axe-core/playwright@4.10
// Se o ng serve já estiver rodando: defina A11Y_BASE_URL=http://localhost:4200 antes.

import { spawnSync } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const AQUI = dirname(fileURLToPath(import.meta.url));
const CONFIG = JSON.parse(readFileSync(join(AQUI, 'a11y.config.json'), 'utf8'));
const args = process.argv.slice(2);
const multi = (n) => args.flatMap((a, i) => (a === `--${n}` && args[i + 1] ? [args[i + 1]] : []));

const escopo = multi('escopo')[0];
const rota = multi('rota')[0];
const fixtures = multi('fixture');
if (!escopo || !/^[\w-]+$/.test(escopo) || !rota) {
  console.error('Uso: node tools/a11y/capturar.mjs --escopo <tela> --rota </rota> [--fixture <TAG>.json ...]');
  process.exit(2);
}
for (const f of fixtures)
  if (!existsSync(join('src/testing/a11y/fixtures', f))) { console.error(`Fixture não encontrada: src/testing/a11y/fixtures/${f}`); process.exit(2); }
if (!existsSync('node_modules/@playwright/test')) {
  console.error('Playwright não instalado. Rode: npm i --no-save @playwright/test@1.56 @axe-core/playwright@4.10');
  process.exit(2);
}

const r = spawnSync('npx', ['playwright', 'test', '-c', 'e2e-a11y', 'capturar', '--reporter=line'], {
  stdio: 'inherit',
  shell: process.platform === 'win32', // npx é .cmd no Windows
  env: { ...process.env, A11Y_ESCOPO: escopo, A11Y_ROTA: rota, A11Y_FIXTURES: fixtures.join(','), A11Y_SAIDA: resolve(CONFIG.relatorios) },
});

const dir = join(CONFIG.relatorios, escopo);
if (r.status === 0 && existsSync(join(dir, 'atual.aria.yml'))) {
  console.log(`\n→ ${dir}/atual.aria.yml  (árvore atual)\n→ ${dir}/axe.json\n→ ${dir}/captura.log  (confira "sem fixture": tela pode não ter carregado)`);
} else process.exit(r.status ?? 1);

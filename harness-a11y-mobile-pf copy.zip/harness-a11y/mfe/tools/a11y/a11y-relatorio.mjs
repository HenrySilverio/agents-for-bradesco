#!/usr/bin/env node
// a11y-relatorio.mjs — consolida achados de acessibilidade de MFE + BFFs, agrupados por
// camada e unidade (componente Angular / template FTL). Determinístico, sem LLM, sem dependências.
// NÃO altera código: só lê e escreve em <relatorios>/<escopo>/.
//
// Uso:
//   node tools/a11y/a11y-relatorio.mjs --escopo lista-dividas
//   node tools/a11y/a11y-relatorio.mjs --escopo lista-dividas --mfe src/app/lista-dividas --mfe src/app/shared/card-lista-dividas --ftl detalhe-divida.ftl
//   node tools/a11y/a11y-relatorio.mjs --escopo geral            (inventário do app inteiro)
//
// Fontes:
//   MFE ............ a11y-check nos .html/.ts de --mfe (padrão: config.mfe.raiz)
//   BFF estático ... a11y-check nos .ftl de cada BFF do a11y.config.json (filtro: --ftl)
//   BFF contrato ... <bff>/target/a11y/*.achados.json, gerado pelo A11yContratoFtlTest (IntelliJ)
//   Tela ........... <relatorios>/<escopo>/axe.json, gerado por capturar.mjs (opcional)
//
// Saída: <relatorios>/<escopo>/achados-estaticos.md e .json

import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, relative, basename, dirname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checar, coletar } from './a11y-check.mjs';

const AQUI = dirname(fileURLToPath(import.meta.url));
const REGRAS = JSON.parse(readFileSync(join(AQUI, 'regras.json'), 'utf8'));
const CONFIG = JSON.parse(readFileSync(join(AQUI, 'a11y.config.json'), 'utf8'));

// ---------------------------------------------------------------- argumentos
const args = process.argv.slice(2);
const multi = (nome) => args.flatMap((a, i) => (a === `--${nome}` && args[i + 1] ? [args[i + 1]] : []));
const escopo = multi('escopo')[0];
if (!escopo || !/^[\w-]+$/.test(escopo)) {
  console.error('Informe --escopo <nome-da-tela> (letras, números, - e _). Ex.: --escopo lista-dividas');
  process.exit(2);
}
const pastasMfe = multi('mfe').length ? multi('mfe') : [CONFIG.mfe.raiz];
const filtroFtl = new Set(multi('ftl'));
const saida = resolve(CONFIG.relatorios, escopo);
mkdirSync(saida, { recursive: true });

const avisos = [];
const unidades = new Map(); // chave -> { camada, nome, arquivos:Set, achados:[] }
const unidade = (chave, camada, nome) => {
  if (!unidades.has(chave)) unidades.set(chave, { chave, camada, nome, arquivos: new Set(), achados: [] });
  return unidades.get(chave);
};
const rel = (p) => relative(process.cwd(), p).split(sep).join('/');

// ---------------------------------------------------------------- MFE
for (const p of pastasMfe) if (!existsSync(p)) avisos.push(`MFE: pasta \`${p}\` não existe.`);
for (const achado of pastasMfe.flatMap((p) => coletar(p)).flatMap(checar)) {
  const nome = basename(achado.arquivo).replace(/\.component\.(html|ts)$|\.(html|ts)$/, '');
  const u = unidade(`MFE:${nome}`, 'MFE', nome);
  u.arquivos.add(rel(achado.arquivo));
  u.achados.push({ origem: 'estatico', sev: achado.sev, cod: achado.cod, local: `${rel(achado.arquivo)}:${achado.linha}`, msg: achado.msg, fix: achado.fix });
}

// ---------------------------------------------------------------- BFFs
for (const bff of CONFIG.bffs) {
  const raiz = resolve(bff.raiz);
  if (!existsSync(raiz)) { avisos.push(`BFF ${bff.nome}: pasta \`${bff.raiz}\` não encontrada — ajuste tools/a11y/a11y.config.json.`); continue; }

  const templates = join(raiz, bff.templates);
  const ftls = coletar(templates).filter((f) => f.endsWith('.ftl') && (!filtroFtl.size || filtroFtl.has(basename(f))));
  for (const achado of ftls.flatMap(checar)) {
    const nome = basename(achado.arquivo);
    const u = unidade(`BFF:${bff.nome}:${nome}`, `BFF ${bff.nome}`, nome);
    u.arquivos.add(rel(achado.arquivo));
    u.achados.push({ origem: 'estatico', sev: achado.sev, cod: achado.cod, local: `${rel(achado.arquivo)}:${achado.linha}`, msg: achado.msg, fix: achado.fix });
  }

  const dirContrato = join(raiz, bff.saidaContrato);
  const arquivosContrato = existsSync(dirContrato) ? readdirSync(dirContrato).filter((f) => f.endsWith('.achados.json')) : [];
  if (!arquivosContrato.length) {
    if (filtroFtl.size && !ftls.length) continue; // BFF não tem nenhum FTL desta tela
    avisos.push(`BFF ${bff.nome}: sem achados de contrato (\`${bff.saidaContrato}/*.achados.json\`). Rode A11yContratoFtlTest no IntelliJ para incluir o JSON renderizado.`);
    continue;
  }
  for (const f of arquivosContrato) {
    const caminho = join(dirContrato, f);
    const dados = JSON.parse(readFileSync(caminho, 'utf8'));
    if (filtroFtl.size && !filtroFtl.has(dados.template)) continue;
    const horas = (Date.now() - statSync(caminho).mtimeMs) / 36e5;
    if (horas > 24) avisos.push(`BFF ${bff.nome}: \`${f}\` tem ${Math.round(horas)}h — rode o A11yContratoFtlTest de novo se o FTL mudou.`);
    const u = unidade(`BFF:${bff.nome}:${dados.template}`, `BFF ${bff.nome}`, dados.template);
    u.arquivos.add(rel(join(raiz, bff.templates, dados.template)));
    for (const a of dados.achados)
      u.achados.push({ origem: `contrato (cenário ${dados.cenario})`, sev: a.severidade, cod: a.codigo, local: a.caminho, msg: a.mensagem, fix: a.correcao });
  }
}

// ---------------------------------------------------------------- Tela inteira (captura)
const axePath = join(saida, 'axe.json');
const tela = [];
if (existsSync(axePath)) {
  for (const v of JSON.parse(readFileSync(axePath, 'utf8')))
    tela.push({ origem: 'axe', sev: ['critical', 'serious'].includes(v.impact) ? 'ERRO' : 'AVISO', cod: v.id, local: v.alvos.join(' | '), msg: v.descricao, fix: v.ajuda });
} else avisos.push('Tela: sem captura (`axe.json`, `atual.aria.yml`). Rode capturar.mjs se o MFE sobe localmente.');

// ---------------------------------------------------------------- saída
const ordem = [...unidades.values()].sort((a, b) => (a.camada.startsWith('BFF') ? 0 : 1) - (b.camada.startsWith('BFF') ? 0 : 1) || a.nome.localeCompare(b.nome));
ordem.forEach((u, i) => { u.id = `U${i + 1}`; });

const contar = (lista, sev) => lista.filter((a) => a.sev === sev).length;
const todos = [...ordem.flatMap((u) => u.achados), ...tela];
const esc = (s) => String(s ?? '').replace(/\|/g, '\\|').replace(/\n/g, ' ');

const md = [];
md.push(`# Achados estáticos — ${escopo}`, '');
md.push(`Gerado por \`tools/a11y/a11y-relatorio.mjs\` em ${new Date().toISOString()}. Determinístico: sem interpretação de LLM.`, '');
md.push(`**${contar(todos, 'ERRO')} erro(s), ${contar(todos, 'AVISO')} aviso(s)** em ${ordem.length} unidade(s).`, '');
if (avisos.length) md.push('## Cobertura incompleta', '', ...avisos.map((a) => `- ${a}`), '');
for (const u of ordem) {
  md.push(`## ${u.id} · ${u.camada} · ${u.nome}`, '');
  md.push(`Arquivos: ${[...u.arquivos].map((a) => `\`${a}\``).join(', ')}`, '');
  md.push('| Sev | Regra | Local | Evidência | Impacto no leitor de tela | Correção sugerida | Origem |', '|---|---|---|---|---|---|---|');
  for (const a of u.achados)
    md.push(`| ${a.sev} | ${a.cod} | \`${esc(a.local)}\` | ${esc(a.msg)} | ${esc(REGRAS[a.cod]?.impacto ?? '')} | ${esc(a.fix)} | ${a.origem} |`);
  md.push('');
}
if (tela.length) {
  md.push('## Tela inteira (axe na captura)', '', 'Seletores CSS — o LLM mapeia para o componente dono.', '');
  md.push('| Sev | Regra | Alvos | Descrição | Ajuda |', '|---|---|---|---|---|');
  for (const a of tela) md.push(`| ${a.sev} | ${a.cod} | \`${esc(a.local)}\` | ${esc(a.msg)} | ${esc(a.fix)} |`);
  md.push('');
}

const carimbo = new Date().toISOString().slice(0, 16).replace('T', '-').replace(':', '');
const json = { escopo, geradoEm: new Date().toISOString(), avisos, unidades: ordem.map((u) => ({ ...u, arquivos: [...u.arquivos] })), tela };
writeFileSync(join(saida, 'achados-estaticos.md'), md.join('\n'));
writeFileSync(join(saida, 'achados-estaticos.json'), JSON.stringify(json, null, 2));

console.log(`${contar(todos, 'ERRO')} erro(s), ${contar(todos, 'AVISO')} aviso(s), ${ordem.length} unidade(s)`);
avisos.forEach((a) => console.log(`! ${a}`));
console.log(`→ ${rel(join(saida, 'achados-estaticos.md'))}`);
console.log(`→ nome sugerido do relatório final: ${rel(join(saida, `relatorio-${carimbo}.md`))}`);

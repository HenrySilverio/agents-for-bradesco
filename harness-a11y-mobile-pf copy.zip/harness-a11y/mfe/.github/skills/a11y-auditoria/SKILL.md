---
name: a11y-auditoria
description: Playbook de auditoria de acessibilidade de uma tela (MFE Angular + BFFs com FTL) que produz relatório por unidade de trabalho para virar briefing SDD, sem editar código. Use quando pedirem para auditar, levantar problemas ou mapear onde corrigir acessibilidade.
---
# Auditoria de acessibilidade → relatório por unidade

## Entradas
- `escopo`: nome curto da tela (`lista-dividas`). Obrigatório.
- `tag` da tela (`TELA_...`), se vier do BFF. Sem tag = tela montada só no front.
- `rota` para abrir a tela no MFE standalone (opcional: sem ela, não há captura).
- Print da anotação da designer (opcional: sem ele, não há comparação com o esperado).

## Passos
1. **Linha de base.** Rode `git status --porcelain` na raiz de cada pasta do workspace e guarde a saída.
2. **Descobrir unidades.**
   - MFE: busque a tag (ou o nome da tela) em `src/app`; siga os seletores `app-*` do template até os componentes filhos. O resultado é a lista de pastas de componentes.
   - BFF: busque `"tag": "<TAG>"` nos `*.ftl` de cada BFF do workspace. O resultado é a lista de nomes `.ftl`.
3. **Contrato do BFF.** Para cada FTL, confira se existe `<bff>/target/a11y/*.achados.json` com esse `template`. Se não existir, **não rode Maven**: registre em Cobertura "rodar A11yContratoFtlTest no IntelliJ" e siga em frente. Se faltar cenário para o FTL, registre também.
4. **Achados determinísticos.**
   `node tools/a11y/a11y-relatorio.mjs --escopo <escopo> --mfe <pasta> [--mfe ...] --ftl <arquivo.ftl> [...]`
   Leia `a11y-relatorios/<escopo>/achados-estaticos.json`. A saída do comando traz o nome sugerido do relatório.
5. **Captura** (só com rota): `node tools/a11y/capturar.mjs --escopo <escopo> --rota <rota> --fixture <TAG>.json`. Se falhar ou `captura.log` mostrar "sem fixture", registre em Cobertura e siga. Não conserte.
6. **Esperado** (só com anotação): use a skill `a11y-spec-from-annotation` e crie `a11y-relatorios/<escopo>/esperado.aria.yml`. Compare com `atual.aria.yml`. Cada divergência vira achado na unidade dona, com o nº da anotação.
7. **Atribuir dono.** Leia código só para isto:
   - o texto lido vem do JSON (BFF) ou do componente (MFE)?
   - quais unidades dependem de quais?
   - a que componente pertence cada seletor do axe?
8. **Escrever** o relatório com `edit/createFile` no caminho sugerido no passo 4, seguindo [modelo-relatorio.md](references/modelo-relatorio.md).
9. **Conferência.** Rode `git status --porcelain` de novo e compare com o passo 1. Registre no rodapé do relatório. Diferença fora de `a11y-relatorios/` = avise em destaque.

## Critérios de agrupamento
- Achados do mesmo arquivo e da mesma causa viram uma linha só, com todos os locais.
- A severidade da unidade é a do pior achado: ERRO → BLOQUEANTE, AVISO → MELHORIA.
- Ordem das unidades: BFF antes do MFE que depende dele; depois, BLOQUEANTE antes de MELHORIA.
- Problemas da anotação (ex.: "R$ X Reais", estado no texto) vão em "Para a designer", nunca em unidade de código.

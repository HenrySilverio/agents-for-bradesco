# Modelo do relatório de auditoria

Siga a estrutura exatamente. Cada unidade precisa fazer sentido **sozinha**: ela será copiada para um briefing ou passada ao `/discovery-triagem` como se fosse um chamado.

````markdown
# Auditoria de acessibilidade — <escopo>

- **Data:** <AAAA-MM-DD HH:mm> · **Tag:** <TAG ou "tela só no front">
- **Anotação da designer:** sim | não (sem anotação, a árvore esperada é **[NÃO VERIFICADO]**)
- **Fontes:** estático MFE ✔/✘ · estático FTL ✔/✘ · contrato BFF ✔/✘ · captura ✔/✘

## Cobertura incompleta
- <o que não foi verificado e o comando/passo que fecharia a lacuna>

## Resumo
| Unidade | Camada | Alvo | Severidade | Bloqueia | Bloqueado por |
|---|---|---|---|---|---|
| U1 | BFF <nome> | detalhe-divida.ftl | BLOQUEANTE | U3 | — |

Ordem sugerida de execução: U1 → U3 → U2

---

## U1 · BFF <nome> · detalhe-divida.ftl

- **Camada:** BFF (FTL) · **Arquivos:** `src/main/resources/templates/detalhe-divida.ftl`
- **Dono do texto de leitura:** BFF
- **Severidade:** BLOQUEANTE · **Bloqueia:** U3 · **Bloqueado por:** —

### Problema
<1–3 frases, em linguagem de quem usa leitor de tela. Ex.: "O botão de voltar é anunciado só como 'botão'; o usuário não sabe para onde ele leva.">

### Evidência
| # | Local | Regra | Hoje | Esperado | Fonte |
|---|---|---|---|---|---|
| 1 | `detalhe-divida.ftl:7` / `$.cabecalho.iconeEsquerda` | C02 | nó `{icone, acao}` sem nome | `"acessibilidade": "Voltar"` | contrato (cenário sem-alerta) |

### Resultado esperado (verificável)
- [ ] `mvn test -Dtest=A11yContratoFtlTest -Da11y.modo=erro` sem C02 para este template
- [ ] <linha do esperado.aria.yml, se houver anotação>

### Decisões pendentes
- **[DECISÃO PENDENTE]** Nome do campo: `acessibilidade` ou `texto_leitor`? — decide: squad

### Fora do escopo
- <o que parece relacionado mas pertence a outra unidade>

---

## Para a designer
- <problemas na anotação, com o nº do item>

## Achados sem dono claro
- <achado, e o que falta para atribuir>

## Conferência
- `git status` antes/depois: <sem diferença fora de a11y-relatorios/ | DIFERENÇA: lista>
- Arquivos criados: <lista>
````

Regras de escrita:
- "Hoje" e "Esperado" são literais (o texto falado, o atributo). Sem "melhorar a acessibilidade".
- Nada de solução de implementação além da correção mínima da regra. Como implementar é trabalho do `/sdd-plan`.
- Se a anotação não cobre o elemento, "Esperado" = **[NÃO VERIFICADO]**.

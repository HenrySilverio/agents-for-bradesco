---
name: a11y-verificar
description: Roda e interpreta a verificação local de acessibilidade do MFE (checagem estática, testes de componente, Playwright com ARIA snapshot e axe) sem subir em HOM. Use quando pedirem para testar, validar ou conferir acessibilidade de uma tela ou quando um teste .a11y falhar.
---
# Verificar acessibilidade localmente

Fase 2: use depois que uma unidade do relatório de auditoria for implementada. Para levantar problemas sem mexer em código, use `/a11y-auditar`.

Rode do mais barato para o mais caro e pare no primeiro nível que falhar.

| Nível | Comando | Tempo | Pega |
|---|---|---|---|
| 0 | `node tools/a11y/a11y-check.mjs <arquivo ou pasta>` | <1s | anti-padrões conhecidos no template/TS |
| 1 | `npx jest a11y.spec` | ~10s | nome/papel/nível do componente isolado (jsdom: sem layout nem CSS) |
| 2 | `npx playwright test -c e2e-a11y <tela>` | ~10s + ng serve | ordem de leitura da tela inteira + axe |

Nível 2 usa fixture (`src/testing/a11y/fixtures`) — não precisa de BFF rodando.

## Interpretando falhas
- **Diff do `toMatchAriaSnapshot`**: `-` é o esperado (anotação), `+` é o que a tela expõe. Compare linha a linha e diga ao dev QUAL elemento da anotação diverge (pelo número dela, se houver).
- **axe**: a saída é `regra (impacto): seletor`. `color-contrast` costuma vir de token do Liquid — reporte, não troque cor no componente.
- **Achado axe zero ≠ acessível.** axe não sabe a ordem de leitura nem o texto esperado. O snapshot é o teste principal.

## Onde corrigir (regra de ownership)
- Texto lido errado e a tela vem do BFF (tem `tag`) → correção no FTL do BFF, não no front. Diga isso e pare.
- Papel, heading, foco, `aria-*`, agrupamento → front.
- Snapshot desatualizado por mudança intencional → só atualize (`--update-snapshots`) se a anotação da designer também mudou. Nunca atualize para "fazer passar".

## O que o local NÃO cobre (diga sempre ao final)
Foco inicial ao abrir a WebView e título nativo do app hospedeiro: só em HOM, uma vez, no final. Leitura real de TalkBack/VoiceOver: ver `docs/a11y/acessibilidade-local.md`, nível 3.

---
description: Audita a acessibilidade de uma tela (MFE + BFFs) e grava relatório por unidade para virar briefing. Não altera código. Anexe o print da anotação, se houver.
agent: a11y-auditor
---
Audite a tela abaixo seguindo a skill `a11y-auditoria`.

- Escopo: ${input:escopo:nome curto da tela, ex.: lista-dividas}
- Tag: ${input:tag:TELA_... (vazio se a tela é só do front)}
- Rota: ${input:rota:rota no MFE standalone (vazio = sem captura)}

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { carregarTudo } from '../lib/config.mjs';
import { gerarManual } from '../lib/manual.mjs';

const cfg = carregarTudo();

test('o manual sai autocontido e com as seções que o time precisa', () => {
  const html = gerarManual(cfg, { baseExibida: 'C:\\Users\\fulano\\.copilot\\harness-metricas' });
  assert.ok(!/<script[^>]+src=/i.test(html), 'script externo');
  assert.ok(!/<link[^>]+href=/i.test(html), 'css externo');
  for (const t of ['Instalar o pacote na sua máquina', 'Escolher quais sessões são medidas', 'Medir uma sessão avulsa', 'Puxar os harnesses', 'O que é e o que não é gravado', 'Glossário']) {
    assert.ok(html.includes(t), `faltou a seção: ${t}`);
  }
});

test('nenhum escape de template vira caractere de controle no HTML', () => {
  const html = gerarManual(cfg, { baseExibida: 'C:\\Users\\fulano\\.copilot\\harness-metricas' });
  const controle = [...html].filter((c) => c.charCodeAt(0) < 32 && !'\n\r\t'.includes(c));
  assert.equal(controle.length, 0, `caracteres de controle no HTML: ${controle.map((c) => c.charCodeAt(0))}`);
  assert.ok(html.includes('C:\\Users\\fulano\\.copilot\\harness-metricas\\bin\\hm.mjs'), 'o caminho do hm.mjs saiu quebrado');
});

test('o caminho exibido é o que foi pedido, não o da máquina que gerou', () => {
  const html = gerarManual(cfg, { baseExibida: 'D:\\ferramentas\\hm' });
  assert.ok(html.includes('D:\\ferramentas\\hm\\dados\\otel\\copilot-otel.jsonl'));
  assert.ok(!html.includes('/home/claude'));
});
